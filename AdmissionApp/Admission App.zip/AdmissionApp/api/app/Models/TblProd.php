<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class TblProd extends Model
{
    protected $table = 'tbl_prod';

}
