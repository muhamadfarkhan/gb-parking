<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class TblPlg extends Model
{
    
    public $timestamps = false;
    protected $table = 'tbl_plg';

}
