package net.admission.view.transact;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import net.admission.R;


public class PrinterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_printer);

    }
}