package net.admission.model

data class Transact(val passno: String, val regno: String, val remark: String, val datetime: String)
