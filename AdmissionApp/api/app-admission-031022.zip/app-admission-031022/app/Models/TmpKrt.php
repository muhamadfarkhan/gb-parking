<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class TmpKrt extends Model
{
    
    public $timestamps = false;
    protected $table = 'tmp_krt';

}
