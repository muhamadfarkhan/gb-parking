<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class TblTrans extends Model
{
    
    public $timestamps = false;
    protected $table = 'tbl_trans';

}
