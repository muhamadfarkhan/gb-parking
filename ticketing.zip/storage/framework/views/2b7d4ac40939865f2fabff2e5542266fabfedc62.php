<header class="main-nav">
    <div class="sidebar-user" style="margin-bottom: 0px;"><img class="img-90 rounded-circle" src="<?php echo e(asset('assets/images/dashboard/1.png')); ?>" alt="" style="width: 35px !important;border-width: 3px !important;float: left;">
    <!-- <div class="badge-bottom"><span class="badge badge-primary">New</span></div> -->
    <a href="<?php echo e(route('dashboard')); ?>">
        <h6 class="mt-3 f-14 f-w-600" style="margin-top: 0 !important;padding-left: 50px;text-align: left;display: block;"><?php echo e(Session::get('nama')); ?></h6></a>
    <p class="mb-0 font-roboto" style="font-size: 8px; padding-left: 15px;text-align: left;max-width: 120px;text-overflow: ellipsis;white-space: nowrap;overflow: hidden;"><?php echo e(Session::get('jabatan')); ?></p>
    </div>
    <nav>
    <div class="main-navbar">
        <div class="left-arrow" id="left-arrow"><i data-feather="arrow-left"></i></div>
        <div id="mainnav">           
        <ul class="nav-menu custom-scrollbar" style="height: auto;">
            <li class="back-btn">
            <div class="mobile-back text-end"><span>Back</span><i class="fa fa-angle-right ps-2" aria-hidden="true"></i></div>
            </li>
            <li class="sidebar-main-title">
            <div>
                <h6>Home</h6>
            </div>
            </li>
            <li><a class="nav-link menu-title link-nav" href="<?php echo e(url('/')); ?>"
            <?php if(Request::segment(1) == ''): ?>
            style="background-color: #4c8e82; color: #d0efe9;"
            <?php endif; ?>><i data-feather="home"></i><span>Dashboard</span></a></li>

            
            <?php if(str_contains(strtolower(Session::get('jabatan')), 'sales') || 
                    str_contains(strtolower(Session::get('jabatan')), 'district')): ?>
            <li><a class="nav-link menu-title link-nav" href="<?php echo e(url('/master-data')); ?>"
            <?php if(Request::segment(1) == '/master-data'): ?>
            style="background-color: #4c8e82; color: #d0efe9;"
            <?php endif; ?>><i data-feather="list"></i><span>Branding Program</span></a></li>
            <?php endif; ?>

            <?php if(str_contains(strtolower(Session::get('jabatan')), 'group')): ?>
                <li><a class="nav-link menu-title link-nav" href="<?php echo e(url('/manage-budget-pm')); ?>"
                <?php if(Request::segment(1) == 'manage-budget-pm' || Request::segment(1) == 'req-budget-pm'): ?>
                style="background-color: #4c8e82; color: #d0efe9;"
                <?php endif; ?>
                ><i data-feather="airplay"></i><span>Manage Budget PM</span></a></li>
            <?php endif; ?>

            <?php if(str_contains(strtolower(Session::get('jabatan')), 'product') ): ?> 
                <?php if(!str_contains(strtolower(Session::get('jabatan')), 'group')): ?>
                    <li><a class="nav-link menu-title link-nav" href="<?php echo e(url('/parameter-prod-branding')); ?>"
                    <?php if(Request::segment(1) == 'parameter-prod-branding'): ?>
                    style="background-color: #4c8e82; color: #d0efe9;"
                    <?php endif; ?>
                    ><i data-feather="archive"></i><span>Parameter Branding</span></a></li>
                <?php endif; ?>
            <?php endif; ?>

            <li class="sidebar-main-title">
            <div>
                <h6>Product Branding</h6>
            </div>
            </li>

            <?php if(str_contains(strtolower(Session::get('jabatan')), 'district')): ?>
            <li><a class="nav-link menu-title link-nav" href="<?php echo e(url('/manage-prod-branding')); ?>"
            <?php if(Request::segment(1) == 'manage-prod-branding' || Request::segment(1) == 'req-prod-branding'): ?>
            style="background-color: #4c8e82; color: #d0efe9;"
            <?php endif; ?>
            ><i data-feather="edit-3"></i><span>Pengajuan</span></a></li>
            <?php endif; ?>
            
            <?php if(str_contains(strtolower(Session::get('jabatan')), 'product') || 
                    str_contains(strtolower(Session::get('jabatan')), 'regional')): ?> 
                <?php if(!str_contains(strtolower(Session::get('jabatan')), 'group')): ?>
                    <li><a class="nav-link menu-title link-nav" href="<?php echo e(url('/approval-prod-branding')); ?>"
                    <?php if(Request::segment(1) == 'approval-prod-branding'): ?>
                    style="background-color: #4c8e82; color: #d0efe9;"
                    <?php endif; ?>
                    ><i data-feather="check-square"></i><span>Approval</span></a></li>
                <?php endif; ?>
            <?php endif; ?>

            <?php if(str_contains(strtolower(Session::get('jabatan')), 'sales') || 
                    str_contains(strtolower(Session::get('jabatan')), 'district') ||
                        str_contains(strtolower(Session::get('jabatan')), 'finance')): ?>
                <li><a class="nav-link menu-title link-nav" href="<?php echo e(url('/real-prod-branding')); ?>"
                <?php if(Request::segment(1) == 'real-prod-branding'): ?>
                style="background-color: #4c8e82; color: #d0efe9;"
                <?php endif; ?>
                ><i data-feather="calendar"></i><span>Realisasi</span></a></li>
            <?php endif; ?>

            
            <?php if(str_contains(strtolower(Session::get('jabatan')), 'finance')): ?>
            <li><a class="nav-link menu-title link-nav" href="<?php echo e(url('/report-transfer')); ?>"
                <?php if(Request::segment(1) == 'report-transfer'): ?>
                style="background-color: #4c8e82; color: #d0efe9;"
                <?php endif; ?>
                ><i data-feather="briefcase"></i><span>Data Transfer</span></a></li>
            <?php endif; ?>

                <li><a class="nav-link menu-title link-nav" href="<?php echo e(url('/report-branding')); ?>"
                <?php if(Request::segment(1) == 'report-branding'): ?>
                style="background-color: #4c8e82; color: #d0efe9;"
                <?php endif; ?>
                ><i data-feather="list"></i><span>Reporting</span></a></li>


        </ul>
        </div>
        <div class="right-arrow" id="right-arrow"><i data-feather="arrow-right"></i></div>
    </div>
    </nav>
</header><?php /**PATH D:\MFN\WebServer\laragon\www\parking-is\resources\views/layouts/partials/sidebar.blade.php ENDPATH**/ ?>