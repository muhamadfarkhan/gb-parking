<!DOCTYPE html>
<html>
<head>

	<style>
	
        * {
            font-size: 14px;
        }

        th {
            width:100%;
            text-align:center;
        }

        .aright{
            text-align:right;
        }

        table, td, th {
            border: 1px solid #ddd;;
        }

        table {
            border-collapse: collapse;
            width: 100%;
        }

	</style>
</head>
<body>
	<div class="container">
	<p align="center"> <b style="font-size: 1.5em;">LAPORAN REKAP TRANSAKSI</b> </p>
    <p align="center" style="font-size: 18px;"> <?php echo e(strtoupper($site->site_name)); ?> </p>
    <table style="border: 0px;">
        <tr>
            <td width="10%" style="border: 0px;">Tgl Shift</td>
            <td style="border: 0px;">: <?php echo e($startDate); ?> s/d <?php echo e($endDate); ?></td>
        </tr>
        <tr>
            <td style="border: 0px;" width="10%">Jam Shift</td>
            <td style="border: 0px;">: <?php echo e($startHour); ?> s/d <?php echo e($endHour); ?></td>
        </tr>
    </table>
	<br>
	<!-- Here pure-table class is used -->
    <p><b style="font-size: 1em;">REKAP PENDAPATAN</b></p>
	<table style="border: 1px solid #ddd;" id="datatable" class="table table-bordered table-hover" width="100%" >
            <thead>
            <tr role="row">
                <th width="25%" rowspan="3">
                    Kelas Kendaraan
                </th>
                <th width="5%" colspan="4" style="text-align: center;">Total Masuk</th>
                <th width="5%" colspan="4" style="text-align: center;">Total Keluar</th>
                <th width="5%" rowspan="3" style="text-align: center;vertical-align: middle;">Pendapatan</th>
                <th width="5%" rowspan="2" colspan="2" style="vertical-align: middle; text-align: center;">
                    Jenis Pembayaran
                </th>
            </tr>
            <tr role="row">
                <th width="5%" style="text-align: center;" colspan="2" class=table-center"> Normal</th>
                <th width="5%" style="text-align: center;" colspan="2" class=table-center"> Manual</th>
                <th width="5%" style="text-align: center;" colspan="2" class=table-center"> Normal</th>
                <th width="5%" style="text-align: center;border-right: 2px solid #e6edef;" colspan="2" class=table-center"> Manual</th>
            </tr>
            <tr role="row">
                <th width="5%" style="text-align: center;" class=table-center"> Casual</th>
                <th width="5%" style="text-align: center;" class=table-center"> Pass</th>
                <th width="5%" style="text-align: center;" class=table-center"> Casual</th>
                <th width="5%" style="text-align: center;" class=table-center"> Pass</th>

                <th width="5%" style="text-align: center;" class=table-center"> Casual</th>
                <th width="5%" style="text-align: center;" class=table-center"> Pass</th>
                <th width="5%" style="text-align: center;" class=table-center"> Casual</th>
                <th width="5%" style="text-align: center;" class=table-center"> Pass</th>

                <th width="5%" style="text-align: center;" class=table-center"> Tunai</th>
                <th width="5%" style="text-align: center;" class=table-center"> E-Payment</th>
            </tr>
            </thead>
            <tbody>
            <?php $sum_casualIn = 0 ?>
            <?php $sum_passIn = 0 ?>
            
            <?php $sum_casualOut = 0 ?>
            <?php $sum_passOut = 0 ?>

            <?php $sum_pendapatan = 0 ?>
            <?php $sum_cash = 0 ?>
            <?php $sum_epayment = 0 ?>

                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td width="25%"><?php echo e($data->vehicle); ?></td>
                    <td class="aright"><?php echo e(number_format($data->casualIn,0,'','.')); ?></td>
                    <td class="aright"><?php echo e(number_format($data->passIn,0,'','.')); ?></td>
                   
                    <td class="aright"><?php echo e(number_format($data->manualCasualIn,0,'','.')); ?></td>
                    <td class="aright"><?php echo e(number_format($data->manualPassIn,0,'','.')); ?></td>

                    <td class="aright"><?php echo e(number_format($data->casualOut,0,'','.')); ?></td>
                    <td class="aright"><?php echo e(number_format($data->passOut,0,'','.')); ?></td>

                    <td class="aright"><?php echo e(number_format($data->manualCasualOut,0,'','.')); ?></td>
                    <td class="aright"><?php echo e(number_format($data->manualPassOut,0,'','.')); ?></td>

                    <td class="aright"><?php echo e(number_format($data->pendapatan,0,'','.')); ?></td>
                    <td class="aright"><?php echo e(number_format($data->tunai,0,'','.')); ?></td>
                    <td class="aright"><?php echo e(number_format($data->ePayment,0,'','.')); ?></td>
                </tr>
                <?php $sum_casualIn += $data->casualIn ?>
                <?php $sum_passIn += $data->passIn ?>
                <?php $sum_casualOut += $data->casualOut ?>
                <?php $sum_passOut += $data->passOut ?>
                <?php $sum_pendapatan += $data->pendapatan ?>
                <?php $sum_cash += $data->tunai ?>
                <?php $sum_epayment += $data->ePayment ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
            <tr class="total">
                <th >TOTAL</th>
                <th class="aright"><?php echo e(number_format($sum_casualIn,0,'','.')); ?></th>
                <th class="aright" ><?php echo e(number_format($sum_passIn,0,'','.')); ?></th>
                <th class="aright" ><?php echo e(number_format($sum_passIn,0,'','.')); ?></th>
                <th class="aright" >0</th>
                <th class="aright" >0</th>
                <th class="aright" ><?php echo e(number_format($sum_passOut,0,'','.')); ?></th>
                <th class="aright" >0</th>
                <th class="aright" >0</th>
                <th class="aright" ><?php echo e(number_format($sum_pendapatan,0,'','.')); ?></th>
                <th class="aright" ><?php echo e(number_format($sum_cash,0,'','.')); ?></th>
                <th class="aright" ><?php echo e(number_format($sum_epayment,0,'','.')); ?></th>
            </tr>
            </tfoot>
        </table>
        <br>
        <p><b style="font-size: 1em;">STATISTIK LAMA PARKIR KENDARAAN</b></p>
        <table style="border: 1px solid #ddd;" id="datatable2" class="table table-bordered table-hover">
            <thead>
            <tr role="row">
                <th rowspan="2" style="vertical-align: middle; text-align: center;"
                    class="table-center">
                    Kelas Kendaraan
                </th>
                <th colspan="2" style="text-align: center;">0-1 Jam</th>
                <th colspan="2" style="text-align: center;">1-2 Jam</th>
                <th colspan="2" style="text-align: center;">2-3 Jam</th>
                <th colspan="2" style="text-align: center;">3-4 Jam</th>
                <th colspan="2" style="text-align: center;">4-5 Jam</th>
                <th colspan="2" style="text-align: center;">5-6 Jam</th>
                <th colspan="2" style="text-align: center;">Lebih dari 6 Jam</th>
            </tr>
            <tr role="row">
                                                    <th style="text-align: center;">Pass</th>
                    <th style="text-align: center;">Casual</th>
                                                    <th style="text-align: center;">Pass</th>
                    <th style="text-align: center;">Casual</th>
                                                    <th style="text-align: center;">Pass</th>
                    <th style="text-align: center;">Casual</th>
                                                    <th style="text-align: center;">Pass</th>
                    <th style="text-align: center;">Casual</th>
                                                    <th style="text-align: center;">Pass</th>
                    <th style="text-align: center;">Casual</th>
                                                    <th style="text-align: center;">Pass</th>
                    <th style="text-align: center;">Casual</th>
                                                    <th style="text-align: center;">Pass</th>
                    <th style="text-align: center;">Casual</th>
                                            </tr>
            </thead>
            <tbody>
            <?php $sum_pass1 = 0 ?>
            <?php $sum_casual1 = 0 ?>
            <?php $sum_pass2 = 0 ?>
            <?php $sum_casual2 = 0 ?>
            <?php $sum_pass3 = 0 ?>
            <?php $sum_casual3 = 0 ?>
            <?php $sum_pass4 = 0 ?>
            <?php $sum_casual4 = 0 ?>
            <?php $sum_pass5 = 0 ?>
            <?php $sum_casual5 = 0 ?>
            <?php $sum_pass6 = 0 ?>
            <?php $sum_casual6 = 0 ?>
            <?php $sum_pass7 = 0 ?>
            <?php $sum_casual7 = 0 ?>
                <?php $__currentLoopData = $dataStat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td width="25%"><?php echo e($data->vehicle); ?></td>
                    <td class="aright"><?php echo e(number_format($data->pass1,0,'','.')); ?></td>
                    <td class="aright"><?php echo e(number_format($data->casual1,0,'','.')); ?></td>
                    <td class="aright"><?php echo e(number_format($data->pass2,0,'','.')); ?></td>
                    <td class="aright"><?php echo e(number_format($data->casual2,0,'','.')); ?></td>
                    <td class="aright"><?php echo e(number_format($data->pass3,0,'','.')); ?></td>
                    <td class="aright"><?php echo e(number_format($data->casual3,0,'','.')); ?></td>
                    <td class="aright"><?php echo e(number_format($data->pass4,0,'','.')); ?></td>
                    <td class="aright"><?php echo e(number_format($data->casual4,0,'','.')); ?></td>
                    <td class="aright"><?php echo e(number_format($data->pass5,0,'','.')); ?></td>
                    <td class="aright"><?php echo e(number_format($data->casual5,0,'','.')); ?></td>
                    <td class="aright"><?php echo e(number_format($data->pass6,0,'','.')); ?></td>
                    <td class="aright"><?php echo e(number_format($data->casual6,0,'','.')); ?></td>
                    <td class="aright"><?php echo e(number_format($data->pass7,0,'','.')); ?></td>
                    <td class="aright"><?php echo e(number_format($data->casual7,0,'','.')); ?></td>
                </tr>
                <?php $sum_pass1 += $data->pass1 ?>
                <?php $sum_casual1 += $data->casual1 ?>
                <?php $sum_pass2 += $data->pass2 ?>
                <?php $sum_casual2 += $data->casual2 ?>
                <?php $sum_pass3 += $data->pass3 ?>
                <?php $sum_casual3 += $data->casual3 ?>
                <?php $sum_pass4 += $data->pass4 ?>
                <?php $sum_casual4 += $data->casual4 ?>
                <?php $sum_pass5 += $data->pass5 ?>
                <?php $sum_casual5 += $data->casual5 ?>
                <?php $sum_pass6 += $data->pass6 ?>
                <?php $sum_casual6 += $data->casual6 ?>
                <?php $sum_pass7 += $data->pass7 ?>
                <?php $sum_casual7 += $data->casual7 ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
            <tr class="total">
                <th>TOTAL</th>
                <th class="aright" ><?php echo e(number_format($sum_pass1,0,'','.')); ?></th>
                <th class="aright" ><?php echo e(number_format($sum_casual1,0,'','.')); ?></th>
                <th class="aright" ><?php echo e(number_format($sum_pass2,0,'','.')); ?></th>
                <th class="aright" ><?php echo e(number_format($sum_casual2,0,'','.')); ?></th>
                <th class="aright" ><?php echo e(number_format($sum_pass3,0,'','.')); ?></th>
                <th class="aright" ><?php echo e(number_format($sum_casual3,0,'','.')); ?></th>
                <th class="aright" ><?php echo e(number_format($sum_pass4,0,'','.')); ?></th>
                <th class="aright" ><?php echo e(number_format($sum_casual4,0,'','.')); ?></th>
                <th class="aright" ><?php echo e(number_format($sum_pass5,0,'','.')); ?></th>
                <th class="aright" ><?php echo e(number_format($sum_casual5,0,'','.')); ?></th>
                <th class="aright" ><?php echo e(number_format($sum_pass6,0,'','.')); ?></th>
                <th class="aright" ><?php echo e(number_format($sum_casual6,0,'','.')); ?></th>
                <th class="aright" ><?php echo e(number_format($sum_pass7,0,'','.')); ?></th>
                <th class="aright" ><?php echo e(number_format($sum_casual7,0,'','.')); ?></th>
            </tr>
            </tfoot>
        </table>
	</div>
</body>
</html>
<?php /**PATH D:\MFN\WebServer\laragon\www\parking-is\resources\views/modules/trans/pdfRecap.blade.php ENDPATH**/ ?>