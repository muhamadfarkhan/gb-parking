
<?php $__env->startSection('title'); ?>
 <?php echo e($title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row">
    <div class="col-sm-12">
      <div class="card">
        <div class="card-header b-l-primary">
          <h5>Daftar Transaksi Tiket</h5><span></span>
          <div class="setting-list">
            <i class="icofont icofont-refresh reload-card font-primary"></i>
            <i class="icofont icofont-minus minimize-card font-primary"></i>
          </div>
        </div>
        <div class="card-body">

          <div class="col-sm-12 col-xl-12">
            <div class="card card-absolute">
              <div class="card-header bg-light">
                <h5 class="text-black"><span class="icon-search"></span> Filter Transaksi</h5>
              </div>
              <div class="card-body">
              <form class="needs-validation" novalidate="">
                  <div class="row g-3">
                    
                    <div class="col-md-4">
                      <label class="form-label" for="validationCustom04">Lokasi</label>
                          <select class="form-select select2" name="site_id" id="validationCustom04" required="">
                            <?php $__currentLoopData = $site; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							  <option value="<?php echo e($site->id); ?>" selected readonly><?php echo e($site->site_name); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                      <div class="invalid-feedback">Mohon pilih lokasi.</div>
                    </div>

                    <div class="col-md-4">
                      <label class="form-label" for="validationCustom02">Rentang Tanggal</label>
                      <div class="input-group"><span class="input-group-text"><i class="icofont icofont-ui-calendar"></i></span>
                        <input class="form-control daterange" id="validationCustom02" type="text" name="date_range" value="<?php echo e($dateRangeNow); ?>" required="">
                      </div>
                      <div class="invalid-feedback">Mohon pilih rentang tanggal.</div>
                    </div>
                    
                    <div class="col-md-4">
                      <label class="form-label" for="validationCustom04">Jenis Tiket</label>
                        <select class="form-select select2" name="jenis_tiket" id="validationCustom04" required="">
                            <option value="">Pilih Jenis tiket...</option>
                            <?php $__currentLoopData = $ticket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tick): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($tick->VEHCLASS); ?>"><?php echo e($tick->WALKDES); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      <div class="invalid-feedback">Mohon pilih perusahaan.</div>
                    </div>
                    </div>
                    <div class="row" style="margin-top: 16px;">
                    
                    <div class="col-md-4">
                      <label class="form-label" for="validationCustom04">Petugas Tiket</label>
                        <select class="form-select select2" name="petugas" id="validationCustom04" required="">
                            <option value="">Pilih Petugas tiket...</option>
                            <?php $__currentLoopData = $petugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $petugas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($petugas->USRNM); ?>"><?php echo e($petugas->FULLNM); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      <div class="invalid-feedback">Mohon pilih perusahaan.</div>
                    </div>

                    <div class="col-md-4">
                      <label class="form-label" for="validationCustom04">Perusahaan Pelayaran</label>
                        <select class="form-select select2" name="perusahaan" id="validationCustom04" required="">
                            <option value="">Pilih Perusahaan...</option>
                            <?php $__currentLoopData = $perusahaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($per->CODE); ?>"><?php echo e($per->DESCR); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      <div class="invalid-feedback">Mohon pilih perusahaan.</div>
                    </div>

                    <div class="col-md-4">
                      <label class="form-label" for="validationCustom04">Jenis Pembayaran</label>
                        <select class="form-select select2" name="pembayaran" id="validationCustom04" required="">
                            <option value="">Pilih Jenis Pembayaran...</option>
                              <option value="C">Cash</option>
                              <option value="P">Pass</option>
                              <option value="E">E-Payment</option>
                        </select>
                      <div class="invalid-feedback">Mohon pilih pembayaran.</div>
                    </div>

                    
                  </div>

                  <div class="row" style="margin-top: 12px;">

                    <div class="col-md-4">
                      <label class="form-label" for="validationCustom04">Jenis Kapal</label>
                        <select class="form-select select2" name="kapal" id="validationCustom04" required="">
                            <option value="">Pilih Jenis Kapal...</option>
                            <?php $__currentLoopData = $kapal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kapal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($kapal->CODE); ?>"><?php echo e($kapal->DESCR); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      <div class="invalid-feedback">Mohon pilih perusahaan.</div>
                    </div>
         
                   <div class="col-md-2 mb-3">
                      <label class="form-label" for="validationCustomUsername">&nbsp;</label>
                      <div class="input-group">
                      <button class="btn btn-primary" id="show" type="button">Tampilkan</button>
                      </div>
                    </div>
                    <div class="col-md-2 mb-3">
                      <label class="form-label" for="validationCustomUsername">&nbsp;</label>
                      <div class="input-group">
                      <button class="btn btn-secondary" id="pdf" style="display: none" type="button">
                      <span class="fa fa-file-pdf-o"></span> Pdf</button>
                      </div>
                    </div>
                  </div>
                
                
                  
                </form>
              </div>
            </div>
          </div>
          
          
        </div>
      </div>
    </div>
  </div>

<div class="row box-body" style="display: none">
    <div class="col-sm-12">
      <div class="card">
        <div class="card-header b-r-primary">
          <h5>Transaksi Tiket</h5><span></span>
        </div>
        <div class="card-body">
        <div class="dt-ext">
            <table class="display table-hover" id="custom-datatable">
              <thead>
              <tr role="row">
                <th style="vertical-align: middle; text-align: center;"
                    class="table-center">
                    No Trans
                </th>
                <th style="vertical-align: middle; text-align: center;"
                    class="table-center">
                    Pembelian
                </th>
                <th style="vertical-align: middle; text-align: center;"
                    class="table-center">
                    Jenis Tiket
                </th>
                <th style="vertical-align: middle; text-align: center;"
                    class="table-center">
                    Tanggal
                </th>
                <th style="vertical-align: middle; text-align: center;"
                    class="table-center">
                    Nama
                </th>
                <th style="vertical-align: middle; text-align: center;"
                    class="table-center">
                    No. Plat
                </th>
                <th style="vertical-align: middle; text-align: center;"
                    class="table-center">
                    Pembayaran
                </th>
                <th style="vertical-align: middle; text-align: center;"
                    class="table-center">
                    Jml<br>Pnp
                </th>
                <th style="vertical-align: middle; text-align: center;"
                    class="table-center">
                    Pelayanan
                </th>
                <th style="vertical-align: middle; text-align: center;"
                    class="table-center">
                    TJP
                </th>
                <th style="vertical-align: middle; text-align: center;"
                    class="table-center">
                    Iuran Wajib
                </th>
                <th style="vertical-align: middle; text-align: center;"
                    class="table-center">
                    Pas Pelabuhan
                </th>
                <th style="vertical-align: middle; text-align: center;"
                    class="table-center">
                    Berat<br>(kg)
                </th>
                <th style="vertical-align: middle; text-align: center;"
                    class="table-center">
                    Total Terpadu
                </th>
            </tr>
              </thead>
              <tbody>  
              </tbody>
              <tfoot>
                <tr>
                    <th colspan="13" class="aright">Total Pendapatan</th>
                    <th class="aright" id="total-income"></th>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
    </div>
  </div>
</div>
</div>

<div class="modal fade modal-transaction" id="modal-transaction" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenter" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Detail Transaksi</h5>
        <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="dt-ext table-responsive">
          <table class="table table-border-vertical miniTable">
                <thead>
                <tr>
                    <th>No. Trans</th>
                    <th>Petugas Tiket</th>
                    <th>Pembelian Tiket</th>
                    <th>Jenis Kapal</th>
                    <th>Perusahaan Pelayaran</th>
                    <th>Tanggal</th>
                    <th>Total Terpadu (Rp)</th>
                </tr>
                <tr>
                    <td id="tr-notrans"></td>
                    <td id="tr-usrnma"></td>
                    <td id="tr-entrytype"></td>
                    <td id="tr-jeniskapal"></td>
                    <td id="tr-usrnme"></td>
                    <td id="tr-tanggal"></td>
                    <td id="tr-total" class="aright"></td>
                </tr>
                </thead>
                <tbody>  
                </tbody>
          </table>
          <input type="hidden" id="current_index_row_tr"/>
          <div class="col-md-12 col-xs-12 col-lg-12">
              <div class="row">
                  <div class="col-md-6 col-xs-6 col-lg-6">
                      <p class="text-center">
                          <img id="img-in" src="<?php echo e(asset('assets/images/noimage.png')); ?>"
                                style="max-width: 320px;max-height: 240px"
                                class="img-responsive img-thumbnail" alt=""/>
                      </p>
                      <p class="text-center text-bold">Gambar Pos ticketing</p>
                  </div>
                  <div class="col-md-6 col-xs-6 col-lg-6">
                      <p class="text-center">
                          <img id="img-out" src="<?php echo e(asset('assets/images/noimage.png')); ?>"
                                style="max-width: 320px;max-height: 240px"
                                class="img-responsive img-thumbnail"
                                data-failover="<?php echo e(asset('assets/images/noimage.png')); ?>" alt=""/>
                      </p>
                      <p class="text-center text-bold">Gambar Gate verifikasi</p>
                  </div>
              </div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" id="btn-back-tr" type="button"><i class="fa fa-arrow-left" style="margin-right:10px;"></i>Previous</button>
        <button class="btn btn-primary" id="btn-next-tr" type="button">Next<i class="fa fa-arrow-right" style="margin-left:10px;"></i></button>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- Plugins JS start-->
    <script src="<?php echo e(asset('assets/js/datatable/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/buttons.colVis.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.autoFill.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/responsive.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.keyTable.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.colReorder.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.fixedHeader.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.rowReorder.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.scroller.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/datatable-prev-next.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/custom.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/accounting.min.js')); ?>"></script>
   
    <script>
      $(document).ready(function(){

        var site = $('select[name=site_id]');
        var range = $('input[name=date_range]');

        moment.locale("id");
        $('.daterange').daterangepicker({
            'dateLimit': {
                'month': 1
            },
            'timePicker': true,
            'timePicker24Hour': true,
            'startDate': moment().startOf('day'),
            'endDate': moment().endOf('day'),
            'autoUpdateInput': true,
            'locale': {
                "format": 'DD/MM/YYYY HH:mm',
                "fromLabel": "Dari",
                "toLabel": "Sampai",
                "customRangeLabel": "Custom",
                "daysOfWeek": [
                    "Mg",
                    "Sn",
                    "Sl",
                    "Rb",
                    "Km",
                    "Jm",
                    "Sb"
                ],
                "monthNames": [
                    "Januari",
                    "Februari",
                    "Maret",
                    "April",
                    "Mei",
                    "Juni",
                    "Juli",
                    "Agustus",
                    "September",
                    "Oktober",
                    "November",
                    "Desember"
                ],
                "firstDay": 1
            }
        });
        $('.select2').select2();

        $('#show').click(function (event) {
            event.preventDefault();

            if (site.val() === "" || range.val().length === 0) {
                swalNotify("Oops!","Parameter lokasi harus diisi.","warning");
                return false;
            }

            $(".box-body").show();
            datatable();
            // setLabel();
        });

      var table = null;

      function datatable(){
        
        var site = $('select[name=site_id]').val();
        var jenis_tiket = $('select[name=jenis_tiket]').val();
        var petugas = $('select[name=petugas]').val();
        var perusahaan = $('select[name=perusahaan]').val();
        var kapal = $('select[name=kapal]').val();
        var pembayaran = $('select[name=pembayaran]').val();
        var range = $('input[name=date_range]').val();//.split('-');

        table = $('#custom-datatable').DataTable( {
              processing: true,
              serverSide: true,
              responsive: true,
              bDestroy: true,
              ajax: { 
                      url: "<?php echo e(route('ajax-ticket-trans')); ?>",
                      data: function (d) {
                            d.site = site;
                            d.jenis_tiket = jenis_tiket;
                            d.petugas = petugas;
                            d.perusahaan = perusahaan;
                            d.kapal = kapal;
                            d.pembayaran = pembayaran;
                            d.range = range;
                        },
                      type: "post" 
                    },
              columns: [
                  {data: 'NOTRAN', name: 'NOTRAN', visible: false},
                  {data: 'pembelian', name: 'pembelian', visible: false},
                  {data: 'jenis_tiket', name: 'jenis_tiket'},
                  {data: 'DATETIMEIN', name: 'DATETIMEIN'},
                  {data: 'PASSNO', name: 'PASSNO'},
                  {data: 'REGNO', name: 'REGNO'},
                  {data: 'TRANPAY', name: 'TRANPAY', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                  {data: 'ENTPAY', name: 'ENTPAY', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                  {data: 'VLTAMT', visible: false, name: 'VLTAMT', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                  {data: 'VLTFEE', visible: false, name: 'VLTFEE', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                  {data: 'CPSAMT', visible: false, name: 'CPSAMT', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                  {data: 'TRANFEE', visible: false, name: 'TRANFEE', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                  {data: 'CPSFEE', name: 'CPSFEE', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                  {data: 'TRANSAMT', name: 'TRANSAMT', render: $.fn.dataTable.render.number('.', ',', 0, ''), className: "aright"}
              ],
              order: [[2, 'desc']],
              fnDrawCallback: function () {
                  $('[data-toggle="tooltip"]').tooltip();
                  $("#pdf").show();
                  var api = this.api();
                  var json = api.ajax.json();
                  $("#total-qty").html(json.total_qty);
                  $("#total-income").html(json.total_income_f);
              },   
          });

        }

        $('#pdf').click(function () {
          var site = $('select[name=site_id]').val();
          var range = $('input[name=date_range]').val();
          var jenis_tiket = $('select[name=jenis_tiket]').val();
          var pembayaran = $('select[name=pembayaran]').val();
          var perusahaan = $('select[name=perusahaan]').val();
          var petugas = $('select[name=petugas]').val();

          if (site == "" || range == "") {
              $('#alert-filter').show().delay(3000).fadeOut('slow');
              return false;
          }

          var param = {
              site: site,
              range: range,
              jenis_tiket: jenis_tiket,
              perusahaan: perusahaan,
              petugas: petugas,
              pembayaran: pembayaran
          };

          var url = "<?php echo e(url('parking-trans-pdf')); ?>" + "?" + $.param(param);
          window.open(url, "_blank");
      });

          $('#btn-submit').click(function(){
              table.draw();
          });

          $('#custom-datatable').on('click', 'tbody tr td:not(:first-child)', function () {
              var data = table.row(this).data();
              var selected = table.row(this).index();

              update_current_row(selected);
              showModal(data);
          });

          $('#btn-back-tr').click(function () {
              previousRow();
          });

          $('#btn-next-tr').click(function () {
              nextRow();
          });

          function update_current_row(value) {
              $("#current_index_row_tr").val("").val(value);
          }

          function showModal(data) {
            var modal = $('.modal-transaction');
            modal.modal('show');

            modal.find('#tr-notrans').text('').text(data.NOTRAN);
            modal.find('#tr-usrnma').text('').text(data.USRNMA);
            modal.find('#tr-entrytype').text('').text(data.pembelian);
            modal.find('#tr-jeniskapal').text('').text(data.jenis_kapal);
            modal.find('#tr-usrnme').text('').text(data.perusahaan);
            modal.find('#tr-tanggal').text('').text(data.DATETIMEIN);
            modal.find('#tr-total').text('').text(formatNumber(data.TRANSAMT));

            modal.find("#img-in").attr('src', 'public/capture/'+data.TGLIMG+'/'+data.NOTRAN+'A.jpg');
            modal.find("#img-out").attr('src', 'public/capture/'+data.TGLIMG+'/'+data.NOTRAN+'B.jpg');

            $('img').on("error", function() {
              $(this).attr('src', '<?php echo e(asset('assets/images/noimage.png')); ?>');
              // $(this).attr('src', 'public/capture/'+data.TGLIMG+'/'+data.NOTRAN+'A.jpg');
            });
          }

          function nextRow() {
            $("#btn-back-tr").attr("disabled", false);
            var selected = $("#current_index_row_tr").val();
            var data = table.row(selected).next();
            if (parseInt(selected) < parseInt(table.data().length) - 1) {
                update_current_row(data.index());
                showModal(data.data());
            } else {
                goNextPage();
            }
          }

          function previousRow() {
              $("#btn-next-tr").attr("disabled", false);
              var selected = $("#current_index_row_tr").val();
              var data = table.row(selected).prev();

              if (data !== null) {
                  update_current_row(data.index());
                  showModal(data.data());
              } else {
                  goPrevPage();
              }
          }

          function goNextPage() {
              var maxpage = parseInt(table.page.info().pages - 1);
              var currentPage = parseInt(table.page.info().page);

              if (currentPage < maxpage) {
                  table.page('next').draw(false);
                  update_current_row(0);
                  showModal(table.row(0).data());
              } else {
                  $("#btn-next-tr").attr("disabled", true);
                  return false;
              }
          }

          function goPrevPage() {
              var maxpage = 0;
              var currentPage = parseInt(table.page.info().page);
              if (currentPage > maxpage) {
                  table.page('previous').draw(false);
                  var lastRow = table.row(':last');
                  update_current_row(lastRow.index());
                  showModal(lastRow.data());
              } else {
                  $("#btn-back-tr").attr("disabled", true);
                  return false;
              }
          }

          function formatNumber(number) {
            var precision = {
                decimal: ",",
                thousand: ".",
                precision: 0,
                format: "%s%v"
            };
            return accounting.formatNumber(number, precision)
        }
      });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ticketing/resources/views/modules/trans/ticket.blade.php ENDPATH**/ ?>