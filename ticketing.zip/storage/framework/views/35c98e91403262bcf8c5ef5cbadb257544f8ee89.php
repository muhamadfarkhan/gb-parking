
<?php $__env->startSection('title'); ?>
 <?php echo e($title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid dashboard-default-sec">
  <div class="row">
    
    <h8><?php echo e(Carbon\Carbon::now()); ?></h8>
    <h6>Selamat datang, <?php echo e(Auth()->user()->USRNM); ?></h6>
    
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MFN\WebServer\laragon\www\ticketing-ms\resources\views/layouts/dashboard.blade.php ENDPATH**/ ?>