
<?php $__env->startSection('title'); ?>
 <?php echo e($title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row">
    <div class="col-sm-12">
      <div class="card">
        <div class="card-header b-l-primary">
          <h5>Daftar Transaksi Tiket</h5><span></span>
          <div class="setting-list">
            <i class="icofont icofont-refresh reload-card font-primary"></i>
            <i class="icofont icofont-minus minimize-card font-primary"></i>
          </div>
        </div>
        <div class="card-body">

          <div class="col-sm-12 col-xl-12">
            <div class="card card-absolute">
              <div class="card-header bg-light">
                <h5 class="text-black"><span class="icon-search"></span> Filter Transaksi</h5>
              </div>
              <div class="card-body">
              <form class="needs-validation" novalidate="">
                  <div class="row g-3">
                    
                    <div class="col-md-4">
                      <label class="form-label" for="validationCustom04">Lokasi</label>
                          <select class="form-select select2" name="site_id" id="validationCustom04" required="">
                            <option value="">Pilih lokasi...</option>
                            <?php $__currentLoopData = $site; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($site->id); ?>"><?php echo e($site->site_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                      <div class="invalid-feedback">Mohon pilih lokasi.</div>
                    </div>

                    <div class="col-md-4">
                      <label class="form-label" for="validationCustom02">Rentang Tanggal</label>
                      <div class="input-group"><span class="input-group-text"><i class="icofont icofont-ui-calendar"></i></span>
                        <input class="form-control daterange" id="validationCustom02" type="text" name="date_range" value="<?php echo e($dateRangeNow); ?>" required="">
                      </div>
                      <div class="invalid-feedback">Mohon pilih rentang tanggal.</div>
                    </div>
                    
                    <div class="col-md-4">
                      <label class="form-label" for="validationCustom04">Jenis Kendaraan</label>
                      <select class="form-select select2" name="vehicle_type_id" id="validationCustom04" required="">
                              <option value="">Semua</option>
                              <option value="C">Motor</option>
                              <option value="B">Mobil</option>
                            </select>
                      <div class="invalid-feedback">Mohon pilih lokasi.</div>
                    </div>
                    </div>
                    <div class="row" style="margin-top: 24px;">
                    <div class="col-md-4">
                      <label class="form-label" for="validationCustom04">Kondisi</label>
                      <select class="form-select select2" name="condition" id="validationCustom04" required="">
                              <option value="">Semua</option>
                              <option value="in">Masih Parkir</option>
                              <option value="out">Sudah Keluar</option>
                            </select>
                      <div class="invalid-feedback">Mohon pilih lokasi.</div>
                    </div>
                    <div class="col-md-4">
                      <label class="form-label" for="validationCustom04">Pembayaran</label>
                      <select class="form-select select2" name="payment_method" id="validationCustom04" required="">
                              <option value="">Semua</option>
                              <option value="C">Cash</option>
                              <option value="P">Pass</option>
                              <option value="E">E-Payment</option>
                              <option value="V">Voucher</option>
                              <option value="O">Ovo</option>
                            </select>
                      <div class="invalid-feedback">Mohon pilih lokasi.</div>
                    </div>
                    <div class="col-md-2 mb-3">
                      <label class="form-label" for="validationCustomUsername">&nbsp;</label>
                      <div class="input-group">
                      <button class="btn btn-primary" id="show" type="button">Tampilkan</button>
                      </div>
                    </div>
                    <div class="col-md-2 mb-3">
                      <label class="form-label" for="validationCustomUsername">&nbsp;</label>
                      <div class="input-group">
                      <button class="btn btn-secondary" id="pdf" style="display: none" type="button">
                      <span class="fa fa-file-pdf-o"></span> Pdf</button>
                      </div>
                    </div>
                  </div>
                
                
                  
                </form>
              </div>
            </div>
          </div>
          
          
        </div>
      </div>
    </div>
  </div>

<div class="row box-body" style="display: none">
    <div class="col-sm-12">
      <div class="card">
        <div class="card-header b-r-primary">
          <h5>Transaksi Parkir</h5><span></span>
        </div>
        <div class="card-body">
        <div class="dt-ext">
            <table class="display table-hover" id="custom-datatable">
              <thead>
              <tr role="row">
                <th rowspan="2" style="vertical-align: middle; text-align: center;"
                    class="table-center">
                    No. Plat
                </th>
                <th rowspan="2" style="vertical-align: middle; text-align: center;"
                    class="table-center">
                    No. Pass
                </th>
                <th rowspan="2" style="vertical-align: middle; text-align: center;"
                    class="table-center">
                    Kendaraan
                </th>
                <th colspan="2" style="text-align: center;">Masuk</th>
                <th colspan="2" style="text-align: center;">Keluar</th>
                <th rowspan="2" style="text-align: center;vertical-align: middle">Pembayaran</th>
                <th rowspan="2" style="vertical-align: middle; text-align: center;">Biaya <br>(Rp)
                </th>
            </tr>
            <tr role="row">
                <th style="text-align: center;" class="table-center"> Tanggal - Jam</th>
                <th style="text-align: center;" class="table-center"> Disp</th>
                <th style="text-align: center;" class="table-center">Tanggal - Jam</th>
                <th style="text-align: center;" class="table-center">User</th>
            </tr>
              </thead>
              <tbody>  
              </tbody>
              <tfoot>
                <tr>
                    <th colspan="8" class="text-center">Total Qty</th>
                    <th class="aright" id="total-qty"></th>
                </tr>
                <tr>
                    <th colspan="8" class="text-center">Total Income</th>
                    <th class="aright" id="total-income"></th>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
    </div>
  </div>
</div>
</div>

<div class="modal fade modal-transaction" id="modal-transaction" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenter" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Detail Transaksi</h5>
        <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="dt-ext table-responsive">
          <table class="table table-border-vertical miniTable">
                <thead>
                <tr>
                    <th>No. Plat</th>
                    <th>No. Pass</th>
                    <th>Kendaraan</th>
                    <th>Tanggal Masuk</th>
                    <th>Disp</th>
                    <th>Tanggal Keluar</th>
                    <th>User</th>
                    <th>Pembayaran</th>
                    <th>Biaya (Rp)</th>
                </tr>
                <tr>
                    <td id="tr-noplat"></td>
                    <td id="tr-nopass"></td>
                    <td id="tr-kendaraan"></td>
                    <td id="tr-datein"></td>
                    <td id="tr-display"></td>
                    <td id="tr-dateout"></td>
                    <td id="tr-user"></td>
                    <td id="tr-payment"></td>
                    <th id="tr-fee" class="aright"></th>
                </tr>
                </thead>
                <tbody>  
                </tbody>
          </table>
          <input type="hidden" id="current_index_row_tr"/>
          <div class="col-md-12 col-xs-12 col-lg-12">
              <div class="row">
                  <div class="col-md-6 col-xs-6 col-lg-6">
                      <p class="text-center">
                          <img id="img-in" src="<?php echo e(asset('assets/images/noimage.png')); ?>"
                                style="max-width: 320px;max-height: 240px"
                                class="img-responsive img-thumbnail" alt=""/>
                      </p>
                      <p class="text-center text-bold">Gambar Pos Masuk</p>
                  </div>
                  <div class="col-md-6 col-xs-6 col-lg-6">
                      <p class="text-center">
                          <img id="img-out" src="<?php echo e(asset('assets/images/noimage.png')); ?>"
                                style="max-width: 320px;max-height: 240px"
                                class="img-responsive img-thumbnail"
                                data-failover="<?php echo e(asset('assets/images/noimage.png')); ?>" alt=""/>
                      </p>
                      <p class="text-center text-bold">Gambar Pos Keluar</p>
                  </div>
              </div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" id="btn-back-tr" type="button"><i class="fa fa-arrow-left" style="margin-right:10px;"></i>Previous</button>
        <button class="btn btn-primary" id="btn-next-tr" type="button">Next<i class="fa fa-arrow-right" style="margin-left:10px;"></i></button>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- Plugins JS start-->
    <script src="<?php echo e(asset('assets/js/datatable/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/buttons.colVis.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.autoFill.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/responsive.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.keyTable.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.colReorder.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.fixedHeader.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.rowReorder.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.scroller.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/datatable-prev-next.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/custom.js')); ?>"></script>

    <script>
      $(document).ready(function(){

        var site = $('select[name=site_id]');
        var range = $('input[name=date_range]');

        moment.locale("id");
        $('.daterange').daterangepicker({
            'dateLimit': {
                'month': 1
            },
            'timePicker': true,
            'timePicker24Hour': true,
            'startDate': moment().startOf('day'),
            'endDate': moment().endOf('day'),
            'autoUpdateInput': true,
            'locale': {
                "format": 'DD/MM/YYYY HH:mm',
                "fromLabel": "Dari",
                "toLabel": "Sampai",
                "customRangeLabel": "Custom",
                "daysOfWeek": [
                    "Mg",
                    "Sn",
                    "Sl",
                    "Rb",
                    "Km",
                    "Jm",
                    "Sb"
                ],
                "monthNames": [
                    "Januari",
                    "Februari",
                    "Maret",
                    "April",
                    "Mei",
                    "Juni",
                    "Juli",
                    "Agustus",
                    "September",
                    "Oktober",
                    "November",
                    "Desember"
                ],
                "firstDay": 1
            }
        });
        $('.select2').select2();

        $('#show').click(function (event) {
            event.preventDefault();

            if (site.val() === "" || range.val().length === 0) {
                swalNotify("Oops!","Parameter lokasi harus diisi.","warning");
                return false;
            }

            $(".box-body").show();
            datatable();
            // setLabel();
        });

      var table = null;

      function datatable(){
        
        var site = $('select[name=site_id]').val();
        var vehicle = $('select[name=vehicle_type_id]').val();
        var condition = $('select[name=condition]').val();
        var payment_method = $('select[name=payment_method]').val();
        var range = $('input[name=date_range]').val();//.split('-');

        table = $('#custom-datatable').DataTable( {
              processing: true,
              serverSide: true,
              responsive: true,
              bDestroy: true,
              ajax: { 
                      url: "<?php echo e(route('ajax-ticket-trans')); ?>",
                      data: function (d) {
                            d.site = site;
                            d.vehicle = vehicle;
                            d.condition = condition;
                            d.payment_method = payment_method;
                            d.range = range;
                        },
                      type: "post" 
                    },
              columns: [
                  {data: 'REGNO', name: 'REGNO'},
                  {data: 'PASSNO', name: 'PASSNO'},
                  {data: 'vehicle', name: 'vehicle'},
                  {data: 'DATETIMEIN', name: 'DATETIMEIN'},
                  {data: 'USRNME', name: 'USRNME'},
                  {data: 'DATETIMEOUT', name: 'DATETIMEOUT'},
                  {data: 'USRNMA', name: 'USRNMA'},
                  {data: 'TRANPAY', name: 'TRANPAY'},
                  {data: 'TRANFEE', name: 'TRANFEE', className: "aright"}
              ],
              order: [[3, 'desc']],
              fnDrawCallback: function () {
                  $('[data-toggle="tooltip"]').tooltip();
                  $("#pdf").show();
                  var api = this.api()
                  var json = api.ajax.json();
                  $("#total-qty").html(json.total_qty);
                  $("#total-income").html(json.total_income);
              },   
          });

        }

        $('#pdf').click(function () {
          var site = $('select[name=site_id]').val();
          var range = $('input[name=date_range]').val();
          var condition = $('select[name=condition]').val();
          var vehicle = $('select[name=vehicle_type_id]').val();
          var payment = $('select[name=payment_method]').val();

          if (site == "" || range == "") {
              $('#alert-filter').show().delay(3000).fadeOut('slow');
              return false;
          }

          var param = {
              site: site,
              range: range,
              vehicle: vehicle,
              condition: condition,
              payment_method: payment
          };

          var url = "<?php echo e(url('parking-trans-pdf')); ?>" + "?" + $.param(param);
          window.open(url, "_blank");
      });

          $('#btn-submit').click(function(){
              table.draw();
          });

          $('#custom-datatable').on('click', 'tbody tr td:not(:first-child)', function () {
              var data = table.row(this).data();
              var selected = table.row(this).index();

              update_current_row(selected);
              showModal(data);
          });

          $('#btn-back-tr').click(function () {
              previousRow();
          });

          $('#btn-next-tr').click(function () {
              nextRow();
          });

          function update_current_row(value) {
              $("#current_index_row_tr").val("").val(value);
          }

          function showModal(data) {
            var modal = $('.modal-transaction');
            modal.modal('show');

            modal.find('#tr-noplat').text('').text(data.REGNO);
            modal.find('#tr-nopass').text('').text(data.PASSNO);
            modal.find('#tr-kendaraan').text('').text(data.vehicle);
            modal.find('#tr-datein').text('').text(data.DATETIMEIN);
            modal.find('#tr-display').text('').text(data.USRNME);
            modal.find('#tr-dateout').text('').text(data.DATETIMEOUT);
            modal.find('#tr-user').text('').text(data.USRNMA);
            modal.find('#tr-payment').text('').text(data.TRANPAY);
            modal.find('#tr-fee').text('').text(data.TRANFEE);

            modal.find("#img-in").attr('src', data.img_in);
            modal.find("#img-out").attr('src', data.img_out);

            $('img').on("error", function() {
              $(this).attr('src', '<?php echo e(asset('assets/images/noimage.png')); ?>');
            });
          }

          function nextRow() {
            $("#btn-back-tr").attr("disabled", false);
            var selected = $("#current_index_row_tr").val();
            var data = table.row(selected).next();
            if (parseInt(selected) < parseInt(table.data().length) - 1) {
                update_current_row(data.index());
                showModal(data.data());
            } else {
                goNextPage();
            }
          }

          function previousRow() {
              $("#btn-next-tr").attr("disabled", false);
              var selected = $("#current_index_row_tr").val();
              var data = table.row(selected).prev();

              if (data !== null) {
                  update_current_row(data.index());
                  showModal(data.data());
              } else {
                  goPrevPage();
              }
          }

          function goNextPage() {
              var maxpage = parseInt(table.page.info().pages - 1);
              var currentPage = parseInt(table.page.info().page);

              if (currentPage < maxpage) {
                  table.page('next').draw(false);
                  update_current_row(0);
                  showModal(table.row(0).data());
              } else {
                  $("#btn-next-tr").attr("disabled", true);
                  return false;
              }
          }

          function goPrevPage() {
              var maxpage = 0;
              var currentPage = parseInt(table.page.info().page);
              if (currentPage > maxpage) {
                  table.page('previous').draw(false);
                  var lastRow = table.row(':last');
                  update_current_row(lastRow.index());
                  showModal(lastRow.data());
              } else {
                  $("#btn-back-tr").attr("disabled", true);
                  return false;
              }
          }
      });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MFN\WebServer\laragon\www\ticketing-ms\resources\views/modules/trans/parking.blade.php ENDPATH**/ ?>