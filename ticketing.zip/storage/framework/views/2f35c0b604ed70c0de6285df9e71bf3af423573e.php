
<?php $__env->startSection('title'); ?>
 <?php echo e($title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row">
    <div class="col-sm-12">
      <div class="card">
        <div class="card-header b-l-primary">
          <h5> Laporan Rekap Transaksi </h5><span></span>
        </div>
        <div class="card-body">

        <div class="col-sm-12 col-xl-12">
          <div class="card card-absolute">
            <div class="card-header bg-light">
              <h5 class="text-black"><span class="icon-search"></span> Filter Transaksi</h5>
            </div>
            <div class="card-body">
            <form class="needs-validation" novalidate="">
                <div class="row g-3">
                  <div class="col-md-4">
                    <label class="form-label" for="validationCustom04">Lokasi</label>
                        <select class="form-select select2" name="site_id" id="validationCustom04" required="">
                          <option value="">Pilih lokasi...</option>
                          <?php $__currentLoopData = $site; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($site->id); ?>"><?php echo e($site->site_name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    <div class="invalid-feedback">Mohon pilih lokasi.</div>
                  </div>
                  <div class="col-md-4">
                    <label class="form-label" for="validationCustom02">Rentang Tanggal</label>
                    
                    <div class="input-group"><span class="input-group-text"><i class="icofont icofont-ui-calendar"></i></span>
                      <input class="form-control" id="date_ranges" type="text" name="date_range" value="<?php echo e($dateRangeNow); ?>" required="">
                    </div>
                    <div class="invalid-feedback">Mohon pilih rentang tanggal.</div>
                  </div>
                  <div class="col-md-4">
                      <label class="form-label" for="validationCustom04">Petugas</label>
                        <select class="form-select select2" name="petugas" id="validationCustom04" required="">
                            <option value="">Pilih Petugas...</option>
                            <?php $__currentLoopData = $petugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($pet->USRNM); ?>"><?php echo e($pet->FULLNM); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      <div class="invalid-feedback">Mohon pilih lokasi.</div>
                    </div>
                    <div class="col-md-4">
                      <label class="form-label" for="validationCustom04">Perusahaan Pelayaran</label>
                        <select class="form-select select2" name="perusahaan" id="validationCustom04" required="">
                            <option value="">Pilih Perusahaan...</option>
                            <?php $__currentLoopData = $perusahaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($per->CODE); ?>"><?php echo e($per->DESCR); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      <div class="invalid-feedback">Mohon pilih perusahaan.</div>
                    </div>
                  <div class="col-md-2 mb-3">
                    <label class="form-label" for="validationCustomUsername">&nbsp;</label>
                    <div class="input-group">
                    <button class="btn btn-primary" id="show" type="button">Tampilkan</button>
                    </div>
                  </div>
                  <div class="col-md-2 mb-3">
                      <label class="form-label" for="validationCustomUsername">&nbsp;</label>
                      <div class="input-group">
                      <button class="btn btn-secondary" id="pdf" style="display: none" type="button">
                      <span class="fa fa-file-pdf-o"></span> Pdf</button>
                      </div>
                    </div>
                </div>
               
               
                
              </form>
            </div>
          </div>
        </div>
        
          <div class="dt-ext">
            <div class="box-body" style="display: none">
              <h3 style="text-align: center">Laporan Rekap Transaksi</h3>
              <h4 class="text-center"><span id="info-location"></span></h4>
              <h5 style="text-align: center"><span id="info-date"></span></h5>
              <br>
              <h6><i class="fa fa-bar-chart-o"></i> Rekap Pendapatan</h6>
              <table id="datatable" class="table table-bordered table-hover" width="100%" >
                  <thead>
                  <tr role="row">
                      <th rowspan="2" style="vertical-align: middle; text-align: center;"
                          class="table-center">
                          Jenis tiket
                      </th>
                      <th colspan="3" style="text-align: center;">Pembelian tiket</th>
                      <th colspan="2" style="text-align: center;">Pelayaran</th>
                      <th rowspan="2" style="vertical-align: middle; text-align: center;">Iuran Wajib</th>
                      <th rowspan="2" style="vertical-align: middle; text-align: center;">Pas Pelabuhan</th>
                      <th rowspan="2" style="vertical-align: middle; text-align: center;">Total Terpadu</th>
                      <th colspan="3" style="vertical-align: middle; text-align: center;">
                          Jenis Pembayaran
                      </th>
                  </tr>
                  <tr role="row">
                      <th style="text-align: center;" class=table-center"> Online</th>
                      <th style="text-align: center;" class=table-center"> Offline</th>
                      <th style="text-align: center;" class=table-center"> Jumlah</th>

                      <th style="text-align: center;" class=table-center"> Pelayanan</th>
                      <th style="text-align: center;" class=table-center"> TJP</th>

                      <th style="text-align: center;" class=table-center"> Tunai</th>
                      <th style="text-align: center;" class=table-center"> E-Payment</th>

                  </tr>
                  </thead>
                  <tbody></tbody>
                  <tfoot>
                    <tr class="total">
                        <th style="border-top: 2px solid #e6edef;">TOTAL</th>
                        <th style="border-top: 2px solid #e6edef;"></th>
                        <th style="border-top: 2px solid #e6edef;"></th>
                        <th style="border-top: 2px solid #e6edef;"></th>
                        <th style="border-top: 2px solid #e6edef;"></th>
                        <th style="border-top: 2px solid #e6edef;"></th>
                        <th style="border-top: 2px solid #e6edef;"></th>
                        <th style="border-top: 2px solid #e6edef;"></th>
                        <th style="border-top: 2px solid #e6edef;"></th>
                        <th style="border-top: 2px solid #e6edef;"></th>
                        <th style="border-top: 2px solid #e6edef;"></th>
                    </tr>
                  </tfoot>
              </table>
          </div><!-- /.box-body -->
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- Plugins JS start-->
    <script src="<?php echo e(asset('assets/js/datatable/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/buttons.colVis.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.autoFill.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/responsive.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.keyTable.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.colReorder.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.fixedHeader.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.rowReorder.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.scroller.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/datatable-prev-next.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/custom.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/accounting.min.js')); ?>"></script>
    
    <script src="<?php echo e(asset('assets/js/form-validation-custom.js')); ?>"></script>

    <script>
      $(document).ready(function(){

        var site = $('select[name=site_id]');
        var range = $('input[name=date_range]');

        moment.locale("id");
        $('.select2').select2();

        $('#show').click(function (event) {
            event.preventDefault();

            if (site.val() === "" || range.val().length === 0) {
                swalNotify("Oops!","Parameter lokasi harus diisi.","warning");
                return false;
            }

            $(".box-body").show();
            datatable();
            setLabel();
        });

        
        $('#date_ranges').daterangepicker({
                'dateLimit': {
                    'month': 1
                },
                'autoApply': true,
                'startDate': moment().startOf('month'),
                'endDate': moment().endOf('month'),
                'locale': {
                    "format": 'DD/MM/YYYY',
                    "applyLabel": "Apply",
                    "cancelLabel": "Cancel",
                    "fromLabel": "Dari",
                    "toLabel": "Sampai",
                    "customRangeLabel": "Custom",
                    "daysOfWeek": [
                        "Mg",
                        "Sn",
                        "Sl",
                        "Rb",
                        "Km",
                        "Jm",
                        "Sb"
                    ],
                    "monthNames": [
                        "Januari",
                        "Februari",
                        "Maret",
                        "April",
                        "Mei",
                        "Juni",
                        "Juli",
                        "Agustus",
                        "September",
                        "Oktober",
                        "November",
                        "Desember"
                    ],
                    "firstDay": 1
                },
                'format': 'DD-MM-YYYY'
            });


        $('#pdf').click(function () {
            event.preventDefault();
            var site = $('select[name=site_id]').val();
            var perusahaan = $('select[name=perusahaan]').val();
            var petugas = $('select[name=petugas]').val();
            var range = $('input[name=date_range]').val().split('-');

            if (site == "" || range == "") {
                $('#alert-filter').show().delay(3000).fadeOut('slow');
                return false;
            }

            var param = {
                site: site,
                start: range[0].replace(/\s+/g, ''),
                end: range[1].replace(/\s+/g, ''),
                perusahaan: perusahaan,
                petugas: petugas,
            };

            var url = "<?php echo e(url('parking-recap-pdf')); ?>" + "?" + $.param(param);
            window.open(url, "_blank");
        });

        function setLabel() {
                var location = $('select[name=site_id] :selected').text();
                var date = range.val();
                $('#info-location').text('').text(location);
                $('#info-date').text('').text(date);
            }


            function datatable() {
                var rangeExplode = range.val().split('-');
                var petugas = $('select[name=petugas]').val();
                var perusahaan = $('select[name=perusahaan]').val();

                var targets = [1, 2, 3, 4, 5, 6, 7, 8, 10];

                return oTable = $('#datatable').DataTable({
                    "bPaginate": false,
                    "bLengthChange": true,
                    "bFilter": false,
                    "bSort": false,
                    "responsive": true,
                    "bInfo": false,
                    "bAutoWidth": true,
                    "processing": true,
                    "bDestroy": true,
                    "serverSide": true,
                    "columnDefs": [
                        {"className": "dt-right", "targets": targets},
                        {"className": "aright", "targets": [9]}
                    ],
                    "ajax": {
                        url: "<?php echo e(route('ajax-recap-transaction')); ?>",
                        data: function (d) {
                            d.site = site.val(),
                            d.petugas = petugas,
                            d.perusahaan = perusahaan,
                            d.start = rangeExplode[0].replace(/\s+/g, ''),
                            d.end = rangeExplode[1].replace(/\s+/g, '')
                        },
                        type: "post"
                    },
                    fnDrawCallback: function () {
                        $("#pdf").show();
                    },
                    columns: [
                        {data: 'vehicle', name: 'vehicle'},
                        {data: 'online', name: 'online', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                        {data: 'offline', name: 'offline', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                        {data: 'totalLine', name: 'totalLine', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                        {data: 'pelayanan', name: 'pelayanan', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                        {data: 'tjp', name: 'tjp', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                        {data: 'iuran_wajib', name: 'iuran_wajib', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                        {data: 'pas_pelabuhan', name: 'pas_pelabuhan', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                        {data: 'total', name: 'total', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                        {data: 'tunai', name: 'tunai', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                        {data: 'ePayment', name: 'ePayment', render: $.fn.dataTable.render.number('.', ',', 0, '')}
                    ],
                    fnFooterCallback: function (row, data, start, end, display) {
                        var api = this.api(), data;

                        for (var cols = 1; cols < 11; cols++) {
                            var total = api
                                .column(cols)
                                .data()
                                .reduce(function (a, b) {
                                    return rmDot(a) + rmDot(b);
                                }, 0);

                            $(api.column(cols).footer()).html(
                                formatNumber(total)
                            );
                        }
                    }
                });
            }

        var rmDot = function (i) {
            var clean;
            if (i === '' || i === null) {
                return "";
            }
            if (typeof i === 'number') {
                clean = i;
            } else {
                clean = i.replace(/\./g, "");
            }

            return parseInt(clean);
        };

        function formatNumber(number) {
            var precision = {
                decimal: ",",
                thousand: ".",
                precision: 0,
                format: "%s%v"
            };
            return accounting.formatNumber(number, precision)
        }


      });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MFN\WebServer\laragon\www\ticketing-ms\resources\views/modules/trans/recap.blade.php ENDPATH**/ ?>