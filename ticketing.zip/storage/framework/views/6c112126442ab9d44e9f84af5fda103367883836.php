
<?php $__env->startSection('title'); ?>
 <?php echo e($title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row">
    <div class="col-sm-12">
      <div class="card">
        <div class="card-header b-l-primary">
          <h5>Manage User</h5><span></span>
          <div class="setting-list">
            <i class="icofont icofont-refresh reload-card font-primary"></i>
            <i class="icofont icofont-minus minimize-card font-primary"></i>
          </div>
        </div>
        <div class="card-body">
        <div class="col-sm-12 col-xl-6">
        <div class="row">
                  <div class="col-sm-12">
                    <div class="card">
                      <div class="card-header pb-0">
                        <h5>Update user</h5><span></span>
                      </div>
                      <div class="card-body">
                        <form method="post" action="<?php echo e(route('update-user',$user->USRNM)); ?>">
                        <?php echo csrf_field(); ?>
                          <div class="mb-3">
                            <label class="col-form-label pt-0" for="exampleInputEmail1">Username</label>
                            <input class="form-control" id="exampleInputEmail1" type="text" aria-describedby="emailHelp" value="<?php echo e($user->USRNM); ?>" name="username" placeholder="Enter username"><small class="form-text text-muted" id="emailHelp"></small>
                          </div>
                          <div class="mb-3">
                            <label class="col-form-label pt-0" for="exampleInputEmail1">Fullname</label>
                            <input class="form-control" id="exampleInputEmail1" type="text" aria-describedby="emailHelp" value="<?php echo e($user->FULLNM); ?>" name="fullname" placeholder="Enter password"><small class="form-text text-muted" id="emailHelp"></small>
                          </div>
                          <div class="mb-3">
                            <label class="col-form-label pt-0" for="exampleInputEmail1">Dept</label>
                            <input class="form-control" id="exampleInputEmail1" type="text" aria-describedby="emailHelp"  value="<?php echo e($user->DEPTCD); ?>" name="deptcd" placeholder="Enter Dept"><small class="form-text text-muted" id="emailHelp"></small>
                          </div>
                          <div class="mb-3">
                            <label class="col-form-label pt-0" for="exampleInputEmail1">Password</label>
                            <input class="form-control" id="exampleInputEmail1" type="password" aria-describedby="emailHelp" value="" name="password" placeholder="Enter email"><small class="form-text text-muted" id="emailHelp"></small>
                          </div>
                      </div>
                      <div class="card-footer">
                        <button class="btn btn-primary" type="submit">Submit</button>
                        <button class="btn btn-secondary">Cancel</button>
                      </div>
                    </div>
                    </form>
                  </div>
                </div>
            </div>
        </div>
        </div>
      </div>
    </div>
  </div>
  </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- Plugins JS start-->
    <script src="<?php echo e(asset('assets/js/datatable/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/buttons.colVis.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.autoFill.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/responsive.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.keyTable.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.colReorder.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.fixedHeader.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.rowReorder.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.scroller.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/datatable-prev-next.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/custom.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/accounting.min.js')); ?>"></script>
    
    <script>
      $(document).ready(function(){
        
      });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MFN\WebServer\laragon\www\ticketing-ms\resources\views/modules/manage/edit-user.blade.php ENDPATH**/ ?>