<html>

    <table>
        <tr>
            <th>No</th>
            <th>No</th>
            <th>No</th>
            <th>No</th>
            <th>No</th>
        </tr>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($data->REGNO); ?></td>
            <td><?php echo e($data->REGNO); ?></td>
            <td><?php echo e($data->REGNO); ?></td>
            <td><?php echo e($data->REGNO); ?></td>
            <td><?php echo e($data->REGNO); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</html><?php /**PATH D:\MFN\WebServer\laragon\www\parking-is\resources\views/modules/trans/pdf.blade.php ENDPATH**/ ?>