
<?php $__env->startSection('title'); ?>
 <?php echo e($title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row">
    <div class="col-sm-12">
      <div class="card">
        <div class="card-header b-l-primary">
          <h5> Laporan Rekap Transaksi </h5><span></span>
        </div>
        <div class="card-body">

        <div class="col-sm-12 col-xl-12">
          <div class="card card-absolute">
            <div class="card-header bg-light">
              <h5 class="text-black"><span class="icon-search"></span> Filter Transaksi</h5>
            </div>
            <div class="card-body">
            <form class="needs-validation" novalidate="">
                <div class="row g-3">
                  <div class="col-md-4">
                    <label class="form-label" for="validationCustom04">Lokasi</label>
                        <select class="form-select select2" name="site_id" id="validationCustom04" required="">
                          <option value="">Pilih lokasi...</option>
                          <?php $__currentLoopData = $site; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($site->id); ?>"><?php echo e($site->site_name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    <div class="invalid-feedback">Mohon pilih lokasi.</div>
                  </div>
                  <div class="col-md-4">
                    <label class="form-label" for="validationCustom02">Rentang Tanggal</label>
                    
                    <div class="input-group"><span class="input-group-text"><i class="icofont icofont-ui-calendar"></i></span>
                      <input class="form-control" id="date_ranges" type="text" name="date_range" value="<?php echo e($dateRangeNow); ?>" required="">
                    </div>
                    <div class="invalid-feedback">Mohon pilih rentang tanggal.</div>
                  </div>
                  <div class="col-md-2 mb-3">
                    <label class="form-label" for="validationCustomUsername">&nbsp;</label>
                    <div class="input-group">
                    <button class="btn btn-primary" id="show" type="button">Tampilkan</button>
                    </div>
                  </div>
                  <div class="col-md-2 mb-3">
                      <label class="form-label" for="validationCustomUsername">&nbsp;</label>
                      <div class="input-group">
                      <button class="btn btn-secondary" id="pdf" style="display: none" type="button">
                      <span class="fa fa-file-pdf-o"></span> Pdf</button>
                      </div>
                    </div>
                </div>
               
               
                
              </form>
            </div>
          </div>
        </div>
        
          <div class="dt-ext">
            <div class="box-body" style="display: none">
              <h3 style="text-align: center">Laporan Rekap Transaksi</h3>
              <h4 class="text-center"><span id="info-location"></span></h4>
              <h5 style="text-align: center"><span id="info-date"></span></h5>
              <br>
              <h6><i class="fa fa-bar-chart-o"></i> Rekap Pendapatan</h6>
              <table id="datatable" class="table table-bordered table-hover" width="100%" >
                  <thead>
                  <tr role="row">
                      <th rowspan="3" style="vertical-align: middle; text-align: center;"
                          class="table-center">
                          Kelas Kendaraan
                      </th>
                      <th colspan="4" style="text-align: center;">Total Masuk</th>
                      <th colspan="4" style="text-align: center;">Total Keluar</th>
                      <th rowspan="3" style="text-align: center;vertical-align: middle;">Pendapatan</th>
                      <th rowspan="2" colspan="2" style="vertical-align: middle; text-align: center;">
                          Jenis Pembayaran
                      </th>
                  </tr>
                  <tr role="row">
                      <th style="text-align: center;" colspan="2" class=table-center"> Normal</th>
                      <th style="text-align: center;" colspan="2" class=table-center"> Manual</th>
                      <th style="text-align: center;" colspan="2" class=table-center"> Normal</th>
                      <th style="text-align: center;border-right: 2px solid #e6edef;" colspan="2" class=table-center"> Manual</th>
                  </tr>
                  <tr role="row">
                      <th style="text-align: center;" class=table-center"> Casual</th>
                      <th style="text-align: center;" class=table-center"> Pass</th>
                      <th style="text-align: center;" class=table-center"> Casual</th>
                      <th style="text-align: center;" class=table-center"> Pass</th>

                      <th style="text-align: center;" class=table-center"> Casual</th>
                      <th style="text-align: center;" class=table-center"> Pass</th>
                      <th style="text-align: center;" class=table-center"> Casual</th>
                      <th style="text-align: center;" class=table-center"> Pass</th>

                      <th style="text-align: center;" class=table-center"> Tunai</th>
                      <th style="text-align: center;" class=table-center"> E-Payment</th>
                  </tr>
                  </thead>
                  <tbody></tbody>
                  <tfoot>
                    <tr class="total">
                        <th style="border-top: 2px solid #e6edef;">TOTAL</th>
                        <th style="border-top: 2px solid #e6edef;"></th>
                        <th style="border-top: 2px solid #e6edef;"></th>
                        <th style="border-top: 2px solid #e6edef;"></th>
                        <th style="border-top: 2px solid #e6edef;"></th>
                        <th style="border-top: 2px solid #e6edef;"></th>
                        <th style="border-top: 2px solid #e6edef;"></th>
                        <th style="border-top: 2px solid #e6edef;"></th>
                        <th style="border-top: 2px solid #e6edef;"></th>
                        <th style="border-top: 2px solid #e6edef;"></th>
                        <th style="border-top: 2px solid #e6edef;"></th>
                        <th style="border-top: 2px solid #e6edef;"></th>
                    </tr>
                  </tfoot>
              </table>
              <h6 style="margin-top: 16px;"><i class="fa fa-line-chart"></i> Statistik Lama Parkir Kendaraan</h6>
              <table id="datatable2" class="table table-bordered table-hover">
                  <thead>
                  <tr role="row">
                      <th rowspan="2" style="vertical-align: middle; text-align: center;"
                          class="table-center">
                          Kelas Kendaraan
                      </th>
                      <th colspan="2" style="text-align: center;">0-1 Jam</th>
                      <th colspan="2" style="text-align: center;">1-2 Jam</th>
                      <th colspan="2" style="text-align: center;">2-3 Jam</th>
                      <th colspan="2" style="text-align: center;">3-4 Jam</th>
                      <th colspan="2" style="text-align: center;">4-5 Jam</th>
                      <th colspan="2" style="text-align: center;">5-6 Jam</th>
                      <th colspan="2" style="text-align: center;">Lebih dari 6 Jam</th>
                  </tr>
                  <tr role="row">
                                                          <th style="text-align: center;">Pass</th>
                          <th style="text-align: center;">Casual</th>
                                                          <th style="text-align: center;">Pass</th>
                          <th style="text-align: center;">Casual</th>
                                                          <th style="text-align: center;">Pass</th>
                          <th style="text-align: center;">Casual</th>
                                                          <th style="text-align: center;">Pass</th>
                          <th style="text-align: center;">Casual</th>
                                                          <th style="text-align: center;">Pass</th>
                          <th style="text-align: center;">Casual</th>
                                                          <th style="text-align: center;">Pass</th>
                          <th style="text-align: center;">Casual</th>
                                                          <th style="text-align: center;">Pass</th>
                          <th style="text-align: center;">Casual</th>
                                                  </tr>
                  </thead>
                  <tbody></tbody>
                  <tfoot>
                  <tr class="total">
                      <th style="border-top: 2px solid #e6edef;">TOTAL</th>
                      <th style="border-top: 2px solid #e6edef;"></th>
                      <th style="border-top: 2px solid #e6edef;"></th>
                      <th style="border-top: 2px solid #e6edef;"></th>
                      <th style="border-top: 2px solid #e6edef;"></th>
                      <th style="border-top: 2px solid #e6edef;"></th>
                      <th style="border-top: 2px solid #e6edef;"></th>
                      <th style="border-top: 2px solid #e6edef;"></th>
                      <th style="border-top: 2px solid #e6edef;"></th>
                      <th style="border-top: 2px solid #e6edef;"></th>
                      <th style="border-top: 2px solid #e6edef;"></th>
                      <th style="border-top: 2px solid #e6edef;"></th>
                      <th style="border-top: 2px solid #e6edef;"></th>
                      <th style="border-top: 2px solid #e6edef;"></th>
                      <th style="border-top: 2px solid #e6edef;"></th>
                  </tr>
                  </tfoot>
              </table>
          </div><!-- /.box-body -->
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- Plugins JS start-->
    <script src="<?php echo e(asset('assets/js/datatable/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/buttons.colVis.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.autoFill.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/responsive.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.keyTable.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.colReorder.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.fixedHeader.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.rowReorder.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.scroller.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/datatable-prev-next.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/custom.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/accounting.min.js')); ?>"></script>
    
    <script src="<?php echo e(asset('assets/js/form-validation-custom.js')); ?>"></script>

    <script>
      $(document).ready(function(){

        var site = $('select[name=site_id]');
        var range = $('input[name=date_range]');

        moment.locale("id");
        $('.select2').select2();

        $('#show').click(function (event) {
            event.preventDefault();

            if (site.val() === "" || range.val().length === 0) {
                swalNotify("Oops!","Parameter lokasi harus diisi.","warning");
                return false;
            }

            $(".box-body").show();
            datatable();
            datatableVehicleDuration();
            setLabel();
        });

        
        $('#date_ranges').daterangepicker({
                'dateLimit': {
                    'month': 1
                },
                'autoApply': true,
                'startDate': moment().startOf('month'),
                'endDate': moment().endOf('month'),
                'locale': {
                    "format": 'DD/MM/YYYY',
                    "applyLabel": "Apply",
                    "cancelLabel": "Cancel",
                    "fromLabel": "Dari",
                    "toLabel": "Sampai",
                    "customRangeLabel": "Custom",
                    "daysOfWeek": [
                        "Mg",
                        "Sn",
                        "Sl",
                        "Rb",
                        "Km",
                        "Jm",
                        "Sb"
                    ],
                    "monthNames": [
                        "Januari",
                        "Februari",
                        "Maret",
                        "April",
                        "Mei",
                        "Juni",
                        "Juli",
                        "Agustus",
                        "September",
                        "Oktober",
                        "November",
                        "Desember"
                    ],
                    "firstDay": 1
                },
                'format': 'DD-MM-YYYY'
            });


        $('#pdf').click(function () {
            event.preventDefault();
            var site = $('select[name=site_id]').val();
            var range = $('input[name=date_range]').val().split('-');

            if (site == "" || range == "") {
                $('#alert-filter').show().delay(3000).fadeOut('slow');
                return false;
            }

            var param = {
                site: site,
                start: range[0].replace(/\s+/g, ''),
                end: range[1].replace(/\s+/g, ''),
            };

            var url = "<?php echo e(url('parking-recap-pdf')); ?>" + "?" + $.param(param);
            window.open(url, "_blank");
        });

        function setLabel() {
                var location = $('select[name=site_id] :selected').text();
                var date = range.val();
                $('#info-location').text('').text(location);
                $('#info-date').text('').text(date);
            }


            function datatable() {
                var rangeExplode = range.val().split('-');

                var targets = [1, 2, 3, 4, 5, 6, 7, 8, 10, 11];

                return oTable = $('#datatable').DataTable({
                    "bPaginate": false,
                    "bLengthChange": true,
                    "bFilter": false,
                    "bSort": false,
                    "responsive": true,
                    "bInfo": false,
                    "bAutoWidth": true,
                    "processing": true,
                    "bDestroy": true,
                    "serverSide": true,
                    "columnDefs": [
                        {"className": "dt-right", "targets": targets},
                        {"className": "aright", "targets": [9]}
                    ],
                    "ajax": {
                        url: "<?php echo e(route('ajax-recap-transaction')); ?>",
                        data: function (d) {
                            d.site = site.val(),
                            d.start = rangeExplode[0].replace(/\s+/g, ''),
                            d.end = rangeExplode[1].replace(/\s+/g, '')
                        },
                        type: "post"
                    },
                    fnDrawCallback: function () {
                        $("#pdf").show();
                    },
                    columns: [
                        {data: 'vehicle', name: 'vehicle'},
                        {data: 'casualIn', name: 'casualIn', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                        {data: 'passIn', name: 'passIn', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                        {data: 'manualCasualIn', name: 'manualCasualIn', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                        {data: 'manualPassIn', name: 'manualPassIn', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                        {data: 'casualOut', name: 'casualOut', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                        {data: 'passOut', name: 'passOut', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                        {data: 'manualCasualOut', name: 'manualCasualOut', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                        {data: 'manualPassOut', name: 'manualPassOut', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                        {data: 'pendapatan', name: 'pendapatan', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                        {data: 'tunai', name: 'tunai', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                        {data: 'ePayment', name: 'ePayment', render: $.fn.dataTable.render.number('.', ',', 0, '')}
                    ],
                    fnFooterCallback: function (row, data, start, end, display) {
                        var api = this.api(), data;

                        for (var cols = 1; cols < 12; cols++) {
                            var total = api
                                .column(cols)
                                .data()
                                .reduce(function (a, b) {
                                    return rmDot(a) + rmDot(b);
                                }, 0);

                            $(api.column(cols).footer()).html(
                                formatNumber(total)
                            );
                        }
                    }
                });
            }

            function datatableVehicleDuration() {
                var rangeExplode = range.val().split('-');

                var targets = [];
                for (var i = 1; i < 15; i++) {
                    targets.push(i);
                }

                return oTable = $('#datatable2').DataTable({
                    "bPaginate": false,
                    "bLengthChange": true,
                    "bFilter": false,
                    "responsive": true,
                    "bSort": false,
                    "bInfo": false,
                    "bAutoWidth": true,
                    "processing": true,
                    "bDestroy": true,
                    "serverSide": true,
                    "columnDefs": [
                        {"className": "dt-right", "targets": targets},
                    ],
                    "ajax": {
                        url: "<?php echo e(route('ajax-recap-statistic')); ?>",
                          data: function (d) {
                              d.site = site.val(),
                              d.start = rangeExplode[0].replace(/\s+/g, ''),
                              d.end = rangeExplode[1].replace(/\s+/g, '')
                          },
                          type: "post"
                    },
                    fnDrawCallback: function () {
                        $("#pdf").show();
                    },
                    columns: [
                        {data: 'vehicle', name: 'vehicle', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                        {data: 'pass1', name: 'pass1', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                        {data: 'casual1', name: 'casual1', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                        {data: 'pass2', name: 'pass2', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                        {data: 'casual2', name: 'casual2', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                        {data: 'pass3', name: 'pass3', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                        {data: 'casual3', name: 'casual3', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                        {data: 'pass4', name: 'pass4', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                        {data: 'casual4', name: 'casual4', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                        {data: 'pass5', name: 'pass5', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                        {data: 'casual5', name: 'casual5', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                        {data: 'pass6', name: 'pass6', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                        {data: 'casual6', name: 'casual6', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                        {data: 'pass7', name: 'pass7', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                        {data: 'casual7', name: 'casual7', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                       
                    ],
                    fnFooterCallback: function (row, data, start, end, display) {
                        var api = this.api(), data;

                        $.each(targets, function (key, cols) {
                            console.log(cols);
                            var total = api
                                .column(cols)
                                .data()
                                .reduce(function (a, b) {
                                    return rmDot(a) + rmDot(b);
                                }, 0);

                            $(api.column(cols).footer()).html(
                                formatNumber(total)
                            );
                        });
                    }
                });
            }


        var rmDot = function (i) {
            var clean;
            if (i === '' || i === null) {
                return "";
            }
            if (typeof i === 'number') {
                clean = i;
            } else {
                clean = i.replace(/\./g, "");
            }

            return parseInt(clean);
        };

        function formatNumber(number) {
            var precision = {
                decimal: ",",
                thousand: ".",
                precision: 0,
                format: "%s%v"
            };
            return accounting.formatNumber(number, precision)
        }


      });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MFN\WebServer\laragon\www\parking-is\resources\views/modules/trans/recap.blade.php ENDPATH**/ ?>