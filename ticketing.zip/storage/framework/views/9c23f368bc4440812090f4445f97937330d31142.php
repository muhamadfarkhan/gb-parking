
<?php $__env->startSection('title'); ?>
 <?php echo e($title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row">
    <div class="col-sm-12">
      <div class="card">
        <div class="card-header b-l-primary">
          <h5>Daftar Tarif</h5><span></span>
          <!-- <div class="setting-list" style="right: 190px;">
            <i class="icofont icofont-refresh reload-card font-primary"></i>
            <i class="icofont icofont-minus minimize-card font-primary"></i>
          </div> -->
        </div>
        <div class="card-body">
        
        <div style="position: absolute;right: 18px;top: 17px;float: right;">
          <a class="btn btn-primary btn-sm" href="<?php echo e(route('create-tarif')); ?>" data-bs-original-title="" title=""> <span class="icon-plus"></span> Create New</a>
        </div>
        <div class="row">
          <div class="col-sm-12">
            <div class="card">
              <div class="card-body">
                <div class="dt-ext">
                  <table class="display" id="custom-datatable">
                    <thead>
                    <tr role="row">
                      <th rowspan="2" style="vertical-align: middle; text-align: center;"
                          class="table-center">
                          Kode
                      </th>
                      <th rowspan="2" style="vertical-align: middle; text-align: center;"
                          class="table-center">
                          Jenis Tiket
                      </th>
                      <th colspan="2" style="text-align: center;">Pelayaran</th>
                      <th rowspan="2" style="text-align: center;">IW</th>
                      <th rowspan="2" style="text-align: center;vertical-align: middle">Pas Pelabuhan</th>
                      <th rowspan="2" style="vertical-align: middle; text-align: center;">Total Terpadu</th>
                      <th rowspan="2" style="vertical-align: middle; text-align: center;">Action</th>
                  </tr>
                  <tr role="row">
                      <th style="text-align: center;" class="table-center"> Pelayanan</th>
                      <th style="text-align: center;" class="table-center"> TJP</th>
                  </tr>                 
                    </thead>
                    <tbody>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
          
        </div>
        </div>
      </div>
    </div>
  </div>
  </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- Plugins JS start-->
    <script src="<?php echo e(asset('assets/js/datatable/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/buttons.colVis.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.autoFill.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/responsive.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.keyTable.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.colReorder.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.fixedHeader.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.rowReorder.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.scroller.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/datatable-prev-next.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/custom.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/accounting.min.js')); ?>"></script>
    
    <script>
      $(document).ready(function(){
        
        moment.locale("id");

        var table = null;
        var targets = [2,3,4,5,6];

        table = $('#custom-datatable').DataTable( {
            processing: true,
            serverSide: true,
            responsive: true,
            bDestroy: true,
			aaSorting: [[0, 'asc']],
            columnDefs: [
                        {"className": "dt-right", "targets": targets}
                    ],
            ajax: { 
                    url: "<?php echo e(route('ajax-list-tarif')); ?>",
                    type: "post" 
                  },
            columns: [
                {data: 'VEHCLASS', name: 'VEHCLASS'},
                {data: 'WALKDES', name: 'walkdes'},
                {data: 'pelayanan', name: 'pelayanan'},
                {data: 'tjp', name: 'tjp'},
                {data: 'iuran_wajib', name: 'iuran_wajib'},
                {data: 'pas_pelabuhan', name: 'pas_pelabuhan'},
                {data: 'total', name: 'total'},
                {data: 'action', name: 'action'}
            ]   
        });

      });

      function editRow(id){
          window.location.href = '<?php echo e(url('/update-biaya')); ?>'+'/'+id;
        }

        function deleteRow(id){
            swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover this!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    window.location.href = '<?php echo e(url('/delete-tarif')); ?>'+'/'+id;
                }
            })
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ticketing/resources/views/modules/manage/tarif.blade.php ENDPATH**/ ?>