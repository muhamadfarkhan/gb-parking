<!DOCTYPE html>
<html>
<head>

	<style>
	
        * {
            font-size: 10px;
            font-family: Arial;
        }

        th {
            width:100%;
            text-align:center;
        }

        .aright{
            text-align:right;
        }

        table, td, th {
            border: 1px solid #ddd;;
        }

        table {
            border-collapse: collapse;
            width: 100%;
        }

	</style>
</head>
<body>
	<div class="container">
	

        <header>
        <p align="center"> <b style="font-size: 1.5em;">LAPORAN TRANSAKSI HARIAN</b> </p>
    <p align="center" style="font-size: 18px;"> <?php echo e(strtoupper($site->site_name)); ?> </p>
    <table style="border: 0px;width: 70%;">
        <tr>
            <td style="border: 0px;width: 15%;">Tgl Transaksi</td>
            <td style="border: 0px;width: 25%;">: <?php echo e($tgl); ?></td>
            <td style="border: 0px;width: 15%;">Jenis Pembayaran</td>
            <td style="border: 0px;width: 25%;">: All</td>
        </tr>
        <tr>
            <td style="border: 0px;">Jam Transaksi</td>
            <td style="border: 0px;">: <?php echo e($jam); ?></td>
            <td style="border: 0px;">Kondisi</td>
            <td style="border: 0px;">: Masih Parkir</td>
        </tr>
        <tr>
            <td style="border: 0px;">Jenis Kendaraan</td>
            <td style="border: 0px;">: All</td>
            <td style="border: 0px;">Sory By</td>
            <td style="border: 0px;">: Waktu Masuk</td>
        </tr>
    </table>
    <br>
    <br>
        </header>

        <footer>
           
        </footer>

        <main>
	
	<!-- Here pure-table class is used -->
	<table style="border: 1px solid #ddd;">
		<thead>
		<tr>
			<th style="width:10%">No</th>
			<th style="width:15%">Kendaraan</th>
			<th style="width:15%">No. Plat</th>
			<th style="width:15%">No. Pass</th>
			<th style="width:25%">Waktu Masuk</th>
            <th style="width:5%">Disp</th>
			<th style="width:25%">Waktu Keluar</th>
			<th style="width:10%">User</th>
			<th style="width:15%">Biaya</th>
			<th style="width:25%">Jenis Pembayaran</th>
		</tr>
		</thead>

		<tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($data->biaya->WALKDES); ?></td>
                    <td><?php echo e($data->REGNO); ?></td>
                    <td><?php echo e($data->PASSNO); ?></td>
                    <td><?php echo e($data->DATETIMEIN); ?></td>
                    <td><?php echo e($data->VEHCLASS); ?></td>
                    <td><?php echo e($data->DATETIMEOUT); ?></td>
                    <td><?php echo e($data->USRNMA); ?></td>
                    <td class="aright"><?php echo e(number_format($data->TRANFEE,0,'','.')); ?></td>
                    <td>
                    <?php
                    if ($data->TRANPAY == "E") {
                        echo "E-Payment";
                    } elseif ($data->TRANPAY == "C") {
                        echo "Cash";
                    } elseif ($data->TRANPAY == "P") {
                        echo "Member";
                    } elseif ($data->TRANPAY == "O") {
                        echo "Online";
                    } elseif ($data->TRANPAY == "V") {
                        echo "Voucher";
                    } ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		</tbody>
	</table>
                </main>
	</div>
</body>
</html>
<?php /**PATH D:\MFN\WebServer\laragon\www\parking-is\resources\views/modules/trans/pdfParking.blade.php ENDPATH**/ ?>