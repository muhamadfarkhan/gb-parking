<!DOCTYPE html>
<html>
<head>

	<style>
	
        * {
            font-size: 10px;
            font-family: Arial;
        }

        th {
            width:100%;
            text-align:center;
        }

        .aright{
            text-align:right;
        }

        table, td, th {
            border: 1px solid #ddd;;
        }

        table {
            border-collapse: collapse;
            width: 100%;
        }

	</style>
</head>
<body>
	<div class="container">
	

        <header>
        <p align="center"> <b style="font-size: 1.5em;">LAPORAN DATA VIP</b> </p>
    

    <br>
        </header>

        <footer>
           
        </footer>

        <main>
	
	<!-- Here pure-table class is used -->
	<table style="border: 1px solid #ddd;">
		<thead>
		<tr>
			<th style="width:5%">No</th>
			<th style="width:10%">Nama</th>
			<th style="width:15%">Keterangan</th>
            <th style="width:15%">No. Plat</th>
			<th style="width:35%">Masa berlaku</th>
		</tr>
		</thead>

		<tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($data->PASSNO); ?></td>
                    <td><?php echo e($data->WSID); ?></td>
                    <td><?php echo e($data->REGNO); ?></td>
                    <td><?php echo e($data->STARTDATE); ?> s/d <?php echo e($data->ENDDATE); ?></td>
                   
                    
                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		</tbody>
      
	</table>
                </main>
	</div>
</body>
</html>

<?php /**PATH /var/www/html/ticketing/resources/views/modules/trans/pdfVip.blade.php ENDPATH**/ ?>