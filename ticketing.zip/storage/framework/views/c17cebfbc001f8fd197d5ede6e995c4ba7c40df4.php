
<?php $__env->startSection('title'); ?>
 <?php echo e($title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid dashboard-default-sec">
  <div class="row">
    <div class="col-xl-12 box-col-12 des-xl-100"> 
      <div class="row">
        <div class="col-sm-6 col-xl-4 col-lg-6">
          <div class="card o-hidden border-0">
            <div class="bg-primary b-r-4 card-body">
              <div class="media static-top-widget">
                <div class="align-self-center text-center"><i data-feather="dollar-sign"></i></div>
                <div class="media-body"><span class="m-0">Pendapatan Hari Ini</span>
                  <h4 class="mb-0"><div class="blink_me"><?php echo e(number_format($totalIncomeToday,0,",",".")); ?></div></h4><i class="icon-bg" data-feather="dollar-sign"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-xl-4 col-lg-6">
          <div class="card o-hidden border-0">
            <div class="bg-secondary b-r-4 card-body">
              <div class="media static-top-widget">
                <div class="align-self-center text-center"><i data-feather="airplay"></i></div>
                <div class="media-body"><span class="m-0">Total Kendaraan Masuk Hari Ini</span>
                  <h4 class="mb-0 counter"><?php echo e(number_format($totalInToday,0,",",".")); ?></h4><i class="icon-bg" data-feather="airplay"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-xl-4 col-lg-6">
          <div class="card o-hidden border-0">
            <div class="bg-danger b-r-4 card-body">
              <div class="media static-top-widget">
                <div class="align-self-center text-center"><i data-feather="log-out"></i></div>
                <div class="media-body"><span class="m-0">Total Kendaraan Keluar Hari Ini</span>
                  <h4 class="mb-0 counter"><?php echo e(number_format($totalOutToday,0,",",".")); ?></h4><i class="icon-bg" data-feather="log-out"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-xl-4 col-lg-6">
          <div class="card o-hidden border-0">
            <div class="bg-warning b-r-4 card-body">
              <div class="media static-top-widget">
                <div class="align-self-center text-center"><i data-feather="list"></i></div>
                <div class="media-body"><span class="m-0">Motor Keluar Hari Ini</span>
                  <h4 class="mb-0 counter"><?php echo e(number_format($totalOutMotorToday,0,",",".")); ?></h4><i class="icon-bg" data-feather="list"></i>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="col-sm-6 col-xl-4 col-lg-6">
          <div class="card o-hidden border-0">
            <div class="bg-success b-r-4 card-body">
              <div class="media static-top-widget">
                <div class="align-self-center text-center"><i data-feather="map"></i></div>
                <div class="media-body"><span class="m-0">Mobil Keluar Hari ini</span>
                  <h4 class="mb-0 counter"><?php echo e(number_format($totalOutMobilToday,0,",",".")); ?></h4><i class="icon-bg" data-feather="map"></i>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="col-sm-6 col-xl-4 col-lg-6">
          <div class="card o-hidden border-0">
            <div class="bg-info b-r-4 card-body">
              <div class="media static-top-widget">
                <div class="align-self-center text-center"><i data-feather="truck"></i></div>
                <div class="media-body"><span class="m-0">Truck/Box Keluar Hari Ini</span>
                  <h4 class="mb-0 counter"><?php echo e(number_format($totalOutBoxToday,0,",",".")); ?></h4><i class="icon-bg" data-feather="truck"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row" style="margin-bottom: 16px;">
        <div class="col-md-4 offset-md-4">
          <div class="input-group"><span class="input-group-text"><i class="icofont icofont-ui-calendar"></i></span>
                  <input class="form-control daterange" id="date" type="text" name="date_range" value="20/11/2022" required="">
                </div>
        </div>
    </div>


    <div class="col-xl-12 box-col-12 des-xl-100 dashboard-sec">
      <div class="card income-card">
        <div class="card-header">
          <div class="header-top d-sm-flex align-items-center">
            <h5>Grafik Pendapatan</h5>
            <div class="center-content">
              <p class="d-sm-flex align-items-center"><span class="font-primary m-r-10 f-w-700"><strong>Laporan Pendapatan Sistem - Tanggal : </strong></span>
              <span id="label-total-weekly"></span>
            </p>
            </div>
            <div class="setting-list">
              
              <i class="icofont icofont-minus minimize-card font-primary"></i>
              <i class="icofont icofont-refresh reload-card font-primary"></i>
              
            </div>
          </div>
        </div>
        <div class="card-body" style="margin-left: 30px;margin-top: 20px;">
        <div id="loading-chart-total-weekly" style="text-align: center; display: none;">
                              <i class="fa fa-spin fa-2x fa-refresh"></i>
                          </div>
          <div id="total-weekly-chart"></div>
        </div>
        <div class="card-body grid-showcase grid-align">
        <div class="row align-items-center" style="min-height:10px; margin-botton: 0px;">
            <div class="col"><span><h6 id="info-weekly-actual"></h6>Total Pendapatan</span></div>
            <div class="col"><span><h6 id="info-weekly-cash"></h6>Pendapatan Tunai</span></div>
            <div class="col"><span><h6 id="info-weekly-emoney"></h6>Pendapatan E-Payment</span></div>
          </div>
          </div>
      </div>
    </div>

    <div class="col-xl-12 box-col-12 des-xl-100 dashboard-sec">
      <div class="card income-card">
        <div class="card-header">
          <div class="header-top d-sm-flex align-items-center">
            <h5> Grafik Rata-rata Pendapatan Parkir Per Jam</h5>
            <div class="center-content">
              <p class="d-sm-flex align-items-center"><span class="font-primary m-r-10 f-w-700" id="label-average"></span></p>
            </div>
            <div class="setting-list">
              
              <i class="icofont icofont-minus minimize-card font-primary"></i>
              <i class="icofont icofont-refresh reload-card font-primary"></i>
              
            </div>
          </div>
        </div>
        <div class="card-body" style="margin-left: 30px;margin-top: 20px;">
        <div id="loading-chart-average" style="text-align: center; display: none;">
                              <i class="fa fa-spin fa-2x fa-refresh"></i>
                          </div>
          <div id="average-chart"></div>
        </div>
      </div>
    </div>
    
    <div class="col-xl-12 box-col-12 des-xl-100">
      <div class="row">
        <div class="col-xl-8 box-col-12 des-xl-50">
          <div class="card">
            <div class="card-header">
              <div class="header-top d-sm-flex align-items-center">
                <h5> Grafik Rata-rata Lalu Lintas Kendaraan Per Jam</h5>
                <div class="center-content">
                  <p><span id="label-vehicle"></span></p>
                </div>
                <div class="setting-list">
                  
                    <i class="icofont icofont-minus minimize-card font-primary"></i>
                    <i class="icofont icofont-refresh reload-card font-primary"></i>
                  
                </div>
              </div>
            </div>
            <div class="card-body p-0">
            <div id="loading-chart-vehicle" style="text-align: center; display: none;">
                  <i class="fa fa-spin fa-2x fa-refresh"></i>
              </div>
              <div id="vehicle-chart"></div>
              
            </div>
          </div>
        </div>
        <div class="col-xl-4 box-col-12 des-xl-50">
          <div class="card trasaction-sec">
            <div class="card-header">
              <div class="header-top d-sm-flex align-items-center">
                <h5> Persentase Kendaraan</h5>
                <div class="center-content">
                  <p><span id="label-quantity"></span></p>
                </div>
                <div class="setting-list">
                  
                    <i class="icofont icofont-minus minimize-card font-secondary"></i>
                    <i class="icofont icofont-refresh reload-card font-secondary"></i>
                    
                </div>
              </div>
            </div>
            <div class="card-body p-0">
              <div id="loading-chart-quantity" style="text-align: center; display: none;">
                  <i class="fa fa-spin fa-2x fa-refresh"></i>
              </div>
              <div id="quantity-chart"></div>
              
            </div>
            
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script src="<?php echo e(asset('assets/js/chart/google/google-chart-loader.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/accounting.min.js')); ?>"></script>

<script>
google.charts.load('current', {packages: ['corechart', 'bar']});
google.charts.load('current', {'packages':['line']});
google.charts.load('current', {'packages':['corechart']});
//google.charts.setOnLoadCallback(drawBasic);

function formatNumber(number, currency) {
    var currency = typeof currency !== 'undefined' ? currency : true;
    var withCurrency = currency == true ? 'Rp' : '';


    return accounting.formatMoney(number, withCurrency, 0, ".", ",");
}

$('#date')
  .daterangepicker({
      'dateLimit': {
          'days': 6
      },
      'autoApply': true,
      'endDate': moment(),
      'startDate': moment().subtract(6, 'days'),
      'locale': {
          format: 'DD/MM/YYYY'
      }
  })
  .on('change', function () {
      var param = getParameter();
      incomeWeeklyChart(param);
      averageChart(param);
      vehicleChart(param);
      quantityChart(param);
      // incomeActualWeeklyChart(param);
  });

  var param = getParameter();
  incomeWeeklyChart(param);
  averageChart(param);
  vehicleChart(param);
  quantityChart(param);

  function getParameter() {
      var params = {
          date: $("#date").val()
      };

      return $.param(params);
  }


  function incomeWeeklyChart(params) {
      $("#label-total-weekly").text($("#date").val());
      $("#loading-chart-total-weekly").show();

      google.charts.setOnLoadCallback(function () {
          $.post("<?php echo e(route('total-weekly-chart')); ?>", params, function (result) {

              var data = google.visualization.arrayToDataTable(result.data);
              var formatter = new google.visualization.NumberFormat({
                  prefix: 'Rp',
                  negativeColor: 'red',
                  negativeParens: false,
                  fractionDigits: 0,
                  groupingSymbol: "."
              });
              formatter.format(data, 1);

              var options = {
                  legend: {position: 'none'},
                  axes: {
                      x: {
                          0: {label: ''}
                      }
                  },
                  vAxis: {gridlines: {count: 4}},
                  colors: ['#1b9e77'],
                  bars: 'vertical'
              };

              var chart = new google.charts.Bar(document.getElementById('total-weekly-chart'));

              chart.draw(data, options);

              $("#loading-chart-total-weekly").delay(300).fadeOut("slow");
              $("#info-weekly-actual").text("Rp" + formatNumber(result.info.total, false));
              $("#info-weekly-cash").text("Rp" + formatNumber(result.info.cash, false));
              $("#info-weekly-emoney").text("Rp" + formatNumber(result.info.epayment, false));
          })
              .error(function () {
                  window.location.reload();
              });
      });
  }

  function averageChart(params) {
    $("#label-average").text($("#date").val());
    $("#loading-chart-average").show();

    google.charts.setOnLoadCallback(function () {
        $.post("<?php echo e(route('average-chart')); ?>", params, function (result) {

            var data = google.visualization.arrayToDataTable(result.data);

            var options = {
                legend: {position: 'none'},
                axes: {
                    x: {
                        0: {label: ''}
                    }
                },
                colors: ['rgb(219, 68, 55)'],
                bars: 'vertical'
            };

            var chart = new google.charts.Bar(document.getElementById('average-chart'));

            chart.draw(data, options);

            $("#loading-chart-average").delay(300).fadeOut("slow");
        })
            .error(function () {
                window.location.reload();
            });
    });

  }

  function vehicleChart(params) {
    $("#label-vehicle").text($("#date").val());
    $("#loading-chart-vehicle").show();

    google.charts.setOnLoadCallback(function () {
        $.post("<?php echo e(route('vehicle-chart')); ?>", params, function (result) {
            var data = new google.visualization.DataTable();
            data.addColumn('string', 'Jam');
            data.addColumn('number', 'Masuk');
            data.addColumn('number', 'Keluar');
            data.addRows(result);

            var options = {
                legend: {position: 'none'},
                axes: {
                    x: {
                        0: {label: ''}
                    }
                }
            };

            var chart = new google.charts.Line(document.getElementById('vehicle-chart'));

            chart.draw(data, options);

            $("#loading-chart-vehicle").delay(300).fadeOut("slow");
        })
            .error(function () {
                window.location.reload();
            });
    });
}

    function quantityChart(params) {
      $("#label-quantity").text($("#date").val());
      $("#loading-chart-quantity").show();
   
      google.charts.setOnLoadCallback(function () {
          $.post("<?php echo e(route('quantity-chart')); ?>", params, function (result) {
              var data = google.visualization.arrayToDataTable(result.data);

              var options = {
                  legend: 'bottom',
                  pieSliceText: 'label',
                  pieStartAngle: 100,
              };

              var chart = new google.visualization.PieChart(document.getElementById('quantity-chart'));
              chart.draw(data, options);

              $("#loading-chart-quantity").delay(300).fadeOut("slow");
          })
              .error(function () {
                  window.location.reload();
              });
      });
    }

function drawBasic() {
  params = "test";
  $.post("<?php echo e(route('total-weekly-chart')); ?>", params, function (result) {
    var a = google.visualization.arrayToDataTable(result.data),
        b = {
          legend: {position: 'none'},
          axes: {
              x: {
                  0: {label: ''}
              }
          },
          vAxis: {gridlines: {count: 4}},
          colors: [vihoAdminConfig.primary, vihoAdminConfig.primary, "#e2c636"],
          bars: 'vertical'


        },
      c = new google.charts.Bar(document.getElementById("total-weekly-chart"));

      var formatter = new google.visualization.NumberFormat({
                        prefix: 'Rp ',
                        negativeColor: 'red',
                        negativeParens: false,
                        fractionDigits: 0,
                        groupingSymbol: "."
                    });
                    formatter.format(a, 1);
      
      c.draw(a, google.charts.Bar.convertOptions(b))
    });

    $.post("<?php echo e(route('average-chart')); ?>", params, function (result) {
    var a = google.visualization.arrayToDataTable(result.data),
        b = {
          legend: {position: 'none'},
          axes: {
              x: {
                  0: {label: ''}
              }
          },
          vAxis: {gridlines: {count: 4}},
          colors: [vihoAdminConfig.primary, vihoAdminConfig.primary, "#e2c636"],
          bars: 'vertical'


        },
      c = new google.charts.Bar(document.getElementById("average-chart"));

      var formatter = new google.visualization.NumberFormat({
                        prefix: 'Rp ',
                        negativeColor: 'red',
                        negativeParens: false,
                        fractionDigits: 0,
                        groupingSymbol: "."
                    });
                    formatter.format(a, 1);
      
      c.draw(a, google.charts.Bar.convertOptions(b))
    });

    $.post("<?php echo e(route('quantity-chart')); ?>", params, function (result) {
    var a = google.visualization.arrayToDataTable(result.data),
        b = {
          legend: 'bottom',
          pieSliceText: 'label',
          pieStartAngle: 100,
        },
      c = new google.visualization.PieChart(document.getElementById("quantity-chart"));
      
      c.draw(a, google.charts.Bar.convertOptions(b))
    });
        
    $.post("<?php echo e(route('vehicle-chart')); ?>", params, function (result) {
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Jam');
        data.addColumn('number', 'Masuk');
        data.addColumn('number', 'Keluar');
        data.addRows(result);

        var options = {
            legend: {position: 'none'},
            axes: {
                x: {
                    0: {label: ''}
                }
            }
        };

        var chart = new google.charts.Line(document.getElementById('vehicle-chart'));

        chart.draw(data, options);

        $("#loading-chart-vehicle").delay(300).fadeOut("slow");
    })
    .error(function () {
        window.location.reload();
    });

}


</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MFN\WebServer\laragon\www\parking-is\resources\views/layouts/dashboard.blade.php ENDPATH**/ ?>