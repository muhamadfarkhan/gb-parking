
<?php $__env->startSection('title'); ?>
 <?php echo e($title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row">
    <div class="col-sm-12">
      <div class="card">
        <div class="card-header b-l-primary">
          <h5>Daftar Transaksi Parkir</h5><span></span>
          <div class="setting-list">
            <i class="icofont icofont-refresh reload-card font-primary"></i>
            <i class="icofont icofont-minus minimize-card font-primary"></i>
          </div>
        </div>
        <div class="card-body">

          <div class="col-sm-12 col-xl-12">
            <div class="card card-absolute">
              <div class="card-header bg-light">
                <h5 class="text-black"><span class="icon-search"></span> Filter Transaksi</h5>
              </div>
              <div class="card-body">
              <form class="needs-validation" novalidate="">
                  <div class="row g-3">
                    
                    <div class="col-md-6">
                      <label class="form-label" for="validationCustom04">Lokasi</label>
                          <select class="form-select select2" name="site_id" id="validationCustom04" required="">
                            <option value="">Pilih lokasi...</option>
                            <?php $__currentLoopData = $site; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($site->id); ?>"><?php echo e($site->site_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                      <div class="invalid-feedback">Mohon pilih lokasi.</div>
                    </div>

                    <div class="col-md-6">
                      <label class="form-label" for="validationCustom04">Jenis Laporan</label>
                        <select class="form-select select2" name="report_type" id="validationCustom04" required="">
                          <option value=""> -- Pilih Jenis Laporan --</option>
                          <option value="day"> Komparasi Harian</option>
                          <option value="week"> Komparasi Mingguan</option>
                          <option value="month"> Komparasi Bulanan</option>
                        </select>
                      <div class="invalid-feedback">Mohon pilih lokasi.</div>
                    </div>
                    </div>
                    <div class="row" style="margin-top: 24px;">
                    <div class="col-md-3">
                      <label class="form-label" for="validationCustom04">Tahun</label>
                      <select class="form-select select2" name="year" id="validationCustom04" required="">
                            <option value="<?php echo e(date('Y')); ?>"> <?php echo e(date('Y')); ?></option>
                            <?php for($i=1; $i<=3; $i++): ?>
                              <option value="<?php echo e($i); ?>"><?php echo e(date("Y",strtotime("-$i year"))); ?></option>
                            <?php endfor; ?>
                            </select>
                      <div class="invalid-feedback">Mohon pilih lokasi.</div>
                    </div>
                    <div class="col-md-3">
                      <label class="form-label" for="validationCustom04">Bulan</label>
                          <select class="form-select select2" name="month" id="validationCustom04" required="">
                            <?php for($i=1; $i<=12; $i++): ?>
                              <option value="<?php echo e($i); ?>"
                                  <?php if($i == date('m')): ?>
                                    selected
                                  <?php endif; ?>  
                              ><?php echo e(date('F', mktime(0, 0, 0, $i, 10))); ?></option>
                            <?php endfor; ?>
                            </select>
                      <div class="invalid-feedback">Mohon pilih lokasi.</div>
                    </div>

                    <div class="col-md-2">
                      <label class="form-label" for="validationCustom04" id="label-day">Day</label>
                          <select class="form-select select2" name="day" id="validationCustom04" required="">
                           
                            </select>
                      <div class="invalid-feedback">Mohon pilih lokasi.</div>
                    </div>
                    <div class="col-md-2 mb-3">
                      <label class="form-label" for="validationCustomUsername">&nbsp;</label>
                      <div class="input-group">
                      <button class="btn btn-primary" id="show" type="button">Tampilkan</button>
                      </div>
                    </div>
                    <div class="col-md-2 mb-3">
                      <label class="form-label" for="validationCustomUsername">&nbsp;</label>
                      <div class="input-group">
                      <button class="btn btn-secondary" id="pdf" style="display: none" type="button">
                      <span class="fa fa-file-pdf-o"></span> Pdf</button>
                      </div>
                    </div>
                  </div>
                
                
                  
                </form>
              </div>
            </div>
          </div>
          
          
        </div>
      </div>
    </div>
  </div>

<div class="row box-body" style="display: none">
    <div class="col-sm-12">
      <div class="card">
        <div class="card-header b-r-primary">
          <h5>Laporan Komparasi Income </h5>
          <span id="info-location"></span>
        </div>
        <div class="card-body">
        <b> &bull; Pendapatan <span id="info-table1"></span></b>
        <div class="dt-ext">
            <table class="display table-hover" id="datatable-1">
              <thead>
                <tr role="row">
                    <th rowspan="2" style="vertical-align: middle; text-align: center;border-right: 2px solid #e6edef;"
                        class="table-center">
                        Kelas Kendaraan
                    </th>
                    <th colspan="2" style="text-align: center;">Total Masuk</th>
                    <th colspan="2" style="text-align: center;">Total Keluar</th>
                    <th rowspan="2" style="text-align: center;vertical-align: middle;border-left: 2px solid #e6edef;">
                        Pendapatan
                    </th>
                </tr>
                <tr role="row">
                    <th style="text-align: center;border-right: 2px solid #e6edef;" class="table-center"> Casual</th>
                    <th style="text-align: center;border-right: 2px solid #e6edef" class="table-center"> Pass</th>
                    <th style="text-align: center;border-right: 2px solid #e6edef" class="table-center"> Casual</th>
                    <th style="text-align: center;" class="table-center"> Pass</th>
                </tr>
                </thead>
                <tbody></tbody>
                <tfoot>
                <tr class="total">
                    <th>TOTAL</th>
                    <th style="border-left: 2px solid #e6edef;"></th>
                    <th style="border-left: 2px solid #e6edef;"></th>
                    <th style="border-left: 2px solid #e6edef;"></th>
                    <th style="border-left: 2px solid #e6edef;"></th>
                    <th style="border-left: 2px solid #e6edef;"></th>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>

        <div class="card-body">
        <b> &bull; Pendapatan <span id="info-table2"></span></b>
        <div class="dt-ext">
            <table class="display table-hover" id="datatable-2">
              <thead>
                <tr role="row">
                    <th rowspan="2" style="vertical-align: middle; text-align: center;border-right: 2px solid #e6edef;"
                        class="table-center">
                        Kelas Kendaraan
                    </th>
                    <th colspan="2" style="text-align: center;">Total Masuk</th>
                    <th colspan="2" style="text-align: center;">Total Keluar</th>
                    <th rowspan="2" style="text-align: center;vertical-align: middle;border-left: 2px solid #e6edef;">
                        Pendapatan
                    </th>
                </tr>
                <tr role="row">
                    <th style="text-align: center;border-right: 2px solid #e6edef" class="table-center"> Casual</th>
                    <th style="text-align: center;border-right: 2px solid #e6edef" class="table-center"> Pass</th>
                    <th style="text-align: center;border-right: 2px solid #e6edef" class="table-center"> Casual</th>
                    <th style="text-align: center;" class="table-center"> Pass</th>
                </tr>
                </thead>
                <tbody></tbody>
                <tfoot>
                <tr class="total">
                    <th>TOTAL</th>
                    <th style="border-left: 2px solid #e6edef;"></th>
                    <th style="border-left: 2px solid #e6edef;"></th>
                    <th style="border-left: 2px solid #e6edef;"></th>
                    <th style="border-left: 2px solid #e6edef;"></th>
                    <th style="border-left: 2px solid #e6edef;"></th>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>


    </div>
  </div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- Plugins JS start-->
    <script src="<?php echo e(asset('assets/js/datatable/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/buttons.colVis.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.autoFill.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/responsive.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.keyTable.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.colReorder.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.fixedHeader.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.rowReorder.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.scroller.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/datatable-prev-next.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatable/datatable-extension/custom.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/accounting.min.js')); ?>"></script>
    
    <script>
      $(document).ready(function(){
        
        moment.locale("id");

        var months_id = $.parseJSON('{"1":"Januari","2":"Februari","3":"Maret","4":"April","5":"Mei","6":"Juni","7":"Juli","8":"Agustus","9":"September","10":"Oktober","11":"November","12":"Desember"}');

        var location = $('select[name=site_id]');
        var selectYear = $('select[name="year"]');
        var selectMonth = $('select[name="month"]');
        var selectDay = $('select[name="day"]');
        var selectReport = $('select[name="report_type"]');

        function formatNumber(number) {
            var precision = {
                decimal: ",",
                thousand: ".",
                precision: 0,
                format: "%s%v"
            };
            return accounting.formatNumber(number, precision)
        }

        var rmDot = function (i) {
            var clean;
            if (i === '' || i === null) {
                return "";
            }
            if (typeof i === 'number') {
                clean = i;
            } else {
                clean = i.replace(/\./g, "");
            }

            return parseInt(clean);
        };


        $('.select2').select2();

        function getBeforeDate() {
            if (selectReport.val() === 'day') {
                return moment(selectYear.val() + '/' + selectMonth.val() + '/' + selectDay.val(), 'YYYY/MM/DD').subtract(1, 'days');
            } else if (selectReport.val() === "week") {
                return moment(selectYear.val(), 'YYYY').isoWeeks(selectDay.val()).subtract(1, 'weeks');
            } else if (selectReport.val() === "month") {
                return moment(selectYear.val() + '/' + selectMonth.val(), 'YYYY/MM/DD').subtract(1, 'months');
            }
        }
        
        $('#show').click(function (event) {
            event.preventDefault();
            var result = true;

            if (location.val() === "") {
                swalNotify("Oops!","Parameter lokasi harus diisi.","warning");
                return false;
            }

            if (selectReport.val().length === 0) {
                swalNotify("Oops!","Jenis laporan harus diisi.","warning");
                return false;
            }

            if (selectDay.val().length === 0) {
                swalNotify("Oops!","Pilih parameter waktu","warning");
                return false;
            }

            if (selectReport.val() === "day" || selectReport.val() === "week") {
                    if (selectDay.val() === "" || selectMonth.val() === "") {
                        swalNotify("Oops!","Pilih parameter waktu","warning");
                        result = false;
                    }
                }

            if (result === false) {
                return false;
            }

            $(".box-body").show();
            datatable("datatable-1", location.val(), selectReport.val(), selectYear.val(), selectMonth.val(), selectDay.val());
            
            var before = getBeforeDate();
            setLabel(location, selectReport, selectYear, selectMonth, selectDay, before);

            if (selectReport.val() === "week") {
                datatable("datatable-2", location.val(), selectReport.val(), before.format('YYYY'), before.format('M'), before.isoWeeks());
            } else {
                datatable("datatable-2", location.val(), selectReport.val(), before.format('YYYY'), before.format('M'), before.format('D'));
            }
        });

      var table = null;

      function datatable(selector, site, type, year, month, day){
        
        table = $('#' + selector).DataTable( {
              processing: true,
              serverSide: true,
              responsive: true,
              bDestroy: true,
              bPaginate: false,
              bLengthChange: true,
              bFilter: false,
              bSort: false,
              bInfo: false,
              ajax: { 
                      url: "<?php echo e(route('ajax-income-report')); ?>",
                      data: function (d) {
                            d.site = site;
                            d.year = year;
                            d.month = month;
                            d.day = day;
                            d.type = type;
                        },
                      type: "post" 
                    },
              columns: [
                  {data: 'vehicle', name: 'vehicle', render: $.fn.dataTable.render.number('.', ',', 0, '')},
                  {data: 'casualIn', name: 'casualIn', className: "aright", render: $.fn.dataTable.render.number('.', ',', 0, '')},
                  {data: 'passIn', name: 'passIn', className: "aright", render: $.fn.dataTable.render.number('.', ',', 0, '')},
                  {data: 'casualOut', name: 'casualOut', className: "aright", render: $.fn.dataTable.render.number('.', ',', 0, '')},
                  {data: 'passOut', name: 'passOut', className: "aright", render: $.fn.dataTable.render.number('.', ',', 0, '')},
                  {data: 'TRANFEE', name: 'TRANFEE', className: "aright", render: $.fn.dataTable.render.number('.', ',', 0, '')}
              ],
              order: [[3, 'desc']], 
              fnDrawCallback: function () {
                  $("#pdf").show();
              },
              fnFooterCallback: function (row, data, start, end, display) {
                  var api = this.api(), data;

                  for (var cols = 1; cols < 6; cols++) {
                      var total = api
                          .column(cols)
                          .data()
                          .reduce(function (a, b) {
                              return rmDot(a) + rmDot(b);
                          }, 0);

                      $(api.column(cols).footer()).html(
                          formatNumber(total)
                      );
                  }
              }   
          });

        }

        $('#pdf').click(function () {
          event.preventDefault();
          var result = true;

          if (location.val() === "") {
              $('#error-location').show().delay(5000).fadeOut('slow');
              result = false;
          }
          if (selectReport.val() === "") {
              $('#error-type').show().delay(5000).fadeOut('slow');
              result = false;
          }
          if (selectYear.val() === "") {
              $('#error-year').show().delay(5000).fadeOut('slow');
              result = false;
          }
          if (selectMonth.val() === "") {
              if (selectReport.val() === "month") {
                  $('#error-month').show().delay(5000).fadeOut('slow');
                  result = false;
              }
          }
          if (selectReport.val() === "day" || selectReport.val() === "week") {
              if (selectDay.val() === "" || selectMonth.val() === "") {
                  $('#error-day').show().delay(5000).fadeOut('slow');
                  result = false;
              }
          }
          if (result === false) {
              return false;
          }

          var param = {
              site: location.val(),
              type: selectReport.val(),
              year: selectYear.val(),
              month: selectMonth.val(),
              day: selectDay.val()
          };

          var url = "<?php echo e(url('parking-compare-pdf')); ?>" + "?" + $.param(param);
          window.open(url, "_blank");
      });

      $('#btn-submit').click(function(){
          table.draw();
      });

      selectYear.attr('disabled', true).change(function () {
          fillDays();
      });

      selectMonth.attr('disabled', true).change(function () {
          if (selectReport.find('option:selected').val() === 'week') {
              fillWeek();
          } else if (selectReport.find('option:selected').val() === 'day') {
              fillDays();
          }
      });
      selectDay.attr('disabled', true);
      fillDays();
      
      
      selectReport.change(function () {
            var report_type = $(this).find('option:selected').val();
            if (report_type === 'day') {
                selectYear.attr('disabled', false);
                selectMonth.attr('disabled', false);
                selectDay.attr('disabled', false);
                fillDays();
            } else if (report_type === 'week') {
                selectYear.attr('disabled', false);
                selectMonth.attr('disabled', false);
                selectDay.attr('disabled', false);
                fillWeek();

            } else if (report_type === 'month') {
                selectYear.attr('disabled', false);
                selectMonth.attr('disabled', false);
                selectDay.attr('disabled', true);
                fillDays();
            }
      });

      function fillDays() {
            $("#label-day").text("Tanggal");
            var year = $('select[name="year"]').find('option:selected').val();
            var month = $('select[name="month"]').find('option:selected').val();
            var day = $('select[name="day"]');
            var defaultValueDay = day.val() === "" ? moment().format("D") : day.val();

            var days = moment(year + "-" + month, "YYYY-M").daysInMonth();
            day.empty();
            var option = '<option value="">-- Pilih Tanggal --</option>';
            for (var start = 1; start <= days; start++) {
                option += '<option value="' + start + '">' + start + '</option>';
            }
            day.append(option);
            day.val(defaultValueDay);
            day.select2();
        }

        function fillWeek() {
            $("#label-day").text("Minggu");
            var year = $('select[name="year"]').find('option:selected').val();
            var month = $('select[name="month"]').find('option:selected').val();
            var day = $('select[name="day"]');

            var weeksMonth = weeksInMonth(year, month);
            day.empty();
            var option = '<option value="">-- Pilih Minggu --</option>';
            $.each(weeksMonth, function (key, item) {
                option += '<option value="' + item + '">' + (parseInt(key + 1)) + '</option>';
            });

            day.append(option);
            day.val("");
            day.select2();
            //moment('2020','YYYY').week(14).endOf('isoWeek').toDate()
        }

        function weeksInMonth(year, month) {
            const firstDayOfMonth = moment(year + '-' + month, 'YYYY-MM-DD');
            const numOfDays = firstDayOfMonth.daysInMonth();
            let weeks = new Set();

            for (let i = 0; i < numOfDays; i++) {
                const currentDay = moment(firstDayOfMonth, 'YYYY-MM-DD').add(i, 'days');
                weeks.add(currentDay.isoWeek());
            }

            return Array.from(weeks);
        }

        function getKeyByValue(object, value) {
            for (var prop in object) {
                if (object.hasOwnProperty(prop)) {
                    if (object[prop] === value)
                        return prop;
                }
            }
        }

        function setLabel(location, type, year, month, day, before) {

          $('#info-location').text('').text(location.find('option:selected').text());

          if (type.val() === 'day') {
              $('#info-table1').text('').text("Tanggal " + day.val() + " " + month.find('option:selected').text() + " " + year.val());
              $('#info-table2').text('').text("Tanggal " + before.format('D') + " " + months_id[before.format('M')] + " " + before.format('YYYY'));
          } else if (type.val() === "week") {
              var weekBefore = before.isoWeek();
              var listWeekInMonth = weeksInMonth(before.format('YYYY'), before.format('M'));
              var selectedWeek = parseInt(getKeyByValue(listWeekInMonth, weekBefore)) + 1;

              $('#info-table1').text('').text("Minggu ke-" + day.find('option:selected').text() + " " + month.find('option:selected').text() + " " + year.val());
              $('#info-table2').text('').text("Minggu ke-" + selectedWeek + " " + months_id[before.format('M')] + " " + before.format('YYYY'));
          } else if (type.val() === "month") {
              $('#info-table1').text('').text("Bulan " + month.find('option:selected').text() + " " + year.val());
              $('#info-table2').text('').text("Bulan " + months_id[before.format('M')] + " " + before.format('YYYY'));
          }
        }



      });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MFN\WebServer\laragon\www\parking-is\resources\views/modules/trans/compare.blade.php ENDPATH**/ ?>