<!DOCTYPE html>
<html>
<head>

	<style>
	
        * {
            font-size: 14px;
        }

        th {
            width:100%;
            text-align:center;
        }

        .aright{
            text-align:right;
        }

        table, td, th {
            border: 1px solid #ddd;;
        }

        table {
            border-collapse: collapse;
            width: 100%;
        }

	</style>
</head>
<body>
	<div class="container">
	<p align="center"> <b style="font-size: 1.5em;">LAPORAN KOMPARASI INCOME</b> </p>
    <p align="center" style="font-size: 18px;"> <?php echo e(strtoupper($site->site_name)); ?> </p>
    <table style="border: 0px;">
        <tr>
            <td style="border: 0px;" width="10%">Tgl Shift</td>
            <td style="border: 0px;">: <?php echo e($title); ?> </td>
        </tr>
        <tr>
            <td style="border: 0px;" width="10%">Jam Shift</td>
            <td style="border: 0px;">: 00:00:00 s/d 24:00:00</td>
        </tr>
        <tr>
            <td style="border: 0px;" width="10%">Jenis Laporan</td>
            <td style="border: 0px;">: <?php echo e($laporan); ?></td>
        </tr>
    </table>
	<br>
	<!-- Here pure-table class is used -->
    <p><b style="font-size: 1em;">REKAP PENDAPATAN <?php echo e($titlesub1); ?></b></p>
    <table class="display table-hover" id="datatable-1">
        <thead>
        <tr role="row">
            <th rowspan="2" style="vertical-align: middle; text-align: center;border-right: 2px solid #e6edef;"
                class="table-center">
                Kelas Kendaraan
            </th>
            <th colspan="2" style="text-align: center;">Total Masuk</th>
            <th colspan="2" style="text-align: center;">Total Keluar</th>
            <th rowspan="2" style="text-align: center;vertical-align: middle;border-left: 2px solid #e6edef;">
                Pendapatan
            </th>
        </tr>
        <tr role="row">
            <th style="text-align: center;border-right: 2px solid #e6edef;" class="table-center"> Casual</th>
            <th style="text-align: center;border-right: 2px solid #e6edef" class="table-center"> Pass</th>
            <th style="text-align: center;border-right: 2px solid #e6edef" class="table-center"> Casual</th>
            <th style="text-align: center;" class="table-center"> Pass</th>
        </tr>
        </thead>
            <tbody>
            <?php $sum_casualIn = 0 ?>
            <?php $sum_passIn = 0 ?>
            
            <?php $sum_casualOut = 0 ?>
            <?php $sum_passOut = 0 ?>

            <?php $sum_pendapatan = 0 ?>

                <?php $__currentLoopData = $data1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td width="25%"><?php echo e($data->vehicle); ?></td>
                    <td class="aright"><?php echo e(number_format($data->casualIn,0,'','.')); ?></td>
                    <td class="aright"><?php echo e(number_format($data->passIn,0,'','.')); ?></td>
                   
                    <td class="aright"><?php echo e(number_format($data->casualOut,0,'','.')); ?></td>
                    <td class="aright"><?php echo e(number_format($data->passOut,0,'','.')); ?></td>

                    <td class="aright"><?php echo e(number_format($data->TRANFEE,0,'','.')); ?></td>
                </tr>
                <?php $sum_casualIn += $data->casualIn ?>
                <?php $sum_passIn += $data->passIn ?>
                <?php $sum_casualOut += $data->casualOut ?>
                <?php $sum_passOut += $data->passOut ?>
                <?php $sum_pendapatan += $data->TRANFEE ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
            <tr class="total">
                <th style="border-top: 2px solid #e6edef;">TOTAL</th>
                <th class="aright" style="border-top: 2px solid #e6edef;"><?php echo e(number_format($sum_casualIn,0,'','.')); ?></th>
                <th class="aright" style="border-top: 2px solid #e6edef;"><?php echo e(number_format($sum_passIn,0,'','.')); ?></th>
                <th class="aright" style="border-top: 2px solid #e6edef;"><?php echo e(number_format($sum_passIn,0,'','.')); ?></th>
                <th class="aright" style="border-top: 2px solid #e6edef;"><?php echo e(number_format($sum_passOut,0,'','.')); ?></th>
                <th class="aright" style="border-top: 2px solid #e6edef;"><?php echo e(number_format($sum_pendapatan,0,'','.')); ?></th>
            </tr>
            </tfoot>
        </table>
        <br>
        <p><b style="font-size: 1em;">REKAP PENDAPATAN <?php echo e($titlesub2); ?></b></p>
    <table class="display table-hover" id="datatable-1">
        <thead>
        <tr role="row">
            <th rowspan="2" style="vertical-align: middle; text-align: center;border-right: 2px solid #e6edef;"
                class="table-center">
                Kelas Kendaraan
            </th>
            <th colspan="2" style="text-align: center;">Total Masuk</th>
            <th colspan="2" style="text-align: center;">Total Keluar</th>
            <th rowspan="2" style="text-align: center;vertical-align: middle;border-left: 2px solid #e6edef;">
                Pendapatan
            </th>
        </tr>
        <tr role="row">
            <th style="text-align: center;border-right: 2px solid #e6edef;" class="table-center"> Casual</th>
            <th style="text-align: center;border-right: 2px solid #e6edef" class="table-center"> Pass</th>
            <th style="text-align: center;border-right: 2px solid #e6edef" class="table-center"> Casual</th>
            <th style="text-align: center;" class="table-center"> Pass</th>
        </tr>
        </thead>
            <tbody>
            <?php $sum_casualIn = 0 ?>
            <?php $sum_passIn = 0 ?>
            
            <?php $sum_casualOut = 0 ?>
            <?php $sum_passOut = 0 ?>

            <?php $sum_pendapatan = 0 ?>

                <?php $__currentLoopData = $data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td width="25%"><?php echo e($data->vehicle); ?></td>
                    <td class="aright"><?php echo e(number_format($data->casualIn,0,'','.')); ?></td>
                    <td class="aright"><?php echo e(number_format($data->passIn,0,'','.')); ?></td>
                   
                    <td class="aright"><?php echo e(number_format($data->casualOut,0,'','.')); ?></td>
                    <td class="aright"><?php echo e(number_format($data->passOut,0,'','.')); ?></td>

                    <td class="aright"><?php echo e(number_format($data->TRANFEE,0,'','.')); ?></td>
                </tr>
                <?php $sum_casualIn += $data->casualIn ?>
                <?php $sum_passIn += $data->passIn ?>
                <?php $sum_casualOut += $data->casualOut ?>
                <?php $sum_passOut += $data->passOut ?>
                <?php $sum_pendapatan += $data->TRANFEE ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
            <tr class="total">
                <th style="border-top: 2px solid #e6edef;">TOTAL</th>
                <th class="aright" style="border-top: 2px solid #e6edef;"><?php echo e(number_format($sum_casualIn,0,'','.')); ?></th>
                <th class="aright" style="border-top: 2px solid #e6edef;"><?php echo e(number_format($sum_passIn,0,'','.')); ?></th>
                <th class="aright" style="border-top: 2px solid #e6edef;"><?php echo e(number_format($sum_passIn,0,'','.')); ?></th>
                <th class="aright" style="border-top: 2px solid #e6edef;"><?php echo e(number_format($sum_passOut,0,'','.')); ?></th>
                <th class="aright" style="border-top: 2px solid #e6edef;"><?php echo e(number_format($sum_pendapatan,0,'','.')); ?></th>
            </tr>
            </tfoot>
        </table>
	</div>
</body>
</html>
<?php /**PATH D:\MFN\WebServer\laragon\www\parking-is\resources\views/modules/trans/pdfCompare.blade.php ENDPATH**/ ?>