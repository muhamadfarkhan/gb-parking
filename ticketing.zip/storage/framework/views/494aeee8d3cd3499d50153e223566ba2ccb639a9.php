<!DOCTYPE html>
<html>
<head>

	<style>
	
        * {
            font-size: 14px;
        }

        th {
            width:100%;
            text-align:center;
        }

        .aright{
            text-align:right;
        }

        table, td, th {
            border: 1px solid #ddd;;
        }

        table {
            border-collapse: collapse;
            width: 100%;
        }

	</style>
</head>
<body>
	<div class="container">
	<p align="center"> <b style="font-size: 1.5em;">LAPORAN REKAP TRANSAKSI</b> </p>
    <p align="center" style="font-size: 18px;"> <?php echo e(strtoupper($site->site_name)); ?> </p>
    <table style="border: 0px;">
        <tr>
            <td width="10%" style="border: 0px;">Tgl Transaksi</td>
            <td style="border: 0px;">: <?php echo e($startDate); ?> s/d <?php echo e($endDate); ?></td>
        </tr>
        <tr>
            <td style="border: 0px;" width="10%">Jam Transaksi</td>
            <td style="border: 0px;">: <?php echo e($startHour); ?> s/d <?php echo e($endHour); ?></td>
        </tr>
        <tr>
            <td width="10%" style="border: 0px;">Perusahaan</td>
            <td style="border: 0px;">: <?php echo e($perusahaan); ?></td>
        </tr>
        <tr>
            <td style="border: 0px;" width="10%">Petugas</td>
            <td style="border: 0px;">: <?php echo e($petugas); ?></td>
        </tr>
    </table>
        
	<br>
	<!-- Here pure-table class is used -->
    <p><b style="font-size: 1em;">REKAP PENDAPATAN</b></p>
	<table style="border: 1px solid #ddd;" id="datatable" class="table table-bordered table-hover" width="100%" >
    <thead>
        <tr role="row">
            <th rowspan="2" style="vertical-align: middle; text-align: center;"
                class="table-center">
                Jenis tiket
            </th>
            <th colspan="3" style="text-align: center;">Pembelian tiket</th>
            <th colspan="2" style="text-align: center;">Pelayaran</th>
            <th rowspan="2" style="vertical-align: middle; text-align: center;">Iuran Wajib</th>
            <th rowspan="2" style="vertical-align: middle; text-align: center;">Pas Pelabuhan</th>
            <th rowspan="2" style="vertical-align: middle; text-align: center;">Total Terpadu</th>
            <th colspan="3" style="vertical-align: middle; text-align: center;">
                Jenis Pembayaran
            </th>
        </tr>
        <tr role="row">
            <th style="text-align: center;" class=table-center"> Online</th>
            <th style="text-align: center;" class=table-center"> Offline</th>
            <th style="text-align: center;" class=table-center"> Jumlah</th>

            <th style="text-align: center;" class=table-center"> Pelayanan</th>
            <th style="text-align: center;" class=table-center"> TJP</th>

            <th style="text-align: center;" class=table-center"> Tunai</th>
            <th style="text-align: center;" class=table-center"> E-Payment</th>

        </tr>
        </thead>
        <tbody>
            <?php $online = 0 ?>
            <?php $offline = 0 ?>
            <?php $totalLine = 0 ?>
            <?php $pelayanan = 0 ?>
            <?php $tjp = 0 ?>
            <?php $iuran_wajib = 0 ?>
            <?php $pas_pelabuhan = 0 ?>
            <?php $total = 0 ?>
            <?php $tunai = 0 ?>
            <?php $ePayment = 0 ?>

            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td width="25%"><?php echo e($data->vehicle); ?></td>
                    <td class="aright"><?php echo e(number_format($data->online,0,'','.')); ?></td>
                    <td class="aright"><?php echo e(number_format($data->offline,0,'','.')); ?></td>
                   
                    <td class="aright"><?php echo e(number_format($data->totalLine,0,'','.')); ?></td>
                    <td class="aright"><?php echo e(number_format($data->pelayanan,0,'','.')); ?></td>
                   
                    <td class="aright"><?php echo e(number_format($data->tjp,0,'','.')); ?></td>
                    <td class="aright"><?php echo e(number_format($data->iuran_wajib,0,'','.')); ?></td>
                   
                    <td class="aright"><?php echo e(number_format($data->pas_pelabuhan,0,'','.')); ?></td>
                    <td class="aright"><?php echo e(number_format($data->total,0,'','.')); ?></td>
                   
                    <td class="aright"><?php echo e(number_format($data->tunai,0,'','.')); ?></td>
                    <td class="aright"><?php echo e(number_format($data->ePayment,0,'','.')); ?></td>
                   
                </tr>
                
            <?php $online += $data->online?>
            <?php $offline += $data->offline ?>
            <?php $totalLine += $data->totalLine ?>
            <?php $pelayanan += $data->pelayanan ?>
            <?php $tjp += $data->tjp ?>
            <?php $iuran_wajib += $data->iuran_wajib ?>
            <?php $pas_pelabuhan += $data->pas_pelabuhan ?>
            <?php $total += $data->total ?>
            <?php $tunai += $data->tunai ?>
            <?php $ePayment += $data->ePayment ?>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
        <tr class="total">
            <th style="border-top: 2px solid #e6edef;">TOTAL</th>
            <th style="border-top: 2px solid #e6edef;" class="aright"><?php echo e(number_format($online,0,'','.')); ?></th>
            <th style="border-top: 2px solid #e6edef;" class="aright"><?php echo e(number_format($offline,0,'','.')); ?></th>
            <th style="border-top: 2px solid #e6edef;" class="aright"><?php echo e(number_format($totalLine,0,'','.')); ?></th>
            <th style="border-top: 2px solid #e6edef;" class="aright"><?php echo e(number_format($pelayanan,0,'','.')); ?></th>
            <th style="border-top: 2px solid #e6edef;" class="aright"><?php echo e(number_format($tjp,0,'','.')); ?></th>
            <th style="border-top: 2px solid #e6edef;" class="aright"><?php echo e(number_format($iuran_wajib,0,'','.')); ?></th>
            <th style="border-top: 2px solid #e6edef;" class="aright"><?php echo e(number_format($pas_pelabuhan,0,'','.')); ?></th>
            <th style="border-top: 2px solid #e6edef;" class="aright"><?php echo e(number_format($total,0,'','.')); ?></th>
            <th style="border-top: 2px solid #e6edef;" class="aright"><?php echo e(number_format($tunai,0,'','.')); ?></th>
            <th style="border-top: 2px solid #e6edef;" class="aright"><?php echo e(number_format($ePayment,0,'','.')); ?></th>
        </tr>
        </tfoot>
        </table>
        
	</div>
</body>
</html>
<?php /**PATH D:\MFN\WebServer\laragon\www\ticketing-ms\resources\views/modules/trans/pdfRecap.blade.php ENDPATH**/ ?>