<!DOCTYPE html>
<html>
<head>

	<style>
	
        * {
            font-size: 10px;
            font-family: Arial;
        }

        th {
            width:100%;
            text-align:center;
        }

        .aright{
            text-align:right;
        }

        table, td, th {
            border: 1px solid #ddd;;
        }

        table {
            border-collapse: collapse;
            width: 100%;
        }

	</style>
</head>
<body>
	<div class="container">
	

        <header>
        <p align="center"> <b style="font-size: 1.5em;">LAPORAN TRANSAKSI TIKET</b> </p>
    <p align="center" style="font-size: 18px;"> <?php echo e(strtoupper($site->site_name)); ?> </p>
    <table style="border: 0px;width: 70%;">
        <tr>
            <td style="border: 0px;width: 15%;">Tgl Transaksi</td>
            <td style="border: 0px;width: 25%;">: <?php echo e($tgl); ?></td>
            <td style="border: 0px;width: 15%;">Petugas</td>
            <td style="border: 0px;width: 25%;">: <?php echo e($petugas); ?></td>
        </tr>
        <tr>
            <td style="border: 0px;">Jam Transaksi</td>
            <td style="border: 0px;">: <?php echo e($jam); ?></td>
            <td style="border: 0px;">Perusahaan</td>
            <td style="border: 0px;">: <?php echo e($perusahaan); ?></td>
        </tr>
        <tr>
            <td style="border: 0px;">Jenis Tiket</td>
            <td style="border: 0px;">: <?php echo e($jenis_tiket); ?></td>
            <td style="border: 0px;">Pembayaran</td>
            <td style="border: 0px;">: <?php echo e($pembayaran); ?></td>
        </tr>
    </table>
    <br>
    <br>
        </header>

        <footer>
           
        </footer>

        <main>
	
	<!-- Here pure-table class is used -->
	<table style="border: 1px solid #ddd;">
		<thead>
		<tr>
			<th style="width:10%">No</th>
			<th style="width:15%">Jenis Tiket</th>
            <th style="width:15%">Tanggal</th>
            <th style="width:15%">Nama</th>
			<th style="width:15%">No. Plat</th>
			<th style="width:15%">Jenis Pembayaran</th>
            <th style="width:15%">Jml Pnp</th>
            <th style="width:15%">Berat (kg)</th>
			<th style="width:10%">Total</th>
		</tr>
		</thead>

		<tbody>
            <?php $total = 0 ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($data->biaya->WALKDES); ?></td>
                    <td><?php echo e($data->DATETIMEIN); ?></td>
                    <td><?php echo e($data->PASSNO); ?></td>
                    <td><?php echo e($data->REGNO); ?></td>
                    <td>
                    <?php
                    if ($data->TRANPAY == "E") {
                        echo "E-Payment";
                    } elseif ($data->TRANPAY == "C") {
                        echo "Cash";
                    } elseif ($data->TRANPAY == "P") {
                        echo "Member";
                    } elseif ($data->TRANPAY == "O") {
                        echo "Online";
                    } elseif ($data->TRANPAY == "V") {
                        echo "Voucher";
                    } ?>

                    </td>
                    <td class="aright"><?php echo e(number_format($data->ENTPAY,0,'','.')); ?></td>
                    <td class="aright"><?php echo e(number_format($data->CPSFEE,0,'','.')); ?></td>
                    <td class="aright"><?php echo e(number_format($data->TRANSAMT,0,'','.')); ?></td>
                    
                </tr>
            <?php $total += $data->TRANSAMT ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		</tbody>
        <tfoot>
        <tr>
            <th class="aright" style="padding-right: 5px;" colspan="8">TOTAL</th>
            <th class="aright" style="width:10%"><?php echo e(number_format($total,0,'','.')); ?></th>
        </tr>
        </tfoot>
	</table>
                </main>
	</div>
</body>
</html>
<?php /**PATH /var/www/html/ticketing/resources/views/modules/trans/pdfTicket.blade.php ENDPATH**/ ?>