<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\MainController;
use App\Http\Controllers\TransactController;
use App\Http\Controllers\SummaryController;
use App\Http\Controllers\ExportController;
use App\Http\Controllers\ManageSiteController;
use App\Http\Controllers\ManageUserController;
use App\Http\Controllers\ManageTarifController;
use App\Http\Controllers\ManageVIPController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::post('/sync-data', [AuthController::class, 'sync']);
Route::post('/login-p', [AuthController::class, 'login'])->name('login-p');
Route::get('/logout', [AuthController::class, 'logout'])->name('logout');
Route::get('/login', function () {
    
    $data['title'] = 'Authentication - Product Branding';
    return view('layouts.login', $data);
})->name('login');

Route::middleware('auth')->group(function () {

    Route::get('/', [MainController::class, 'index'])->name('dashboard');
    Route::get('/', [MainController::class, 'index'])->name('/');

    
    Route::get('/ticket-transactions', [MainController::class, 'ticketTrans'])->name('ticket-transactions');
    Route::post('/ajax-ticket-trans', [TransactController::class, 'ajaxTicketTrans'])->name('ajax-ticket-trans');
    
    Route::get('/recap-transaction-report', [MainController::class, 'recapTrans'])->name('recap-transaction-report');
    Route::post('/ajax-recap-transaction', [TransactController::class, 'ajaxRecapTrans'])->name('ajax-recap-transaction');
    Route::post('/ajax-recap-statistic', [TransactController::class, 'ajaxRecapStatistic'])->name('ajax-recap-statistic');

    Route::post('/home-income-today', [SummaryController::class, 'incomeToday'])->name('home-income-today');
    Route::post('/total-weekly-chart', [SummaryController::class, 'totalWeeklyChart'])->name('total-weekly-chart');
    Route::post('/average-chart', [SummaryController::class, 'averageChart'])->name('average-chart');
    Route::post('/quantity-chart', [SummaryController::class, 'quantityChart'])->name('quantity-chart');
    Route::post('/vehicle-chart', [SummaryController::class, 'vehicleChart'])->name('vehicle-chart');
    
    Route::get('/comparation-income-report', [MainController::class, 'compareIncome'])->name('comparation-income-report');
    Route::post('/ajax-income-report', [TransactController::class, 'ajaxIncomeReport'])->name('ajax-income-report');

    // report
    Route::get('/parking-trans-pdf', [ExportController::class, 'pdfTrans']);
    Route::get('/parking-recap-pdf', [ExportController::class, 'pdfRecap']);
    Route::get('/parking-compare-pdf', [ExportController::class, 'pdfCompare']);
    
    // manage
    
    Route::get('/manage-site', [MainController::class, 'manageSite'])->name('manage-site');
    Route::post('/ajax-list-site', [ManageSiteController::class, 'index'])->name('ajax-list-site');
    Route::get('/delete-site/{id}', [ManageSiteController::class, 'destroy'])->name('delete-site');
    Route::get('/create-site', [ManageSiteController::class, 'create'])->name('create-site');
    Route::post('/store-site', [ManageSiteController::class, 'store'])->name('store-site');
    Route::get('/edit-site/{id}', [ManageSiteController::class, 'edit'])->name('edit-site');
    Route::post('/update-site/{id}', [ManageSiteController::class, 'update'])->name('update-site');
   
    Route::get('/manage-user', [MainController::class, 'manageUser'])->name('manage-user');
    Route::post('/ajax-list-user', [ManageUserController::class, 'index'])->name('ajax-list-user');
    Route::get('/delete-user/{id}', [ManageUserController::class, 'destroy'])->name('delete-user');
    Route::get('/create-user', [ManageUserController::class, 'create'])->name('create-user');
    Route::post('/store-user', [ManageUserController::class, 'store'])->name('store-user');
    Route::get('/edit-user/{id}', [ManageUserController::class, 'edit'])->name('edit-user');
    Route::post('/update-user/{id}', [ManageUserController::class, 'update'])->name('update-user');

    Route::get('/manage-tarif', [MainController::class, 'manageTarif'])->name('manage-tarif');
    Route::post('/ajax-list-tarif', [ManageTarifController::class, 'index'])->name('ajax-list-tarif');
    Route::get('/delete-tarif/{id}', [ManageTarifController::class, 'destroy'])->name('delete-tarif');
    Route::get('/create-tarif', [ManageTarifController::class, 'create'])->name('create-tarif');
    Route::post('/store-tarif', [ManageTarifController::class, 'store'])->name('store-tarif');
    Route::get('/edit-tarif/{id}', [ManageTarifController::class, 'edit'])->name('edit-tarif');
    Route::post('/update-tarif/{id}', [ManageTarifController::class, 'update'])->name('update-tarif');
   
    Route::get('/manage-vip', [MainController::class, 'manageVIP'])->name('manage-vip');
    Route::post('/ajax-list-vip', [ManageVIPController::class, 'index'])->name('ajax-list-vip');
    Route::get('/delete-vip/{id}', [ManageVIPController::class, 'destroy'])->name('delete-vip');
    Route::get('/create-vip', [ManageVIPController::class, 'create'])->name('create-vip');
    Route::post('/store-vip', [ManageVIPController::class, 'store'])->name('store-vip');
    Route::get('/edit-vip/{id}', [ManageVIPController::class, 'edit'])->name('edit-vip');
    Route::post('/update-vip/{id}', [ManageVIPController::class, 'update'])->name('update-vip');

    Route::get('/export-vip', [ExportController::class, 'pdfVip'])->name('export-vip');
   
});
