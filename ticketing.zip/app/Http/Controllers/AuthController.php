<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Models\User;
use App\Models\Trans;
use Session;
use Redirect;

class AuthController extends Controller
{
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function login(Request $request)
    {
        // try{

            $request->validate([
                'username'=>'required',
                'password'=>'required|string'
            ]);

            $user = \App\Models\User::where([ // This model use your second connection to the other database
                'USRNM' => $request->username,
                'PWD' => md5($request->password)
            ])->where('DEPTCD','<>','0110')->first();

            
            if ($user) {
                
                if($user->DEPTCD <> '0110'){
                    Auth::login($user);
                }else{
                    return back()->with('warning','Akun anda tidak memiliki otoritas.');
                }

                return redirect()->intended('/');
            }else{
                return back()->with('warning','Username atau password anda salah.');
            }
            
        // }catch(\Exception $e){
        //     return back()->with('warning','Error, mohon hubungi IT!'.$e);
        // }
    }

    public function logout(Request $request){
        Auth::logout();
        Session::flush();
    
        return redirect(route('login'))->with('message','Logout Berhasil');
    }

    public function sync(Request $request)
    {
        //NONOTA	FACTNO	PASSNO REGNO	VEHCLASS DATETIMEIN	DATETIMEOUT	TRANSAMT	TRANFEE	ENTPAY	TRANPAY
        $data['NOTRAN'] = $request->notran;
        $data['NONOTA'] = $request->nonota;
        $data['FACTNO'] = $request->factno;
        $data['PASSNO'] = $request->passno;
        $data['REGNO'] = $request->regno;
        $data['VEHCLASS'] = $request->vehclass;
        $data['DATETIMEIN'] = $request->datetimein;
        $data['DATETIMEOUT'] = $request->datetimeout;
        $data['TRANSAMT'] = $request->transamt;
        $data['TRANFEE'] = $request->tranfee;
        $data['ENTPAY'] = $request->entpay;
        $data['TRANPAY'] = $request->tranpay;
        $data['site_id'] = $request->site_id;
        
        Trans::where('NOTRAN',$request->notran)->delete();
        Trans::insert($data);
        echo 'notran : '.$request->notran.'<br>';
    }

}
