<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Trans;
use App\Models\Biaya;
use DataTables;
use Barryvdh\DomPDF\Facade\Pdf;
use DB;

class TransactController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function ajaxTicketTrans(Request $request)
    {
        if ($request->ajax()) {

            if(empty($request->range)){
                $from = date("Y-m-d", strtotime("-1 months"));
                $to = date('Y-m-d');
            }else{
                $split = explode(" - ",str_replace('/', '-', $request->range));
                $from = date("Y-m-d H:i:s", strtotime($split[0]));
                $to = date("Y-m-d H:i:s", strtotime($split[1]));
            }

            if(empty($request->payment_method)){
                $data = Trans::whereBetween('DATETIMEIN', [$from, $to])
                // ->where('site_id',$request->site)
                ;
            }else{
                $data = Trans::whereBetween('DATETIMEIN', [$from, $to])
                    ->where('TRANPAY',$request->payment_method)
                    // ->where('site_id',$request->site)
                    ;
            }

            // $data = Trans::whereNotNull('DATETIMEIN');


            return DataTables::of($data)
                ->addIndexColumn()
                ->addColumn('action', function($row){
                    $actionBtn = '
                    <button class="btn btn-info btn-xs" onclick="editRow('.$row->id.')" type="button"><i class="fa fa-pencil"></i></button>
                    
                    <button class="btn btn-danger btn-xs" onclick="deleteRow('.$row->id.')" type="button"><i class="fa fa-trash-o"></i></button>
                    ';
                    return $actionBtn;
                })
                ->addColumn('jenis_tiket', function($row){
                    if(empty($row->biaya)){
                        return "";
                    }else{
                        return $row->biaya->WALKDES;
                    }
                })
                ->addColumn('img_in', function($row){
                   return url('/')."/capture/".$row->NOTRAN.'A.jpg';
                })
                ->addColumn('img_out', function($row){
                    return url('/')."/capture/".$row->NOTRAN.'B.jpg';
                })
                ->editColumn('TRANPAY', function($row){
                    if ($row->TRANPAY == "E") {
                        return "E-Payment";
                    } elseif ($row->TRANPAY == "C") {
                        return "Cash";
                    } elseif ($row->TRANPAY == "P") {
                        return "Member";
                    } elseif ($row->TRANPAY == "O") {
                        return "Online";
                    } elseif ($row->TRANPAY == "V") {
                        return "Voucher";
                    }
                })
                ->editColumn('pembelian', function($row){
                    if($row->ENTRYTYPE == 1){
                        return "Offline";
                    }else{
                        return "Online";
                    }
                })
                ->editColumn('TRANFEE', function($row){
                    return number_format($row->TRANFEE);
                })
                ->addColumn('TGLIMG', function($row){
                    return date("dmY", strtotime($row->DATETIMEIN));
                })
                ->addColumn('perusahaan', function($row){
                    
                    if($row->perusahaan){
                        return $row->perusahaan->DESCR;
                    }else{
                        return $row->USRNME;
                    }
                })
                ->addColumn('jenis_kapal', function($row){
                    
                    if($row->kapal){
                        return $row->kapal->DESCR;
                    }else{
                        return $row->USRNMP;
                    }
                })
                ->filter(function ($instance) use ($request) {

                   
                    if (!empty($request->jenis_tiket)) {
                         $instance->where(function($w) use($request){
                            $search = $request->jenis_tiket;
                            $w->Where('VEHCLASS', "$search");
                        });
                    }

                    if (!empty($request->petugas)) {
                        $instance->where(function($w) use($request){
                           $search = $request->petugas;
                           $w->Where('USRNMA', "$search");
                       });
                    }

                    if (!empty($request->perusahaan)) {
                        $instance->where(function($w) use($request){
                           $search = $request->perusahaan;
                           $w->Where('USRNME', "$search");
                       });
                    }

                    if (!empty($request->kapal)) {
                        $instance->where(function($w) use($request){
                           $search = $request->kapal;
                           $w->Where('USRNMP', "$search");
                       });
                    }


                    if (!empty($request->pembayaran)) {
                        $instance->where(function($w) use($request){
                           $search = $request->pembayaran;
                           $w->Where('TRANPAY', "$search");
                       });
                    }

                    if (!empty($request->condition)) {
                        $instance->where(function($w) use($request){
                           $search = $request->condition;
                           
                           if($search == 'out'){
                            $w->WhereNotNull('DATETIMEOUT');
                           }else{
                            $w->WhereNull('DATETIMEOUT');
                           }

                       });
                   }

                })
                ->with([
                    'total_qty' => number_format(Trans::whereBetween('DATETIMEIN', [$from, $to])->count('NOTRAN'),0,',','.'),
                    'total_income' => number_format(Trans::whereBetween('DATETIMEIN', [$from, $to])->sum('TRANSAMT'),0,',','.'),
                    'total_income1' => number_format($data->sum('TRANSAMT'),0,',','.'),

                ])
                ->withQuery('total_income_f', function($filteredQuery) {
                    return number_format($filteredQuery->sum('TRANSAMT'),0,',','.');
                })

                ->rawColumns(['action'])
                ->make(true);
        }
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function ajaxRecapTrans(Request $request)
    {
        if ($request->ajax()) {

            $from = date("Y-m-d 00:00:00", strtotime(str_replace('/', '-', $request->start)));
            $to = date("Y-m-d 23:59:00", strtotime(str_replace('/', '-', $request->end)));
            
            $data = Trans::select([
                DB::raw('sum(NOTRAN) as totalC'),
                DB::raw('WALKDES as vehicle'),
                DB::raw('tbl_biaya.VEHCLASS as vehclass'),
                DB::raw('sum(TRANFEE) as TRANFEE'),
                DB::raw("SUM(ENTRYTYPE = '2' and DATETIMEIN between '".$from."' and  '".$to."') online"),
                DB::raw("SUM(ENTRYTYPE = '1' and DATETIMEIN between '".$from."' and  '".$to."') offline"),
                DB::raw("SUM(DATETIMEIN between '".$from."' and  '".$to."') totalLine"),
                DB::raw("sum(case when DATETIMEIN between '".$from."' and  '".$to."' then VLTAMT else 0 end) pelayanan"),
                DB::raw("sum(case when DATETIMEIN between '".$from."' and  '".$to."' then VLTFEE else 0 end) tjp"),
                DB::raw("sum(case when DATETIMEIN between '".$from."' and  '".$to."' then CPSAMT else 0 end) iuran_wajib"),
                DB::raw("sum(case when DATETIMEIN between '".$from."' and  '".$to."' then TRANFEE else 0 end) pas_pelabuhan"),
                DB::raw("sum(case when DATETIMEIN between '".$from."' and  '".$to."' then TRANSAMT else 0 end) total"),
                DB::raw("0 manualCasualOut"),
                DB::raw("0 manualPassOut"),
                DB::raw("0 manualCasualIn"),
                DB::raw("0 manualPassIn"),
                DB::raw("sum(case when DATETIMEOUT between '".$from."' and  '".$to."' then TRANFEE else 0 end) pendapatan"),
                DB::raw("sum(case when TRANPAY = 'C' and DATETIMEIN between '".$from."' and  '".$to."' then TRANSAMT else 0 end) tunai"),
                DB::raw("sum(case when TRANPAY = 'E' and DATETIMEIN between '".$from."' and  '".$to."' then TRANSAMT else 0 end) ePayment"),
                DB::raw("sum(case when TRANPAY = 'P' and DATETIMEIN between '".$from."' and  '".$to."' then TRANSAMT else 0 end) pass"),
            ])
            ->join('tbl_biaya','tbl_trans.VEHCLASS','tbl_biaya.VEHCLASS')
            // ->whereIn('tbl_biaya.VEHCLASS', array('C', 'B'))
            // ->where('site_id',$request->site)
            ->groupBy('vehicle','vehclass')
            // ->havingRaw('pendapatan > 0')
            ->orderBy('vehclass');
            // ->get();

            return DataTables::of($data)
                ->filter(function ($instance) use ($request) {

                   
                    if (!empty($request->perusahaan)) {
                         $instance->where(function($w) use($request){
                            $search = $request->perusahaan;
                            $w->Where('tbl_trans.USRNME', "$search");
                        });
                    }

                    if (!empty($request->petugas)) {
                         $instance->where(function($w) use($request){
                            $search = $request->petugas;
                            $w->Where('tbl_trans.USRNMA', "$search");
                        });
                    }
                })
                ->make();
        }
    }

     /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function ajaxRecapStatistic(Request $request)
    {
        if ($request->ajax()) {
            
            $from = date("Y-m-d 00:00:00", strtotime(str_replace('/', '-', $request->start)));
            $to = date("Y-m-d 23:59:00", strtotime(str_replace('/', '-', $request->end)));

            $data = Trans::select([
                DB::raw('sum(NOTRAN) as total'),
                DB::raw('WALKDES as vehicle'),
                DB::raw('sum(TRANFEE) as TRANFEE'),
                DB::raw("SUM(tranpay = 'p' and DATETIMEOUT between '".$from."' and  '".$to."' and   TIMESTAMPDIFF(HOUR, DATETIMEIN, DATETIMEOUT) < 2) pass1"),
                DB::raw("SUM(tranpay != 'p' and DATETIMEOUT between '".$from."' and  '".$to."' and   TIMESTAMPDIFF(HOUR, DATETIMEIN, DATETIMEOUT) < 2) casual1"),

                DB::raw("SUM(tranpay = 'p' and DATETIMEOUT between '".$from."' and  '".$to."' and   TIMESTAMPDIFF(HOUR, DATETIMEIN, DATETIMEOUT) = 2) pass2"),
                DB::raw("SUM(tranpay != 'p' and DATETIMEOUT between '".$from."' and  '".$to."' and   TIMESTAMPDIFF(HOUR, DATETIMEIN, DATETIMEOUT) = 2) casual2"),

                DB::raw("SUM(tranpay = 'p' and DATETIMEOUT between '".$from."' and  '".$to."' and   TIMESTAMPDIFF(HOUR, DATETIMEIN, DATETIMEOUT) = 3) pass3"),
                DB::raw("SUM(tranpay != 'p' and DATETIMEOUT between '".$from."' and  '".$to."' and   TIMESTAMPDIFF(HOUR, DATETIMEIN, DATETIMEOUT) = 3) casual3"),

                DB::raw("SUM(tranpay = 'p' and DATETIMEOUT between '".$from."' and  '".$to."' and   TIMESTAMPDIFF(HOUR, DATETIMEIN, DATETIMEOUT) = 4) pass4"),
                DB::raw("SUM(tranpay != 'p' and DATETIMEOUT between '".$from."' and  '".$to."' and   TIMESTAMPDIFF(HOUR, DATETIMEIN, DATETIMEOUT) = 4) casual4"),

                DB::raw("SUM(tranpay = 'p' and DATETIMEOUT between '".$from."' and  '".$to."' and   TIMESTAMPDIFF(HOUR, DATETIMEIN, DATETIMEOUT) = 5) pass5"),
                DB::raw("SUM(tranpay != 'p' and DATETIMEOUT between '".$from."' and  '".$to."' and   TIMESTAMPDIFF(HOUR, DATETIMEIN, DATETIMEOUT) = 5) casual5"),

                DB::raw("SUM(tranpay = 'p' and DATETIMEOUT between '".$from."' and  '".$to."' and   TIMESTAMPDIFF(HOUR, DATETIMEIN, DATETIMEOUT) = 6) pass6"),
                DB::raw("SUM(tranpay != 'p' and DATETIMEOUT between '".$from."' and  '".$to."' and   TIMESTAMPDIFF(HOUR, DATETIMEIN, DATETIMEOUT) = 6) casual6"),

                DB::raw("SUM(tranpay = 'p' and DATETIMEOUT between '".$from."' and  '".$to."' and   TIMESTAMPDIFF(HOUR, DATETIMEIN, DATETIMEOUT) > 6) pass7"),
                DB::raw("SUM(tranpay != 'p' and DATETIMEOUT between '".$from."' and  '".$to."' and   TIMESTAMPDIFF(HOUR, DATETIMEIN, DATETIMEOUT) > 6) casual7"),
                
                DB::raw("sum(case when DATETIMEOUT between '".$from."' and  '".$to."' then TRANFEE else 0 end) pendapatan"),
            ])
            ->join('tbl_biaya','tbl_trans.VEHCLASS','tbl_biaya.VEHCLASS')
            // ->whereIn('tbl_trans.VEHCLASS', array('C', 'B'))
            ->where('site_id',$request->site)
            ->groupBy('vehicle')
            ->havingRaw('pendapatan > 0')->get();

            return DataTables::of($data)
            
                ->make();
        }
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function ajaxIncomeReport(Request $request)
    {
        if ($request->ajax()) {
          
            $day = str_pad($request->day, 2, "0", STR_PAD_LEFT);
            $month = str_pad($request->month, 2, "0", STR_PAD_LEFT);
            $year = $request->year;
            $type = $request->type;

            $dayCheck = $year.'-'.$month.'-'.$day;

            $dto = new \DateTime();
            $dto->setISODate($year, $day);
            $weekCheck = $dto->format('Y-m-d');
            $dto->modify('+6 days');
            $lastDay = $dto->format('Y-m-d');

            if($type == 'day'){
                $data = Trans::select([
                    DB::raw('sum(NOTRAN) as total'),
                    DB::raw('WALKDES as vehicle'),
                    DB::raw('sum(TRANFEE) as TRANFEE'),
                    DB::raw("SUM(tranpay = 'p' and date(DATETIMEIN) = '".$dayCheck."') passIn"),
                    DB::raw("SUM(tranpay != 'p' and date(DATETIMEIN) = '".$dayCheck."') casualIn"),
                    DB::raw("SUM(tranpay = 'p' and date(DATETIMEOUT) = '".$dayCheck."') passOut"),
                    DB::raw("SUM(tranpay != 'p' and date(DATETIMEOUT) = '".$dayCheck."') casualOut"),
                ])
                ->join('tbl_biaya','tbl_trans.VEHCLASS','tbl_biaya.VEHCLASS')
                // ->whereIn('tbl_trans.VEHCLASS', array('C', 'B'))
                ->whereDate('DATETIMEOUT',$dayCheck)
                ->where('site_id',$request->site)
                ->groupBy('vehicle')->get();

            }else if($type == 'week'){

                $data = Trans::select([
                    DB::raw('sum(NOTRAN) as total'),
                    DB::raw('WALKDES as vehicle'),
                    DB::raw('sum(TRANFEE) as TRANFEE'),
                    DB::raw("SUM(tranpay = 'p' and YEARWEEK(DATETIMEIN, 1) =  YEARWEEK('".$weekCheck."',1)) passIn"),
                    DB::raw("SUM(tranpay != 'p' and YEARWEEK(DATETIMEIN, 1) =  YEARWEEK('".$weekCheck."',1)) casualIn"),
                    DB::raw("SUM(tranpay = 'p' and YEARWEEK(DATETIMEOUT, 1) =  YEARWEEK('".$weekCheck."',1)) passOut"),
                    DB::raw("SUM(tranpay != 'p' and YEARWEEK(DATETIMEOUT, 1) =  YEARWEEK('".$weekCheck."',1)) casualOut"),
                ])
                ->join('tbl_biaya','tbl_trans.VEHCLASS','tbl_biaya.VEHCLASS')
                // ->whereIn('tbl_trans.VEHCLASS', array('C', 'B'))
                ->whereDate('DATETIMEOUT','>=',$weekCheck)
                ->whereDate('DATETIMEOUT','<=',$lastDay)
                ->where('site_id',$request->site)
                ->groupBy('vehicle')->get();
            }else if($type == 'month'){
                
                $data = Trans::select([
                    DB::raw('sum(NOTRAN) as total'),
                    DB::raw('WALKDES as vehicle'),
                    DB::raw('sum(TRANFEE) as TRANFEE'),
                    DB::raw("SUM(tranpay = 'p' and month(DATETIMEIN) = '".$month."') passIn"),
                    DB::raw("SUM(tranpay != 'p' and month(DATETIMEIN) = '".$month."') casualIn"),
                    DB::raw("SUM(tranpay = 'p' and month(DATETIMEOUT) = '".$month."') passOut"),
                    DB::raw("SUM(tranpay != 'p' and month(DATETIMEOUT) = '".$month."') casualOut"),
                ])
                ->join('tbl_biaya','tbl_trans.VEHCLASS','tbl_biaya.VEHCLASS')
                // ->whereIn('tbl_trans.VEHCLASS', array('C', 'B'))
                ->whereMonth('DATETIMEOUT',$month)
                ->where('site_id',$request->site)
                ->groupBy('vehicle')->get();
            }


            return DataTables::of($data)
                ->addIndexColumn()
                ->addColumn('action', function($row){
                    $actionBtn = '
                    <button class="btn btn-info btn-xs" onclick="editRow('.$row->id.')" type="button"><i class="fa fa-pencil"></i></button>
                    
                    <button class="btn btn-danger btn-xs" onclick="deleteRow('.$row->id.')" type="button"><i class="fa fa-trash-o"></i></button>
                    ';
                    return $actionBtn;
                })
                ->editColumn('TRANFEE', function($row){
                    return $row->TRANFEE;
                })
                ->rawColumns(['action'])
                ->make(true);
        }
    }
}
