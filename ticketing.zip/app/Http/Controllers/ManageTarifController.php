<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Trans;
use App\Models\Biaya;
use App\Models\MtxSite;
use App\Models\Site;
use DataTables;
use DB;


class ManageTarifController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if ($request->ajax()) {

            $data = Biaya::get();

            return DataTables::of($data)
                ->addColumn('action', function($row){
                    return '<a href="'.url("/edit-tarif").'/'.$row->VEHCLASS.'" class="btn btn-success btn-xs" href="javascript:void(0)" data-bs-original-title="" title=""><span class="icon-pencil-alt"></span></a>
                    <a onclick="deleteRow(\''.$row->VEHCLASS.'\')" class="btn btn-danger btn-xs" href="javascript:void(0)" data-bs-original-title="" title=""><span class="icon-trash"></span></a>';
                })
                ->addColumn('pelayanan', function($row){
                    return number_format($row->MAXDAYRT,0,',','.');
                })
                ->addColumn('tjp', function($row){
                    return number_format($row->MAXHDAYRT,0,',','.');
                })
                ->addColumn('iuran_wajib', function($row){
                    return number_format($row->ONGTHOL,0,',','.');
                })
                ->addColumn('pas_pelabuhan', function($row){
                    return number_format($row->WRATE1,0,',','.');
                })
                ->addColumn('total', function($row){
                    return number_format($row->WRATE1+$row->ONGTHOL+$row->MAXHDAYRT+$row->MAXDAYRT,0,',','.');
                })
                ->rawColumns(['action'])
                ->make();
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data['title'] = 'Manage Tarif';
        $data['site'] = Biaya::get();
        return view('modules.manage.create-tarif', $data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $tarif = new Biaya();
        $today = date("Y-m-d H:i:s");

        $check = Biaya::where('VEHCLASS',substr($request->vehclass, 0, 1))->first();

        if(!$check){
            $tarif->VEHCLASS = substr($request->vehclass, 0, 1);
            $tarif->WALKDES = $request->jenis_tiket;
            $tarif->MAXDAYRT = $request->pelayanan;
            $tarif->MAXHDAYRT = $request->tjp;
            $tarif->YFIXFEE = "0";
            $tarif->YHOLFEE = "0";
            $tarif->GPACCESS = "0";
            $tarif->GPTRF = "0";
            $tarif->LUPDDTTIME = $today;
            $tarif->ONGTHOL = $request->iuran_wajib;
            $tarif->WRATE1 = $request->pas_pelabuhan;
            $tarif->save();
        }else{
            return redirect()->intended('/manage-tarif')->with('msg','Nama tarif already exist...');
        }
    
        return redirect()->intended('/manage-tarif')->with('msg','Success...');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data['title'] = 'Manage Tarif';
        $data['tarif'] = Biaya::where('VEHCLASS',$id)->first();
        return view('modules.manage.edit-tarif', $data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $today = date("Y-m-d H:i:s");
        
        $check = Biaya::where('VEHCLASS',$id)
            ->where('WALKDES',$request->jenis_tiket)->first();

        if(!$check){

            Biaya::where('VEHCLASS',$id)->delete();

            $tarif = new Biaya();
            $tarif->VEHCLASS = substr($request->vehclass, 0, 1);
            $tarif->WALKDES = $request->jenis_tiket;
            $tarif->WALKCODE = 'WALK';
            $tarif->MAXDAYRT = $request->pelayanan;
            $tarif->MAXHDAYRT = $request->tjp;
            $tarif->YFIXFEE = "0";
            $tarif->YHOLFEE = "0";
            $tarif->GPACCESS = "0";
            $tarif->GPTRF = "0";
            $tarif->LUPDDTTIME = $today;
            $tarif->ONGTHOL = $request->iuran_wajib;
            $tarif->WRATE1 = $request->pas_pelabuhan;
            $tarif->save();
        }else{

            // $check1 = Biaya::where('VEHCLASS',substr($request->vehclass, 0, 1));

            // if($check1){
            //     return redirect()->intended('/manage-tarif')->with('msg','Failed, data exist...');
            // }else{
                Biaya::where('VEHCLASS', $id)
                ->update([
                        // 'VEHCLASS' => substr($request->vehclass, 0, 1),
                        'WALKDES' => $request->jenis_tiket,
                        'WALKCODE' => 'WALK',
                        'MAXDAYRT' => $request->pelayanan,
                        'MAXHDAYRT' => $request->tjp,
                        'YFIXFEE' => "0",
                        'YHOLFEE' => "0",
                        'GPACCESS' => "0",
                        'GPTRF' => "0",
                        'LUPDDTTIME' => $today,
                        'ONGTHOL' => $request->iuran_wajib,
                        'WRATE1' => $request->pas_pelabuhan,
                        ]);
            // }
            
        }
    
        return redirect()->intended('/manage-tarif')->with('msg','Success...');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $tarif = Biaya::where('VEHCLASS',$id);

        $check = Biaya::where('VEHCLASS','V')->orWhere('VEHCLASS','1')
                ->orWhere('VEHCLASS','2')->orWhere('VEHCLASS','3')->first();


        if(!$check){
            $tarif->delete();
            return redirect()->intended('/manage-tarif')->with('msg','Success...');

        }else{

            return redirect()->intended('/manage-tarif')->with('msg','Failed to delete...');
        }
        
    }
}
