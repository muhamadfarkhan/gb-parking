<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Trans;
use App\Models\Biaya;
use App\Models\MtxSite;
use App\Models\Site;
use DataTables;
use DB;


class ManageSiteController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if ($request->ajax()) {

            $data = Site::get();

            return DataTables::of($data)
                ->addColumn('action', function($row){
                    return '<a href="'.url("/edit-site").'/'.$row->id.'" class="btn btn-success btn-xs" href="javascript:void(0)" data-bs-original-title="" title=""><span class="icon-pencil-alt"></span></a>
                    <a onclick="deleteRow('.$row->id.')" class="btn btn-danger btn-xs" href="javascript:void(0)" data-bs-original-title="" title=""><span class="icon-trash"></span></a>';
                })
                ->rawColumns(['action'])
                ->make();
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data['title'] = 'Manage Site';
        $data['site'] = Site::get();
        return view('modules.manage.create-site', $data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $site = new Site();

        $check = Site::where('site_name',$request->site_name)->first();

        if(!$check){
            $site->site_name = $request->site_name;
            $site->site_desc = $request->site_desc;
            $site->save();
        }else{
            return redirect()->intended('/manage-site')->with('msg','Nama site already exist...');
        }
    
        return redirect()->intended('/manage-site')->with('msg','Success...');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data['title'] = 'Manage Site';
        $data['site'] = Site::where('id',$id)->first();
        return view('modules.manage.edit-site', $data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $site = Site::find($id);

        $check = Site::where('id','!=',$id)
            ->where('site_name',$request->site_name)->first();

        if(!$check){
            $site->site_name = $request->site_name;
            $site->site_desc = $request->site_desc;
            $site->save();
        }else{
            return redirect()->intended('/manage-site')->with('msg','Nama site already exist...');
        }
    
        return redirect()->intended('/manage-site')->with('msg','Success...');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $site = Site::find($id);
        $site->delete();
        
        return redirect()->intended('/manage-site')->with('msg','Success...');
    }
}
