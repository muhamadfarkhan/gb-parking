<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Trans;
use App\Models\Site;
use App\Models\Biaya;
use DB;

class SummaryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function incomeToday()
    {
        return 200;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function totalWeeklyChart(Request $request)
    {
        $split = explode(" - ",str_replace('/', '-', $request->date));
        $from = date("Y-m-d", strtotime($split[0]));
        $to = date("Y-m-d", strtotime($split[1]));
        
        $data = Trans::select([
            DB::raw('sum(TRANFEE) as daily'),
            DB::raw('date(DATETIMEIN) as date'),
        ])
        ->whereBetween('DATETIMEOUT', [$from, $to])
        ->having('daily', '>', 0)
        ->groupBy('date')->get();

        $result[] = ['Tanggal','Pendapatan'];

        foreach ($data as $key => $value) {

            $result[++$key] = [$value->date, (int)$value->daily];

        }

        $info['total'] = Trans::whereBetween('DATETIMEOUT', [$from, $to])->sum('TRANFEE');
        $info['cash'] = Trans::whereBetween('DATETIMEOUT', [$from, $to])->where('TRANPAY','C')->sum('TRANFEE');
        $info['epayment'] = Trans::whereBetween('DATETIMEOUT', [$from, $to])->where('TRANPAY','E')->sum('TRANFEE');

        $datas['data'] = $result;
        $datas['info'] = $info;

        return $datas;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function averageChart(Request $request)
    {
        $split = explode(" - ",str_replace('/', '-', $request->date));
        $from = date("Y-m-d", strtotime($split[0]));
        $to = date("Y-m-d", strtotime($split[1]));

        $data = Trans::select([
            DB::raw('sum(TRANFEE) as daily'),
            DB::raw('HOUR(DATETIMEIN) as date'),
        ])
        ->whereBetween('DATETIMEOUT', [$from, $to])
        ->groupBy('date')->get();

        $result[] = ['Tanggal','Pendapatan'];

        foreach ($data as $key => $value) {

            $result[++$key] = [date('H:00', mktime($value->date)) , (int)$value->daily];

        }

        $datas['data'] = $result;

        return $datas;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function quantityChart(Request $request)
    {
        $split = explode(" - ",str_replace('/', '-', $request->date));
        $from = date("Y-m-d", strtotime($split[0]));
        $to = date("Y-m-d", strtotime($split[1]));

        $data = Trans::select([
            DB::raw('count(NOTRAN) as daily'),
            DB::raw('WALKDES as date'),
        ])
        ->whereBetween('DATETIMEOUT', [$from, $to])
        ->join('tbl_biaya','tbl_trans.VEHCLASS','tbl_biaya.VEHCLASS')
        ->whereIn('tbl_trans.VEHCLASS', array('C', 'B'))
        ->groupBy('date')->get();

        $result[] = ['Kendaraan','Jumlah'];

        foreach ($data as $key => $value) {

            $result[++$key] = [$value->date , (int)$value->daily];

        }

        $datas['data'] = $result;

        return $datas;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function vehicleChart(Request $request)
    {

        $split = explode(" - ",str_replace('/', '-', $request->date));
        $from = date("Y-m-d", strtotime($split[0]));
        $to = date("Y-m-d", strtotime($split[1]));

        $data = Trans::select([
            DB::raw("sum(DATETIMEIN between '".$from."' and  '".$to."') as ins"),
            DB::raw("sum(DATETIMEOUT between '".$from."' and  '".$to."') as outs"),
            DB::raw('HOUR(DATETIMEIN) as date'),
        ])
        ->groupBy('date')->get();

        foreach ($data as $key => $value) {

            $result[] = [date('H:00', mktime($value->date)) , (int)$value->ins, (int)$value->outs];

        }

        return $result;
    }
}
