<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Trans;
use App\Models\Biaya;
use App\Models\MtxSite;
use App\Models\Site;
use App\Models\User;
use DataTables;
use DB;
use Hash;
use Session;


class ManageUserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if ($request->ajax()) {

            $data = User::get();

            return DataTables::of($data)
                ->addColumn('action', function($row){
                    return '<a href="'.url("/edit-user").'/'.$row->USRNM.'" class="btn btn-success btn-xs" href="javascript:void(0)" data-bs-original-title="" title=""><span class="icon-pencil-alt"></span></a>
                    <a onclick="deleteRow(\''.$row->USRNM.'\')" class="btn btn-danger btn-xs" href="javascript:void(0)" data-bs-original-title="" title=""><span class="icon-trash"></span></a>';
                })
                ->rawColumns(['action'])
                ->make();
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data['title'] = 'Manage User';
        $data['user'] = User::get();
        $data['site'] = Site::get();
        return view('modules.manage.create-user', $data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $user = new User();

        $check = User::where('USRNM',$request->username)->first();


        if(!$check){
            $user->USRNM = str_replace(' ','',$request->username);
            $user->FULLNM = $request->fullname;
            $user->INITNM = substr(str_replace(' ','',$request->username),0,3);
            $user->DEPTCD = str_replace(' ','',$request->deptcd);
            $user->LVLCD = 2;
            $user->STATUS = 'A';
            $user->PWD = md5($request->password);
            $user->save();

        }else{
            return redirect()->intended('/manage-user')->with('msg','Username already exist...');
        }
    
        return redirect()->intended('/manage-user')->with('msg','Success...');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data['title'] = 'Manage User';
        $data['user'] = User::where('USRNM',$id)->first();
        return view('modules.manage.edit-user', $data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $check = User::where('USRNM',$id);

        User::where('USRNM',$id)->delete();

        $user = new User();
        $user->USRNM = str_replace(' ','',$request->username);
        $user->FULLNM = $request->fullname;
        $user->INITNM = substr(str_replace(' ','',$request->username),0,3);
        $user->DEPTCD = str_replace(' ','',$request->deptcd);
        $user->LVLCD = 2;
        $user->STATUS = 'A';
        $user->PWD = md5($request->password);
        $user->save();

    
        return redirect()->intended('/manage-user')->with('msg','Success...');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $user = User::where('USRNM',$id);
        
        if(1 == 0){

            return redirect()->intended('/manage-user')->with('msg','Not allowed...');
        }else{

            $user->delete();
            return redirect()->intended('/manage-user')->with('msg','Success...');;
        }

    }
}
