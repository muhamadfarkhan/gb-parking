<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Trans;
use App\Models\Biaya;
use App\Models\TmpPlat;
use App\Models\MtxSite;
use App\Models\Site;
use DataTables;
use DB;


class ManageVIPController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if ($request->ajax()) {

            $data = TmpPlat::get();

            return DataTables::of($data)
                ->addColumn('action', function($row){
                    return '<a href="'.url("/edit-vip").'/'.$row->REGNO.'" class="btn btn-success btn-xs" href="javascript:void(0)" data-bs-original-title="" title=""><span class="icon-pencil-alt"></span></a>
                    <a onclick="deleteRow(\''.$row->REGNO.'\')" class="btn btn-danger btn-xs" href="javascript:void(0)" data-bs-original-title="" title=""><span class="icon-trash"></span></a>';
                })
                ->editColumn('STARTDATE', function($row){
                    return $row->STARTDATE.' s/d '.$row->ENDDATE;
                })
                ->rawColumns(['action'])
                ->make();
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data['title'] = 'Manage VIP';
        $data['site'] = Biaya::get();
        return view('modules.manage.create-vip', $data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $vip = new TmpPlat();
        $today = date("Y-m-d H:i:s");

        $check = TmpPlat::where('REGNO',$request->regno)->first();

        $split = explode(" - ",str_replace('/', '-', $request->range));
        $from = date("Y-m-d H:i:s", strtotime($split[0]));
        $to = date("Y-m-d H:i:s", strtotime($split[1]));


        if(!$check){
            $vip->REGNO = $request->regno;
            $vip->WSID = $request->wsid;
            $vip->VEHCLASS = 'A';
            $vip->USRNME = Auth()->user()->USRNME;
            $vip->STARTDATE = $from;
            $vip->ENDDATE = $to;
            $vip->PASSNO = $request->passno;
            $vip->save();
        }else{
            return redirect()->intended('/manage-vip')->with('msg','VIP already exist...');
        }
    
        return redirect()->intended('/manage-vip')->with('msg','Success...');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data['title'] = 'Manage VIP';
        $data['vip'] = TmpPlat::where('REGNO',$id)->first();
        return view('modules.manage.edit-vip', $data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $today = date("Y-m-d H:i:s");
        

        $split = explode(" - ",str_replace('/', '-', $request->range));
        $from = date("Y-m-d H:i:s", strtotime($split[0]));
        $to = date("Y-m-d H:i:s", strtotime($split[1]));

        TmpPlat::where('REGNO',$id)->delete();

        $vip = new TmpPlat();
        $vip->REGNO = $request->regno;
        $vip->WSID = $request->wsid;
        $vip->VEHCLASS = 'A';
        $vip->USRNME = Auth()->user()->USRNME;
        $vip->STARTDATE = $from;
        $vip->ENDDATE = $to;
        $vip->PASSNO = $request->passno;
        $vip->save();
    
    
        return redirect()->intended('/manage-vip')->with('msg','Success...');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $tarif = TmpPlat::where('REGNO',$id);
        $tarif->delete();
        
        return redirect()->intended('/manage-vip')->with('msg','Success...');
    }
}
