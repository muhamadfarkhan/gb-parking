<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Trans;
use App\Models\User;
use App\Models\Site;
use App\Models\Biaya;
use App\Models\MstPar;
use Session;
use Carbon\Carbon;

class MainController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
        $data['title'] = 'Dashboard';
        $data['trans'] = Trans::count();
        $data['totalIncomeToday'] = Trans::whereDate('DATETIMEOUT', Carbon::today())->sum('TRANFEE');
        $data['totalInToday'] = Trans::whereDate('DATETIMEIN', Carbon::today())->count();
        $data['totalOutToday'] = Trans::whereDate('DATETIMEOUT', Carbon::today())->count();
        $data['totalOutMotorToday'] = Trans::where('VEHCLASS','C')->whereDate('DATETIMEOUT', Carbon::today())->count();
        $data['totalOutMobilToday'] = Trans::where('VEHCLASS','B')->whereDate('DATETIMEOUT', Carbon::today())->count();
        $data['totalOutBoxToday'] = Trans::where('VEHCLASS','X')->whereDate('DATETIMEOUT', Carbon::today())->count();
        return view('layouts.dashboard', $data);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function ticketTrans()
    {
        
        $data['title'] = 'Transaksi Tiket';
        // if(Auth()->user()->level == 'Super admin'){
            $site = Site::get();
        // }else{
        //     $site = Site::join('mtx_sites','mtx_sites.site_id','sites.id')
        //             ->select('sites.*')
        //             ->where('mtx_sites.user_id',Auth()->user()->id)
        //             ->get();
        // }
        $perusahaan = MstPar::where('FLDNM','JNSPT')->orderBy('CODE')->get();
        //  deptcd= 0110 lvlcd= 5
        $petugas = User::where('DEPTCD','0110')->where('LVLCD','5')->get();
        $ticket = Biaya::get();
        $pembayaran = Biaya::get();
        $kapal = MstPar::where('FLDNM','JNSKPL')->orderBy('CODE')->get();
        
        $data['site'] = $site; 
        $data['perusahaan'] = $perusahaan; 
        $data['kapal'] = $kapal; 
        $data['petugas'] = $petugas; 
        $data['ticket'] = $ticket; 
        $data['pembayaran'] = $pembayaran; 
        $data['dateRangeNow'] = date('d/m/Y');
        return view('modules.trans.ticket', $data);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function recapTrans()
    {
        
        $data['title'] = 'Laporan Rekap Transaksi';
        // if(Auth()->user()->level == 'Super admin'){
            $site = Site::get();
        // }else{
        //     $site = Site::join('mtx_sites','mtx_sites.site_id','sites.id')
        //             ->select('sites.*')
        //             ->where('mtx_sites.user_id',Auth()->user()->id)
        //             ->get();
        // }

        $perusahaan = MstPar::where('FLDNM','JNSPT')->get();
        $petugas = User::where('DEPTCD','0110')->where('LVLCD','5')->get();

        $data['site'] = $site; 
        $data['perusahaan'] = $perusahaan; 
        $data['petugas'] = $petugas; 
        $data['dateRangeNow'] = date('d/m/Y');
        return view('modules.trans.recap', $data);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function compareIncome()
    {
        
        $data['title'] = 'Laporan Komparasi Income';
        if(Auth()->user()->level == 'Super admin'){
            $site = Site::get();
        }else{
            $site = Site::join('mtx_sites','mtx_sites.site_id','sites.id')
                    ->select('sites.*')
                    ->where('mtx_sites.user_id',Auth()->user()->id)
                    ->get();
        }
        $data['site'] = $site; 
        $data['dateRangeNow'] = date('d/m/Y');
        return view('modules.trans.compare', $data);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function manageSite()
    {
        
        $data['title'] = 'Manage Site';
        $data['site'] = Site::get();
        $data['dateRangeNow'] = date('d/m/Y');
        return view('modules.manage.site', $data);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function manageTarif()
    {
        
        $data['title'] = 'Manage Tarif';
        $data['biaya'] = Biaya::get();
        $data['dateRangeNow'] = date('d/m/Y');
        return view('modules.manage.tarif', $data);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function manageUser()
    {
        
        $data['title'] = 'Manage User';
        $data['user'] = User::get();
        return view('modules.manage.user', $data);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function manageVIP()
    {
        
        $data['title'] = 'Manage VIP';
        $data['user'] = User::get();
        return view('modules.manage.vip', $data);
    }

   
}
