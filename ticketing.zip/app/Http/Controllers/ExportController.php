<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Trans;
use App\Models\Biaya;
use App\Models\Site;
use App\Models\User;
use App\Models\MstPar;
use App\Models\TmpPlat;
use DataTables;
use Barryvdh\DomPDF\Facade\Pdf;
use DB;

class ExportController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function pdfTrans(Request $request)
    {
        
        // dd($request);
        
        set_time_limit(0);

        if(empty($request->range)){
            $from = date("Y-m-d", strtotime("-1 months"));
            $to = date('Y-m-d');
        }else{
            $split = explode(" - ",str_replace('/', '-', $request->range));
            $from = date("Y-m-d H:i:s", strtotime($split[0]));
            $to = date("Y-m-d H:i:s", strtotime($split[1]));
        }

        if(empty($request->payment_method)){
            $data = Trans::whereBetween('DATETIMEIN', [$from, $to])
                ->select('REGNO','PASSNO','ENTPAY','CPSFEE','DATETIMEIN','NOTRAN','TRANSAMT','VEHCLASS','DATETIMEOUT','USRNMA','TRANFEE','TRANPAY','USRNME')
                // ->where('site_id',$request->site)
                ->get();
        }else{
            $data = Trans::whereBetween('DATETIMEIN', [$from, $to])
                ->select('REGNO','PASSNO','ENTPAY','CPSFEE','DATETIMEIN','NOTRAN','TRANSAMT','VEHCLASS','DATETIMEOUT','USRNMA','TRANFEE','TRANPAY','USRNME')->where('TRANPAY',$request->payment_method)
                // ->where('site_id',$request->site)
                ->get();
        }

        $site = Site::where('id',$request->site)->first();

        $fileName = 'Transaksi Tiket '.$site->site_name.' '.date("dmY", strtotime($from)).'-'.date("dmY", strtotime($to));

        $tgl = date("d-m-Y", strtotime($split[0])).' s/d '.date("d-m-Y", strtotime($split[1]));
        $jam = date("H:i:s", strtotime($split[0])).' s/d '.date("H:i:s", strtotime($split[1]));

        if(empty($request->perusahaan)){
            $perusahaan = 'All';
        }else{
            $perusahaan = MstPar::where('CODE',$request->perusahaan)->first()->DESCR;
        }

        if(empty($request->petugas)){
            $petugas = 'All';
        }else{
            $petugas = User::where('USRNME',$request->petugas)->first()->FULLNM;
        }

        if(empty($request->pembayaran)){
            $pembayaran = 'All';
        }else{
            // $pembayaran = $request->pembayaran;
            if ($request->pembayaran == "E") {
                $pembayaran = "E-Payment";
            } elseif ($request->pembayaran == "C") {
                $pembayaran = "Cash";
            } elseif ($request->pembayaran == "P") {
                $pembayaran = "Member";
            } elseif ($request->pembayaran == "O") {
                $pembayaran = "Online";
            } elseif ($request->pembayaran == "V") {
                $pembayaran = "Voucher";
            }
        }
        
        if(empty($request->jenis_tiket)){
            $jenis_tiket = 'All';
        }else{
            $jenis_tiket = $request->jenis_tiket;
        }

        $pdf = Pdf::loadView('modules.trans.pdfTicket', ['data'=>$data,'site'=>$site,'tgl'=>$tgl,'jam'=>$jam,'from'=>$from,'to'=>$to,'site_id'=>$request->site
        ,'perusahaan'=>$perusahaan,'petugas'=>$petugas,'pembayaran'=>$pembayaran
        ,'jenis_tiket'=>$jenis_tiket]);
        return $pdf->download("$fileName.pdf");
    }

     /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function pdfRecap(Request $request)
    {
        $site = Site::where('id',$request->site)->first();

        $from = date("Y-m-d 00:00:00", strtotime(str_replace('/', '-', $request->start)));
        $to = date("Y-m-d 23:59:00", strtotime(str_replace('/', '-', $request->end)));
        
        $data = Trans::select([
            DB::raw('sum(NOTRAN) as totalC'),
            DB::raw('WALKDES as vehicle'),
            DB::raw('sum(TRANFEE) as TRANFEE'),
            DB::raw("SUM(ENTRYTYPE = '2' and DATETIMEIN between '".$from."' and  '".$to."') online"),
            DB::raw("SUM(ENTRYTYPE = '1' and DATETIMEIN between '".$from."' and  '".$to."') offline"),
            DB::raw("SUM(DATETIMEIN between '".$from."' and  '".$to."') totalLine"),
            DB::raw("sum(case when DATETIMEIN between '".$from."' and  '".$to."' then VLTAMT else 0 end) pelayanan"),
            DB::raw("sum(case when DATETIMEIN between '".$from."' and  '".$to."' then VLTFEE else 0 end) tjp"),
            DB::raw("sum(case when DATETIMEIN between '".$from."' and  '".$to."' then CPSAMT else 0 end) iuran_wajib"),
            DB::raw("sum(case when DATETIMEIN between '".$from."' and  '".$to."' then TRANFEE else 0 end) pas_pelabuhan"),
            DB::raw("sum(case when DATETIMEIN between '".$from."' and  '".$to."' then TRANSAMT else 0 end) total"),
            DB::raw("0 manualCasualOut"),
            DB::raw("0 manualPassOut"),
            DB::raw("0 manualCasualIn"),
            DB::raw("0 manualPassIn"),
            DB::raw("sum(case when DATETIMEOUT between '".$from."' and  '".$to."' then TRANFEE else 0 end) pendapatan"),
            DB::raw("sum(case when TRANPAY = 'C' and DATETIMEIN between '".$from."' and  '".$to."' then TRANSAMT else 0 end) tunai"),
            DB::raw("sum(case when TRANPAY = 'E' and DATETIMEIN between '".$from."' and  '".$to."' then TRANSAMT else 0 end) ePayment"),
            DB::raw("sum(case when TRANPAY = 'P' and DATETIMEIN between '".$from."' and  '".$to."' then TRANSAMT else 0 end) pass"),
        ])
        ->join('tbl_biaya','tbl_trans.VEHCLASS','tbl_biaya.VEHCLASS')
        // ->whereIn('tbl_biaya.VEHCLASS', array('C', 'B'))
        ->groupBy('vehicle')
        ->havingRaw('total > 0')->get();

        $fileName = 'Rekap Transaksi '.$site->site_name.' '.date("dmY", strtotime($from)).'-'.date("dmY", strtotime($to));

        $startDate = date("d-m-Y", strtotime($from));
        $endDate = date("d-m-Y", strtotime($to));
        $startHour = date("H:i:s", strtotime($from));
        $endHour = date("H:i:s", strtotime($to));

        if(empty($request->perusahaan)){
            $perusahaan = 'All';
        }else{
            $perusahaan = MstPar::where('CODE',$request->perusahaan)->first()->DESCR;
        }

        if(empty($request->petugas)){
            $petugas = 'All';
        }else{
            $petugas = User::where('USRNM',$request->petugas)->first()->FULLNM;
        }


        $pdf = Pdf::loadView('modules.trans.pdfRecap', ['data'=>$data,'site'=>$site,'startDate'=>$startDate,'endDate'=>$endDate,
        'startHour'=>$startHour,'endHour'=>$endHour,'perusahaan'=>$perusahaan,'petugas'=>$petugas])->setPaper('a4', 'landscape');
        return $pdf->download("$fileName.pdf");
        
    }

     /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function pdfCompare(Request $request)
    {
        
        // dd($request);
        $site = Site::where('id',$request->site)->first();

        $day = str_pad($request->day, 2, "0", STR_PAD_LEFT);
        $dayBefore = str_pad((int) $request->day-1, 2, "0", STR_PAD_LEFT);
        $month = str_pad($request->month, 2, "0", STR_PAD_LEFT);
        $monthBefore = str_pad((int) $request->month-1, 2, "0", STR_PAD_LEFT);
        $year = $request->year;
        $type = $request->type;

        $dayCheck = $year.'-'.$month.'-'.$day;
        $dayCheckBefore = $year.'-'.$month.'-'.$dayBefore;

        $dto = new \DateTime();
        $dto->setISODate($year, $day);
        $weekCheck = $dto->format('Y-m-d');
        $dto->modify('+6 days');
        $lastDay = $dto->format('Y-m-d');

        if($type == 'day'){
            $jenis = "Harian";
            $title = $dayBefore.'/'.$month.'/'.$year.' s/d '.$day.'/'.$month.'/'.$year;
            $titlesub1 = $day.'/'.$month.'/'.$year;
            $titlesub2 = $dayBefore.'/'.$month.'/'.$year;
            
            $data1 = Trans::select([
                DB::raw('sum(NOTRAN) as total'),
                DB::raw('WALKDES as vehicle'),
                DB::raw('sum(TRANFEE) as TRANFEE'),
                DB::raw("SUM(tranpay = 'p' and date(DATETIMEIN) = '".$dayCheck."') passIn"),
                DB::raw("SUM(tranpay != 'p' and date(DATETIMEIN) = '".$dayCheck."') casualIn"),
                DB::raw("SUM(tranpay = 'p' and date(DATETIMEOUT) = '".$dayCheck."') passOut"),
                DB::raw("SUM(tranpay != 'p' and date(DATETIMEOUT) = '".$dayCheck."') casualOut"),
            ])
            ->join('tbl_biaya','tbl_trans.VEHCLASS','tbl_biaya.VEHCLASS')
            // ->whereIn('tbl_trans.VEHCLASS', array('C', 'B'))
            ->whereDate('DATETIMEOUT',$dayCheck)
            ->where('site_id',$request->site)
            ->groupBy('vehicle')->get();

            $data2 = Trans::select([
                DB::raw('sum(NOTRAN) as total'),
                DB::raw('WALKDES as vehicle'),
                DB::raw('sum(TRANFEE) as TRANFEE'),
                DB::raw("SUM(tranpay = 'p' and date(DATETIMEIN) = '".$dayCheckBefore."') passIn"),
                DB::raw("SUM(tranpay != 'p' and date(DATETIMEIN) = '".$dayCheckBefore."') casualIn"),
                DB::raw("SUM(tranpay = 'p' and date(DATETIMEOUT) = '".$dayCheckBefore."') passOut"),
                DB::raw("SUM(tranpay != 'p' and date(DATETIMEOUT) = '".$dayCheckBefore."') casualOut"),
            ])
            ->join('tbl_biaya','tbl_trans.VEHCLASS','tbl_biaya.VEHCLASS')
            // ->whereIn('tbl_trans.VEHCLASS', array('C', 'B'))
            ->whereDate('DATETIMEOUT',$dayCheckBefore)
            ->where('site_id',$request->site)
            ->groupBy('vehicle')->get();

        }else if($type == 'week'){

            $jenis = "Mingguan";
            $data1 = Trans::select([
                DB::raw('sum(NOTRAN) as total'),
                DB::raw('WALKDES as vehicle'),
                DB::raw('sum(TRANFEE) as TRANFEE'),
                DB::raw("SUM(tranpay = 'p' and YEARWEEK(DATETIMEIN, 1) =  YEARWEEK('".$weekCheck."',1)) passIn"),
                DB::raw("SUM(tranpay != 'p' and YEARWEEK(DATETIMEIN, 1) =  YEARWEEK('".$weekCheck."',1)) casualIn"),
                DB::raw("SUM(tranpay = 'p' and YEARWEEK(DATETIMEOUT, 1) =  YEARWEEK('".$weekCheck."',1)) passOut"),
                DB::raw("SUM(tranpay != 'p' and YEARWEEK(DATETIMEOUT, 1) =  YEARWEEK('".$weekCheck."',1)) casualOut"),
            ])
            ->join('tbl_biaya','tbl_trans.VEHCLASS','tbl_biaya.VEHCLASS')
            // ->whereIn('tbl_trans.VEHCLASS', array('C', 'B'))
            ->whereDate('DATETIMEOUT','>=',$weekCheck)
            ->whereDate('DATETIMEOUT','<=',$lastDay)
            ->where('site_id',$request->site)
            ->groupBy('vehicle')->get();
        }else if($type == 'month'){
            
            $jenis = "Bulanan";
            $monthNumBefore  = $monthBefore;
            $monthNum  = $month;
            $dateObj   = \DateTime::createFromFormat('!m', $monthNum);
            $dateObjBefore   = \DateTime::createFromFormat('!m', $monthNumBefore);
            $monthNameBefore = $dateObjBefore->format('F');
            $monthName = $dateObj->format('F');

            $title = $monthNameBefore.' '.$year.' s/d '.$monthName.' '.$year;
            $titlesub1 = $monthName.' '.$year;
            $titlesub2 = $monthNameBefore.' '.$year;
           
            $data1 = Trans::select([
                DB::raw('sum(NOTRAN) as total'),
                DB::raw('WALKDES as vehicle'),
                DB::raw('sum(TRANFEE) as TRANFEE'),
                DB::raw("SUM(tranpay = 'p' and month(DATETIMEIN) = '".$month."') passIn"),
                DB::raw("SUM(tranpay != 'p' and month(DATETIMEIN) = '".$month."') casualIn"),
                DB::raw("SUM(tranpay = 'p' and month(DATETIMEOUT) = '".$month."') passOut"),
                DB::raw("SUM(tranpay != 'p' and month(DATETIMEOUT) = '".$month."') casualOut"),
            ])
            ->join('tbl_biaya','tbl_trans.VEHCLASS','tbl_biaya.VEHCLASS')
            // ->whereIn('tbl_trans.VEHCLASS', array('C', 'B'))
            ->whereMonth('DATETIMEOUT',$month)
            ->where('site_id',$request->site)
            ->groupBy('vehicle')->get();

            $data2 = Trans::select([
                DB::raw('sum(NOTRAN) as total'),
                DB::raw('WALKDES as vehicle'),
                DB::raw('sum(TRANFEE) as TRANFEE'),
                DB::raw("SUM(tranpay = 'p' and month(DATETIMEIN) = '".$monthBefore."') passIn"),
                DB::raw("SUM(tranpay != 'p' and month(DATETIMEIN) = '".$monthBefore."') casualIn"),
                DB::raw("SUM(tranpay = 'p' and month(DATETIMEOUT) = '".$monthBefore."') passOut"),
                DB::raw("SUM(tranpay != 'p' and month(DATETIMEOUT) = '".$monthBefore."') casualOut"),
            ])
            ->join('tbl_biaya','tbl_trans.VEHCLASS','tbl_biaya.VEHCLASS')
            // ->whereIn('tbl_trans.VEHCLASS', array('C', 'B'))
            ->whereMonth('DATETIMEOUT',$monthBefore)
            ->where('site_id',$request->site)
            ->groupBy('vehicle')->get();
        }

        
        $fileName = 'Komparasi Income '.$site->site_name.' '.str_replace(' s/d ',' ',$title);
        $laporan = "Komparasi ".$jenis;

        $pdf = Pdf::loadView('modules.trans.pdfCompare', ['data1'=>$data1,'data2'=>$data2,'site'=>$site,'laporan'=>$laporan,'title'=>$title,'titlesub1'=>strtoupper($titlesub1),'titlesub2'=>strtoupper($titlesub2) ])->setPaper('a4', 'landscape');
        return $pdf->download("$fileName.pdf");

    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function pdfVip(Request $request)
    {
        
        // dd($request);
       
        $fileName = 'Laporan data VIP';

        $data = TmpPlat::get();

        $pdf = Pdf::loadView('modules.trans.pdfVip', ['data'=>$data])->setPaper('a4', 'landscape');
        return $pdf->download("$fileName.pdf");

    }

}
