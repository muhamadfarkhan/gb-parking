<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Biaya extends Model
{
    protected $table = 'tbl_biaya';
    public $timestamps = false;
}
