<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Trans extends Model
{
    protected $table = 'tbl_trans';
    
    protected $guarded = [];
    
    public $timestamps = false;

    public function biaya(){
        return $this->hasOne(Biaya::class,'VEHCLASS','VEHCLASS');
    }

    public function perusahaan(){
        return $this->hasOne(MstPar::class,'CODE','USRNME');
    }

    public function kapal(){
        return $this->hasOne(MstPar::class,'CODE','USRNMP');
    }
}
