<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class MstPar extends Model
{
    protected $table = 'mst_par';
    public $timestamps = false;
}
