<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MtxSite extends Model
{
    protected $table = 'mtx_sites';
}
