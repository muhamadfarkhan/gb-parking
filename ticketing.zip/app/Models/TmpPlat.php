<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class TmpPlat extends Model
{
    protected $table = 'tmpplat';
    public $timestamps = false;
}
