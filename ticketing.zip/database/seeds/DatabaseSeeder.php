<?php

use App\Models\User;
use App\Models\Site;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // $this->call(UserSeeder::class);
        User::create([
            'name'=>'User 01',
            'username'=>'user01',
            'email'=>'user01@email.com',
            'level'=>'Petugas',
            'password'=>Hash::make('user1234'),
  
        ]);

        Site::create([
            'site_name'=>'Site 01',
            'site_desc'=>'Site 01 - Jakarta',
        ]);

        Site::create([
            'site_name'=>'Site 02',
            'site_desc'=>'Site 02 - Semarang',
        ]);
    }
}
