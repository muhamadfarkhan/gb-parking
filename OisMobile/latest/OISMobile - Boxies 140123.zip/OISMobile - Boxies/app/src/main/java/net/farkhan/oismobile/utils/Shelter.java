package net.farkhan.oismobile.utils;

import android.graphics.Bitmap;

public class Shelter {

        public static Bitmap img;

}
